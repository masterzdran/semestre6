﻿
Public Class SomeClassInVB
    Overridable Sub M1()
        Console.WriteLine("M1 from VB")
    End Sub
End Class
