﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CipherEngine;

namespace CipherAlgorithms
{
	public class Des : ICipher
	{	
		string key;

		public string Key
		{
			get
			{
				return key;
			}
			set
			{
				key=value;
			}
		}

		public void cipher(string fileIn, string fileOut)
		{
			Console.WriteLine("Cipher with DES Algorithm");
		}
	}
}
