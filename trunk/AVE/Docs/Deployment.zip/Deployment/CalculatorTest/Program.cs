/************************************
 * teste da utiliza��o de diferentes vers�es de assemblies via 
 * bindings especificados em ficheiro de configura��o
 */

using System;
using System.Collections.Generic;
using System.Text;
using AVE_Deployment2;


namespace AVE_Deployment
{
    class Program 
    {
       
        static void Main(string[] args)
        {
            Calculator c = new Calculator();

            Console.WriteLine(c.factorial(6));
        }
    }
}
