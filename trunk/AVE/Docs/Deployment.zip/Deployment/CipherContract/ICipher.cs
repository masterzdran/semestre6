﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CipherEngine
{
	public interface  ICipher
	{
		string Key { get; set; }
		void cipher(string fileIn, string fileOut);
	}
}
