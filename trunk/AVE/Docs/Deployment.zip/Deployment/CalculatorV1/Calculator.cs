/*
 * vers�o 1 da calculadora
 */

using System;
using System.Collections.Generic;
using System.Text;

namespace AVE_Deployment2
{
    public class Calculator
    {
        private int fact(int v) {
            if (v <= 2) return v;
            return v *fact(v-1);
        }

        public int factorial(int n)
        {
            Console.WriteLine("recursive version");
            return fact(n);
        }

    }
}
