/*
 * vers�o 2 da calculadora
 */

using System;
using System.Collections.Generic;
using System.Text;

namespace AVE_Deployment
{
    public class Calculator
    {
        private int fact(int v)
        {
            int f = 2;
            for (int i = 3; i <= v; ++i) f *= i;
            return f;
        }

        public int factorial(int n)
        {
            Console.WriteLine("iterative version");
            return fact(n);
        }

    }
}

