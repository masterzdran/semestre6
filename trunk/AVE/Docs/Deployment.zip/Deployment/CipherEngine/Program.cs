﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AVEUtils;
using System.Configuration;
using System.Reflection;

namespace CipherEngine
{
	class MyOptions : Options
	{
		[Option(Nickname="k", Description="Algorithm key")]
		public string key;

		[Option(Nickname = "n", Description = "Algorithm name")]
		public string name;

		public override string ToString()
		{
			StringBuilder sb = new StringBuilder();
			sb.Append("key= ");
			sb.Append(key == null ? "none" : key);
			sb.AppendLine();
			sb.Append("algorithm= ");
			sb.Append(name == null ? "none" : name);
			sb.AppendLine();
			return sb.ToString();
		}
	}

	class Program {
        private static string _pluginsPath=null;
        static string PluginsPath
        {
            get
            {
                if (_pluginsPath == null)  
                   _pluginsPath = 
                       ConfigurationManager.AppSettings["PluginsPath"];
                return _pluginsPath;
            }
        }

		private static ICipher cipherInstance(string plugin)
		{
			if (plugin == null) return null;
			string[] names = plugin.Split(',');
			if (names.Length != 2) return null;

            // using Assembly.Loadfrom. Try using Assembly.Load instead 
			Assembly a = Assembly.LoadFrom(PluginsPath+"\\"+names[0]+".dll");
			//Assembly a = Assembly.Load(names[0]);
			if (a == null) return null;
			return (ICipher)a.CreateInstance(names[1]);
		}

		private static void cipherForPlugin(string plugin, string key, string fileIn, string fileOut) {
			ICipher cipherAlg = cipherInstance(plugin);
            if (cipherAlg == null)
                throw new Exception("Unknown cipher algorithm");
			cipherAlg.Key= key;
			cipherAlg.cipher(fileIn, fileOut);
		
		}
				

		static void Main(string[] args)
		{
            // Using Options infrastruture. See optbbuild project in Reflection examples.
			MyOptions options = new MyOptions();

			try
			{
                // populate MyOptions instance with program options and arguments
				options.load(args);

                Console.WriteLine("Start show options and arguments\n");
				Console.WriteLine(options);

				for (int i = 0; i < options.Arguments.Length; ++i)
				   Console.WriteLine("Arguments[{0}]={1}", i, options.Arguments[i]);

                Console.WriteLine("\nEnd show options and arguments\n");
				if (options.key == null || options.name == null || options.Arguments.Length != 2)
					throw new Exception("Invalid Parameters");

                cipherForPlugin(ConfigurationManager.AppSettings[options.name],
                                options.key,
                                options.Arguments[0],
                                options.Arguments[1]);
			}
			catch (Exception e)
			{
				Console.WriteLine("Error ciphering file: {0}", e.Message);
				options.usage();
			}

		}
	}
}
