/*--------------------------------------------------------------------------
 * Utiliza��o de tipos internos. repare como o tipo interno tem acesso ao estado provado
 * do tipo englobante
 * 
 * Jorge Martins, 2009 
 * -----------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;

class TOuter
{
    private int i;

    class TInner
    {
        internal TInner(TOuter outer)
        {

            Console.WriteLine(outer.i);
        }
    }

    public TOuter(int val)
    {
        this.i = val;
        TInner ti = new TInner(this);
    }
}

class Program
{
    static void Main(string[] args)
    {
        TOuter t1 = new TOuter(2);
    }
}

