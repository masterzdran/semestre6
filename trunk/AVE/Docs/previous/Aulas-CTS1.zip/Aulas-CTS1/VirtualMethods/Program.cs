/*----------------------------------------------------------------------------------
 * Utiliza��o simples do atributo new do C# aplicado a m�todos virtuais e
 * n�o virtuais. Explique o comportamento na execu��o eos warnings na compila��o
 * 
 * Jorge Marins, 2009
 * ----------------------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;

class B
{
	// retira os coment�rios do m�todo e explique as diferen�as
	//public void m(int i)
	//{
	//    Console.WriteLine("m of B");
	//}

    public virtual void vm() {
        Console.WriteLine("vm of B");
    }
}

class D : B
{
    public new void m(int i)
    {
        Console.WriteLine("m of D");
    }

    public virtual new  void vm()
    {
        Console.WriteLine("vm of D");
    } 
}
 
class Program
{
    static void Main(string[] args)
    {
		B b = new D();
		//b.m(2);
		b.vm();
    }
}
 