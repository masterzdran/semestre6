/*------------------------------------------------------------
 * Despaho din�mico em interfaces e m�todoso virtuais
 * Antes de executar, qual � o output gerado pela execu��o?
 * 
 * Jorge Martins, 2010
 *-----------------------------------------------------------*/

using System;
interface I1 { int m(int a); void m2(); }

public class A : I1 {
	public virtual void m2() { Console.WriteLine("m2 de A"); }
    public  virtual int m(int a) { return ++a; }
}
public class B : A {
	public override int m(int a) { return base.m(a) + 5; }
}

public class C : B {
    public override int m(int a) { return a += 3; }
}



public class Teste
{
 
    static void Test1()
    {
        A a = new C();
        I1 i1 = a;
        A a2 = new B();
        B b = new C();

        //Console.WriteLine(a.m(0));
        Console.WriteLine(i1.m(0));
        //Console.WriteLine(a2.m(0));
        Console.WriteLine(b.m(0));
    }



    static void Main(string[] args)
    {
        Test1();
    }

}
