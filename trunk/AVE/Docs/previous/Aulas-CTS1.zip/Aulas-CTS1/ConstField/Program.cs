/*---------------------------------------------------------------
 *  Utiliza��o de constantes.
 *  Analise o c�digo IL gerado
 *  Jorge Martins, 2009
 *--------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;

namespace ConstField
{
    class Program
    {
        public const double PI=3.14;


        public static void oper(ref double val) {
            Console.WriteLine(val);
        }

        static void Main(string[] args)
        {
            double v = PI;
        }
    }
}
