/*-----------------------------------------------------------------
 * Mostra a utiliza��o simples de reflex�o e a unifica��o entre tipos valor e tipos refer�ncia
 * 
 * JMartins, 2009
 * ------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;


struct Ancestors
{

    public static void Show(Type t)
    {
		if (t == typeof(System.Object)) { Console.WriteLine(t.FullName); return; }
        Show(t.BaseType);
		Console.WriteLine(t.FullName);
       
    }

    public static void Main()
    {
		object o = (object)new Ancestors();
        Ancestors.Show(5.GetType());
    }
}
