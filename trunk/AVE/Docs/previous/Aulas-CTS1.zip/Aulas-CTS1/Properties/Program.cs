/*-----------------------------------------------------------------------------
 * Utiliza��o de propriedades e indexers
 * 
 * Analise o c�digo IL gerado
 * 
 * Jorge Martins, 2010
 *-----------------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Properties
{

    struct Ponto
    {
        private int x, y;

        public Ponto(int x, int y)
        {
            this.x = x; this.y = y;
        }

        public int X
        {
            get
            {
                return x;
            }

			set
            {
				if (value < 0)
					throw new InvalidDataException();
					 x=value;
            }

       
        }

		public int Y
		{
			get
			{
				return y;
			}

			set
			{
				if (value < 0)
					throw new InvalidDataException();
				y= value;
			}


		}
    }



    class Program
    {
        public int this[string name]
        {
            get { return 2; }
        }

        public string  this[long index, string str]
        {
            get { return "TESTE"; }
        }

        static void Main(string[] args)
        {
            Program p = new Program();
            Console.WriteLine(p["teste"]);
            Console.WriteLine(p[3, "a"]);

            Ponto p1 = new Ponto(1,2);
            p1.X = -3;
        }
    }
}
