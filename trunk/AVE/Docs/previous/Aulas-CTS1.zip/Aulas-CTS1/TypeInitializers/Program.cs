/*----------------------------------------------------------------------------
 * Ilustra as duas formas de inicia��o de tipos em C#. Com e sem o atributo beforefieldinit
 * 
 * Explique as diferen�as de comportamento
 * Jorge Martins, 2009
 *-------------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;

class TBeforeFieldInit
{
    public static int val = getVal();

    public static int getVal()
    {

        Console.WriteLine("in getVal()");
        return 2;
    }
}

class TOnDemand
{
    public static int val = 3;
    static TOnDemand()
    {
        Console.WriteLine("TOnDemand");
    }
}


class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("In main");
        int v  = TBeforeFieldInit.val;
        int v2 = TOnDemand.val;
       
    }
}
