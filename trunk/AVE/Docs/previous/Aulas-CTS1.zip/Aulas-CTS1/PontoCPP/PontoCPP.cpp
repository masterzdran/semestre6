/*----------------------------------------------------------
  Ilustra a possibilidade de acesso �s inst�ncias da
	vers�o boxed de um tipo valor no C++/CLI, ao contr�rio 
	do que acontece em C#

	JMartins, 2009

	---------------------------------------------------------*/
#include "stdafx.h"

using namespace System;


public value class PontoCPP {
public:
	int x, y;

  
	PontoCPP(int x, int y) {
		this->x = x; this->y=y;
	}

	virtual String^ ToString() override {
		return String::Format("({0}, {1})", x, y);
	}

};



int main() {
	PontoCPP p1(2,3);

	Console::WriteLine(p1.ToString());

	Object^ p2 = p1;


	PontoCPP^ p3 = (PontoCPP^) p2;
	// acesso � vers�o boxed. P3 e p2 referem o mesmo objecto
	p3->x= 5;
	Console::WriteLine(p2);

	PontoCPP p4 = (PontoCPP) p2;
	// p4 � uma inst�ncia do tipo valor PontoCPP, c�pia do objecto referido por p2
	p4.x= 10;
	Console::WriteLine(p2);

	return 0;
}
