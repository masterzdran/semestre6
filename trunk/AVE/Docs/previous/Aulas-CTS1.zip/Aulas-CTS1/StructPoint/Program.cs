/*--------------------------------------------------------------------------
 * Diferentes modos de implementa��o de tipos valor  
 * 
 * Utilize os defines para testar as diferentes possibilidades.
 * Analise o c�digo IL gerado e explique o comportamento da execu��o
 * 
 * Jorge Martins, 2010
 *---------------------------------------------------------------------------*/

#define WITH_REDEFINED_TOSTRING
#define WITH_REDEFINED_EQUALS

using System;

public struct A {
	int i;

	public A(int i) { this.i = i; }
	public override String ToString() { return i.ToString(); }
	public static void m() {
		A x = new A(3);
		A y = x;
		Object o1 = x;
		Object o2 = y;
		if (o1.Equals(o2)) Console.WriteLine("os objectos s�o iguais");
		else Console.WriteLine("os objectos s�o diferentes");
		if (o1==o2) Console.WriteLine("os objectos s�o iguais");
		else Console.WriteLine("os objectos s�o diferentes");
	}
}


public struct Ponto {

    public  int x, y;

	
    public Ponto(int x, int y) { this.x = x; this.y = y; }
#if WITH_REDEFINED_TOSTRING
    public override String ToString()
    {
        return String.Format("({0},{1})", x, y);
    }
#endif

#if WITH_REDEFINED_EQUALS
    public override bool Equals(Object obj)
    {
        if ( !(obj is Ponto)) return false;
        Ponto p = (Ponto)obj;
		return Equals(p);
    }

    public override int GetHashCode() { return x ^ y; }

   
    
#endif

	public bool Equals(Ponto p)
	{
		return x == p.x && y == p.y;
	}
#if WITH_OPERATOR_OVERLOAD
    public static bool operator ==(Ponto p1, Ponto p2)
    {
        return p1.Equals(p2);
    }


    public static bool operator !=(Ponto p1, Ponto p2)
    {

        return !p1.Equals(p2);
    }
#endif

};

 
class Program
{
    public static void Main(String[] args)
    {

		A.m();
		return;

        Ponto p1 = new Ponto(2, 2), p2 = new Ponto(2, 2);

		 

		Console.WriteLine(p2.Equals(p1));

		object o2 = p2;
		
		Ponto p4 = (Ponto) o2;
		p4.x = 5;
		Console.WriteLine(o2);

	
#if OPERATOR_OVERLOAD
        Console.WriteLine(p2 == p1);
        //
#endif

        object o = p2;
		Ponto p3 = (Ponto) o;
		p3.x = 5;

		Console.WriteLine(p3);

        DateTime start = DateTime.Now;

        for (int i = 0; i < 10000000; ++i)
            p1.Equals(o);
        Console.WriteLine("teste calling Object Equals in {0} ms", (DateTime.Now - start).TotalMilliseconds);

        start = DateTime.Now;
        for (int i = 0; i < 10000000; ++i)
            p1.Equals(p2);
        Console.WriteLine("teste calling Ponto Equals in {0} ms", (DateTime.Now - start).TotalMilliseconds);

    }
}


