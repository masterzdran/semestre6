/*--------------------------------------------------------------------------
 * Diferentes modos de implementa��o de interfaces em C#
 * 
 * Utilize os defines para testar as diferentes possibilidades.
 * Analise o c�digo IL gerado e explique o comportamento da execu��o
 * 
 * Jorge Martins, 2010
 *---------------------------------------------------------------------------*/

#define EXPLICIT
#define SEALED

using System;
using System.Collections.Generic;
using System.Text;

interface I1
{
    void m1();
    void m2();
}

interface I2 {
    void m1();
}

class X : I1, I2{ 

    // implementa��o aberta
    public virtual void m1() {
        Console.WriteLine("m1 de I1 em X");
    }

#if !SEALED
	public virtual void m2()
	{
		Console.WriteLine("m2 de I1 em X");
	}
#endif

#if EXPLICIT
    // implementa��o expl�cita (privada e sealed)
    void I2.m1() {
        Console.WriteLine("m1 de I2 em X");
    }   


#endif

#if SEALED
	
    // implementa��o sealed
    public void m2() {
        Console.WriteLine("m2 de X");
    }
#endif
}

class Y : X, I1
{

    public override void m1()
    {
        Console.WriteLine("m1 de Y");
    }

    public new void m2()
    {
        Console.WriteLine("m2 de Y");
    }
}

class Program
{
    static void Main(string[] args)
    {
        X x1 = new X();
		I2 i2 = x1;
		i2.m1();
		//x1.m1();
		//x1.m2();
    }
}
