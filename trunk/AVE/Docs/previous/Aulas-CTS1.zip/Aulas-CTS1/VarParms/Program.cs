/*-----------------------------------------------------------------------------------------------
 * 
 * Utiliza��o do atributo parms para construir m�todos que recebem um n�mero vari�vel de par�metros
 * 
 * Jorge Martins, 2009
 *------------------------------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;

namespace VarParms
{
    class Program
    {
       

        public static void VarParms(string parm1,  params object[] varParms) {
            Console.WriteLine("received Parms:");
            Console.WriteLine("\t{0}", parm1);
            for (int i=0; i < varParms.Length; ++i) 
                Console.WriteLine("\t{0}", varParms[i]);
        }

        static void Main(string[] args)
        {
            VarParms("teste", 1, 2, 3);

        }
    }
}
