/*------------------------------------------------------------------------------- 
 * Ilustra a correcta implementa��o de Equals na exist�ncia de hierarquias de classes
 *  //uncomment next line and explain the different results
 *  
 * Jorge Martins, 2010
 *------------------------------------------------------------------------------*/ 
 
//#define WithAuxEquals

using System;
using System.Collections.Generic;
using System.Text;


public class Ponto
{

    public int x, y;

	public Ponto()
	{
		x = 0; y = 0;
	}

    public Ponto(int x, int y) { this.x = x; this.y = y; }

    public override String ToString()
    {
        return String.Format("({0},{1})", x, y);
    }

    public override bool Equals(Object obj)
    {
        if (obj == null) return false;
        if (obj.GetType() != this.GetType()) return false;
		 
        Ponto p = (Ponto)obj;

        return x == p.x && y == p.y;
    }


#if WithAuxEquals
    public bool Equals(Ponto p) {
        if (p == null) return false;
        return x == p.x && y == p.y; 
    }
#endif

    public override int GetHashCode() { return x ^ y; }

 
	// redefini��o dos operadores == e !=
    public static bool operator ==(Ponto p1, Ponto p2)
    {
        return Object.Equals(p1, p2);
    }


    public static bool operator !=(Ponto p1, Ponto p2)
    {

        return !Object.Equals(p1, p2);
    }
 
}

class Ponto3D : Ponto
{
    int z=5;
    public Ponto3D(int x, int y, int z)
        : base(x, y)
    {
        this.z = z;
    }

	public Ponto3D()
	{
		z = 0;
	}

    public override bool Equals(Object obj)
    { 
        if (!base.Equals(obj)) return false;
        Ponto3D p = (Ponto3D)obj;
        return z == p.z;
    }

    public override int GetHashCode() { return base.GetHashCode() ^ z; }

#if WithAuxEquals
    public bool Equals(Ponto3D p)
    {   if (!base.Equals(p)) return false;
        return z==p.z;
    }
#endif
}


class Program
{
    public static void Main(String[] args)
    {

		Ponto p2 = new Ponto(1, 2);
        Ponto3D p3 = new Ponto3D(1, 2, 3);
       
        Console.WriteLine(p3==p2);
		Console.WriteLine(p2==p3);

		Console.WriteLine(p3.Equals(p2));
		Console.WriteLine(p2.Equals(p3));

    }
}


