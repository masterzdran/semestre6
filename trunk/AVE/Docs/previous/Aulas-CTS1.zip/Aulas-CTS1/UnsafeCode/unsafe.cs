/*---------------------------------------------------------------------------------------------
 * Ilustra a utiliza��o de c�digo unsafe em C#.
 *��E poss�vel optimizar a performance d eutiliza��o de arrays (em especial arraya bidimensionais,
 * mas � custa da robustez oferecida pelo modelo de tipos e pela verifica��o. 
 * Qual o problema do c�digo?
 * 
 * Jorge Martins, 2010
 * ------------------------------------------------------------------------------------------*/

using System;

class C1 {

	unsafe public static int teste(ref int*p) {
			++p;
			return *p;
	}
	
	public static void Main() {
	   int[]  values = {1,2 , 3, 4};
		
		unsafe {
			
			int size = values.Length;
		 
			fixed(int *pi=&values[0]) {
				for (int i=0; i < size; ++i) {
					int *p2 = pi+i;
					Console.WriteLine(teste(ref p2));
				}
			}
	 
		}
		
	}
}