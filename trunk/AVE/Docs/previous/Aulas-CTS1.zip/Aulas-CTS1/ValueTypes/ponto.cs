using  System;

public struct Ponto {

	public  int x, y;
	
	public Ponto(int x, int y) { this.x=x; this.y=y; }
    
	public override String ToString()  {
		return String.Format("({0},{1})", x, y);
    }	
    
	public override bool Equals(Object obj)  {
		if (!(obj is Ponto)) return false;
		
		Ponto p = (Ponto) obj; 
		
		return Equals(p);
    }	 
    
	public static bool operator==(Ponto p1, Ponto p2) {
		// if (Object.ReferenceEquals(p1,p2)) return true;
		// if ((object)p1==null) return false;
		// return p1.Equals((object)p2);
		return object.Equals(p1,p2);
	}
	
	public static bool operator!=(Ponto p1, Ponto p2) {
		 
		return !(p1==p2);
	}
			
	public bool Equals(Ponto p)  { return x== p.x && y == p.y; }
    
    public override int GetHashCode() { return x^y; }	

};

class Program {
	public static void Main( String[] args ) {
		Ponto p1 = new Ponto(2,2), p2 = new Ponto(2,2);
		
		Type t = p1.GetType();
		Object o = p1;
		//Console.WriteLine(p1.Equals((object)null));
		Console.WriteLine(p1==null);
		Ponto p = (Ponto) o;
		p.x=3;
		Console.WriteLine(o.ToString());
	}
}

