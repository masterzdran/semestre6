/*------------------------------------------------------------------------------
 * Passagem de par�metros por valor e por refer�ncia, de inst�ncias
 * de tipos valor e tipos refer�ncia
 * 
 * Jorge Martins, 2010
 *----------------------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;

namespace RefParms
{
	// se fosse tipo valor?
    class Ponto {
        public int x, y;

        public Ponto(int x, int y) { this.x = x; this.y = y; }

        public override string ToString() { return String.Format("({0}, {1})", x, y); }


    }

    class Program
    {
        public static void swap(ref object o1, ref object o2)
        {
            object aux = o1;
            o1 = o2;
            o2 = aux;
        }

		//public static void setPoint(ref Ponto p)
		//{
		//    p = new Ponto(5,6);
		//}

		public static void setPoint(out Ponto p)
		{
		 
			p = new Ponto(5, 6);
		}
       

        public static void setPoint(Ponto p)
        {
            p = new Ponto(10, 12);
        }

		public static void setPoint2(Ponto p)
		{
			p.x = 20;
			p.y=24;
		}
        

        static void Main(string[] args)
        {
            Ponto p;

			 
            setPoint(out p);
            Console.WriteLine(p);

			setPoint( p);
			Console.WriteLine(p);

			setPoint2(p);
			Console.WriteLine(p);
 

			// se as vari�veis fossem do tipo exacto dos objectos, qual o comportamento
			// do c�digo seguinte
			object p1 = p;
			object s1 = "ola";
			object s2 = "ola1"; 
            
			swap(ref s1, ref s2 );
			Console.WriteLine("s1=" + s1);
			Console.WriteLine("s2=" + s2);

			swap(ref s1, ref p1);
			Console.WriteLine("s1=" + s1);
			Console.WriteLine("p1=" + p1);
        }
    }
}
