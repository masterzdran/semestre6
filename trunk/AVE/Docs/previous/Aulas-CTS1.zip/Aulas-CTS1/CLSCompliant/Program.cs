using System;
using System.Collections.Generic;
/*--------------------------------------------------------------------
 * Utiliza��o do atributo CLSCompliant para que o compilador confirme tratar-se
 * de c�digo compat�vel com a sregras da especifica��o CLS
 * 
 * Notem os warnings.
 * 
 * 
 * Jorge Martins, 2010
 *---------------------------------------------------------------------------*/

using System.Text;

[assembly:CLSCompliant(true)]

namespace CLSCompliant
{
    
    
    public class X
    {
        public void teste(ushort x)
        {
            Console.WriteLine(x);
        }

        public void Teste(byte x)
        {
            Console.WriteLine(x);
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
