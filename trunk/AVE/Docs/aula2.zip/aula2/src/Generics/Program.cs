﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Aula2 {

    public struct Pair<T, U> {
        public readonly T v1;
        public readonly U v2;

        public Pair(T v1, U v2)
        {
            this.v1 = v1; this.v2 = v2;
        }

        public override string ToString()
        {
            return string.Format("({0},{1})", v1.ToString(), v2.ToString());
        }

    }

    public struct Point : IComparable, IComparable<Point>, IEquatable<Point>
    {
        private int x, y;

        private double distance()
        {
            return Math.Sqrt(x * x + y * y);
        }


        public Point(int x, int y)
        {
            this.x = x; this.y = y;
        }

        public int X { get { return x; } }

        public int Y { get { return y; } }


        public int CompareTo(object obj)
        {
            if (obj.GetType() != typeof(Point))
                throw new Exception("Invalid type!");
            Point p = (Point)obj;
            return CompareTo(p);

        }

        public int CompareTo(Point p)
        {
            return (int)(distance() - p.distance());
        }

        public override String ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append('(');
            sb.Append(x);
            sb.Append(',');
            sb.Append(y);
            sb.Append(')');
            return sb.ToString();
        }

        public override bool Equals(object obj)
        {
            if (obj.GetType() != typeof(Point))
                return false;
            return Equals((Point)obj);
        }

        public override int GetHashCode()
        {
            return (int)distance();
        }

        #region IEquatable<Point> Members

        public bool Equals(Point other)
        {
            return CompareTo(other) == 0;
        }

        #endregion
    }

    static class GenericAlgorithms
    {


        public static void ForEach<T>(this IEnumerable<T> vals, Action<T> action)
        {
            foreach (T t in vals) action(t);
        }

        public static int CountIf<T>(this IEnumerable<T> c, Predicate<T> p)
        {
            int counter = 0;
            foreach (T i in c)
            {
                if (p(i)) counter++;
            }
            return counter;
        }


        public static IEnumerable<T> OrderBy<T, U>(this IEnumerable<T> e, Func<T, U> key) where U : IComparable<U>
        {
            List<T> sortContainer = new List<T>();
            ForEach(e, t => sortContainer.Add(t));
            sortContainer.Sort((p1, p2) => key(p1).CompareTo(key(p2)));
            return sortContainer;
        }


        public static IEnumerable<T> RemoveDuplicates<T>(this IEnumerable<T> vals)
        {
            List<T> res = new List<T>();
            foreach (T t in vals)
            {
                if (res.IndexOf(t) == -1)
                {
                    res.Add(t);
                    yield return t;
                }
            }
        }

    }



    class Program
    {



        static void Test1()
        {
            List<int> list = new List<int>(new int[] { 2, 5, 12, 4, 2, 3, 5, 7, 7 });



            var l = GenericAlgorithms.RemoveDuplicates(list);

            Console.WriteLine("After removing duplicates: ");
            GenericAlgorithms.ForEach(l, Console.WriteLine);
            Console.WriteLine();

            Console.WriteLine(GenericAlgorithms.CountIf(l, p => p > 5));
        }

        static void Test3()
        {
            List<Point> list = new List<Point>(new Point[] { new Point(1, 2),
                                                             new Point(3, 4),
                                                             new Point(3, 5) });

            GenericAlgorithms.ForEach(list, (i => Console.WriteLine(i)));

        }



        static void Main(string[] args)
        {
            Test1();
        }
    }
}


