﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ReflectionUtils
{
    class Program
    {

        static bool ImplementsInterface(Type t, Type iIntf){
          
          Type[] types = t.GetInterfaces();
            foreach(Type myType in types)
                if(myType.Equals(iIntf)) return true;
            return false;
        }


        static void Main(string[] args)
        {
            ArrayList a=new ArrayList();
            IList b = (IList)a;
            Console.WriteLine(a);
            Console.WriteLine(Type.GetType("System.Collections.IList"));
           Console.WriteLine( ImplementsInterface(a.GetType(), Type.GetType("System.Collections.IList")));
        }
    }
}
