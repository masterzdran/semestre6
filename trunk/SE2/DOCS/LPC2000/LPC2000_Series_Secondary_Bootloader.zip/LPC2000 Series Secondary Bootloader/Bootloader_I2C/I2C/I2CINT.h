/*
*********************************************************************************************************
** I2C master mode should be set in main application
*********************************************************************************************************
*/

#ifndef  I2CINT_H
#define  I2CINT_H

#include "lpc_types.h"

/*address byte of I2C slave*/
#define	ONE_BYTE_SUBA	1
#define TWO_BYTE_SUBA	2
#define X_ADD_8_SUBA	3


extern UNS_8 I2C_ReadNByte (UNS_8 sla, UNS_32 suba_type, UNS_32 suba, UNS_8 *s, UNS_32 num);
extern UNS_8 I2C_WriteNByte(UNS_8 sla, UNS_8 suba_type, UNS_32 suba, UNS_8 *s, UNS_32 num);
extern UNS_8 I2C_Init( UNS_32 fi2c ) ;
extern void __irq IRQ_I2C(void);

#endif


