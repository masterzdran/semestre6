#ifndef _BL_CAN_H
#define _BL_CAN_H

#include "can.h"


// for CAN interface
CAN_MSG MsgBuf_TX1, MsgBuf_TX2; // TX and RX Buffers for CAN message
CAN_MSG MsgBuf_RX1, MsgBuf_RX2; // TX and RX Buffers for CAN message
volatile unsigned int CAN1RxDone, CAN2RxDone;

#define CAN_BLOCK_SIZE 8	// send 2 dword(8 bytes) each time via can interface

#define DEFAULT_SRC_AP_CAN_ADDR 0x60000;	//sector 19
#define MAX_USER_PROG_SZ  0x8000 //32KB
#endif
