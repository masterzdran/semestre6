/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2009

	API para comunica��o em protocolo I2C
*/
#ifndef I2C_H
#define I2C_H

#include <stddef.h>
#include "types.h"

void i2c_init();
void i2c_start();
void i2c_stop();
void i2c_write_byte(U8 value);
int i2c_slave_ack();
U8 i2c_read_byte();
void i2c_master_ack();
void i2c_master_nack();

#endif
