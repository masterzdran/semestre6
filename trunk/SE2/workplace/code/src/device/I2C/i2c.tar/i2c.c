/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2009

	Protocolo I2C sobre o GPIO
*/
#include "i2c.h"
#include "io.h"
#include "lpc2106.h"
#include "chrono.h"
		
/*
	P0.2 e P0.3 s�o sa�das em colector aberto

                       ^
					   |
                       \
                       /
	GPIO			   \		i2c device
	+-------+          /		+-------+
    |		|		   |		|		|
	|	P0.3|----------*--------|SDA    |
    |	P0.2|-------------------|SCL	|
    |		|			   		|		|
    |	    |                   +-------+
    |		|
    +-------+
*/

#define SCL_PIN		2
#define SDA_PIN		3

static U32 usec_5;

void i2c_start() {
	/* Colocar ambos a 1 */
	io_write_u32(LPC210X_GPIO + LPC2XXX_IOSET, (1 << SDA_PIN) | (1 << SCL_PIN));
	
	chrono_micro_delay(usec_5);						/* Start Setup Time */
	/* Primeiro a data ... */
	io_write_u32(LPC210X_GPIO + LPC2XXX_IOCLR, 1 << SDA_PIN);
	
	chrono_micro_delay(usec_5);						/* Start Hold Time */
	/* ... e depois o clock */
	io_write_u32(LPC210X_GPIO + LPC2XXX_IOCLR, 1 << SCL_PIN);
}

void i2c_stop() {
	/* Colocar ambos a 0 */
	io_write_u32(LPC210X_GPIO + LPC2XXX_IOCLR, (1 << SDA_PIN) | (1 << SCL_PIN));
	
	chrono_micro_delay(usec_5);

	/* Primeiro o clock ... */
	io_write_u32(LPC210X_GPIO + LPC2XXX_IOSET, 1 << SCL_PIN);
	
	chrono_micro_delay(usec_5);						/* Stop Hold Time */
	/* ... e depois a data	*/
	io_write_u32(LPC210X_GPIO + LPC2XXX_IOSET, 1 << SDA_PIN);
}

static void write_bit(U8 d) {
	/* Colocar em SDA o valor a escrever */
	io_write_u32(LPC210X_GPIO + ((d & 1) ? LPC2XXX_IOSET : LPC2XXX_IOCLR),
		1 << SDA_PIN);

	/* Clock Pulse Width Low */ /* Data In Setup Time - 100 ns */
	chrono_micro_delay(usec_5);
		
	/* Gerar um impulso em SCL */ 
	io_write_u32(LPC210X_GPIO + LPC2XXX_IOSET, 1 << SCL_PIN);
	
	chrono_micro_delay(usec_5);	/* Clock Pulse Width High */
	io_write_u32(LPC210X_GPIO + LPC2XXX_IOCLR, 1 << SCL_PIN);
				/* Data In Hold Time - 0 ns */
}

static U8 read_bit() {
	/* Colocar em alta-impedancia para aceitar os dados impostos pelo dispositivo */
	io_write_u32(LPC210X_GPIO + LPC2XXX_IOSET, 1 << SDA_PIN);

	/* Clock Pulse Width Low */
	chrono_micro_delay(usec_5);

	/* Gerar um impulso em SCL */ 
	io_write_u32(LPC210X_GPIO + LPC2XXX_IOSET, 1 << SCL_PIN);
	
	chrono_micro_delay(usec_5);		/* Clock Pulse Width High */
	U32 tmp = io_read_u32(LPC210X_GPIO + LPC2XXX_IOPIN);
	io_write_u32(LPC210X_GPIO + LPC2XXX_IOCLR, 1 << SCL_PIN);	
	return (tmp >> SDA_PIN) & 1;
}

int i2c_slave_ack() { return read_bit(); }

void i2c_master_ack() { write_bit(0); }

void i2c_master_nack() { write_bit(1); }

void i2c_write_byte(U8 data) {
	int i;
	for (i = 0; i < 8; ++i)
		write_bit(data >> (7 - i));
}

U8 i2c_read_byte() {
	U8 tmp = 0;
	int i;
	for (i = 0; i < 8; ++i) {
		tmp = (tmp << 1) + read_bit();
	}
	return tmp;
}

void i2c_init() {
	U32 pinsel = io_read_u32(LPC210X_PCB + LPC2XXX_PINSEL0);
	io_write_u32(LPC210X_PCB + LPC2XXX_PINSEL0, pinsel &
		LPC2XXX_PINSEL0_GPIO(SDA_PIN) &	LPC2XXX_PINSEL0_GPIO(SCL_PIN));

	io_write_u32(LPC210X_GPIO + LPC2XXX_IOSET, (1 << SDA_PIN) | (1 << SCL_PIN));
	
	U32 iodir = io_read_u32(LPC210X_GPIO + LPC2XXX_IODIR);
	io_write_u32(LPC210X_GPIO + LPC2XXX_IODIR, iodir | (1 << SDA_PIN) | (1 << SCL_PIN));
	
	usec_5 = usec2tic(5);
}


