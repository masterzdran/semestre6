#include <cyg/hal/hal_diag.h>
#include <cyg/infra/diag.h>
#include <cyg/kernel/kapi.h>
#include <stdio.h>
#include "ir.h"

#define IR_THREAD_STACK_SIZE (8192 / sizeof(int))
int ir_thread_stack[IR_THREAD_STACK_SIZE];

cyg_handle_t ir_thread_handle;
cyg_thread ir_thread_obj;

void ir_test_thread(cyg_addrword_t data) {
	cyg_uint32 code;
	diag_printf("ir_thread()\n");
	
	while (true) {
		code = ir_read();
		diag_printf("IR = %08x\n", code);
	}
}

int main() {
	diag_printf("IR test 4\n");
	cyg_thread_create(12, ir_test_thread, 0, "Infra red thread",
		&ir_thread_stack, IR_THREAD_STACK_SIZE,
		&ir_thread_handle, &ir_thread_obj);
	cyg_thread_resume(ir_thread_handle);
	return 0;
}

void cyg_user_start() {
	ir_init();
}

