#ifndef IR_H
#define IR_H

void ir_init();
cyg_uint32 ir_read();

#endif
