#include <cyg/hal/hal_diag.h>
#include <cyg/infra/diag.h>
#include <cyg/kernel/kapi.h>
#include <stdio.h>
#include "debugbit.h"
#include "chrono.h"
#include "ir.h"

//	IR receiver connected to CAP1.1/P0.11

#define IR_INTERRUPT	CYGNUM_HAL_INTERRUPT_TIMER1
#define IR_BIT			11

static void measure_init() {
	cyg_uint32 pinsel;
	HAL_READ_UINT32(CYGARC_HAL_LPC2XXX_REG_PIN_BASE +
		CYGARC_HAL_LPC2XXX_REG_PINSEL0, pinsel);
	HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_PIN_BASE +
		CYGARC_HAL_LPC2XXX_REG_PINSEL0,
			(pinsel & ~(3 << IR_BIT * 2)) | (2 << IR_BIT * 2));
			
	CYG_ADDRESS timer = CYGARC_HAL_LPC2XXX_REG_TIMER1_BASE;

	// Disable and reset counter
    HAL_WRITE_UINT32(timer + CYGARC_HAL_LPC2XXX_REG_TxTCR,
		CYGARC_HAL_LPC2XXX_REG_TxTCR_CTR_RESET);
    
	//set prescale register to 0
    HAL_WRITE_UINT32(timer + CYGARC_HAL_LPC2XXX_REG_TxPR, 10);			

    // Enable counter
    HAL_WRITE_UINT32(timer+CYGARC_HAL_LPC2XXX_REG_TxTCR, 
		CYGARC_HAL_LPC2XXX_REG_TxTCR_CTR_ENABLE);
	
	//	Capture TC in both transitions and generate interrupt
	HAL_WRITE_UINT32(timer + CYGARC_HAL_LPC2XXX_REG_TxCCR,
		CYGARC_HAL_LPC2XXX_REG_TxCCR_INT_CR1_RISE |
			CYGARC_HAL_LPC2XXX_REG_TxCCR_INT_CR1_FALL |
				CYGARC_HAL_LPC2XXX_REG_TxCCR_INT_CR1);
}

static cyg_uint32 time_stamp;

static inline void measure_start() {
	HAL_READ_UINT32( CYGARC_HAL_LPC2XXX_REG_TIMER1_BASE + 
		CYGARC_HAL_LPC2XXX_REG_TxCR1, time_stamp);
}

static inline cyg_uint32 measure_elapsed() {
	cyg_uint32 current;
	HAL_READ_UINT32( CYGARC_HAL_LPC2XXX_REG_TIMER1_BASE + 
		CYGARC_HAL_LPC2XXX_REG_TxCR1, current);
	return current - time_stamp;
}

static inline void measure_restart(cyg_uint32 delta) {
	time_stamp += delta;
}

#define CYGNUM_HAL_PRI_HIGH		1
static cyg_handle_t		ir_interrupt_handle;
static cyg_interrupt	ir_interrupt_obj;
static cyg_handle_t		ir_mbox_handle;
static cyg_mbox			ir_mbox_obj;
static cyg_handle_t		ir_alarm_handle;
static cyg_alarm		ir_alarm_obj;

static cyg_uint32 ir_isr(cyg_vector_t vector, cyg_addrword_t data) {
	cyg_interrupt_mask(vector);
	cyg_interrupt_acknowledge(vector);
	return (CYG_ISR_HANDLED | CYG_ISR_CALL_DSR);
}

static struct {
	int state;
	int time;
	int half_period;
	int n;
	cyg_uint32 data;
} trace [50];
static int idx;

static int state;

static void ir_dsr(cyg_vector_t v, cyg_ucount32 c, cyg_addrword_t d) {
	static cyg_uint32 half_period, time;
	static int data, n;
	cyg_tick_count_t tics;
	cyg_tick_count_t now;

	bit_toggle();
	switch (state) {
		case 0:
			measure_start();
			n = 11;
			data = 0;
	idx = 0;
	trace[idx].state = state;
	trace[idx].data = data;
	trace[idx++].n = n;
			state = 1;
			tics = nsec2tic(40 * 1000000);
			now = cyg_current_time();
			cyg_alarm_initialize(ir_alarm_handle, now + tics, 0);
			break;
		case 1:
			half_period = measure_elapsed();
			measure_restart(half_period);
	trace[idx].state = state;
	trace[idx].half_period = half_period;
	trace[idx].data = data;
	trace[idx].n = n;
	trace[idx++].time = half_period;
			state = 2;
			break;
		case 2:
			time = measure_elapsed();
			measure_restart(time);
			half_period = (half_period + time) / 2;
	trace[idx].state = state;
	trace[idx].time = time;
	trace[idx].data = data;
	trace[idx].n = n;
	trace[idx++].half_period = half_period;
			state = 3;
			break;
		case 3:
			time = measure_elapsed();
			measure_restart(time);
	trace[idx].state = state;
	trace[idx].time = time;
	trace[idx].data = data;
	trace[idx].n = n;
			cyg_uint32 tolerance = half_period / 2;
			cyg_uint32 period = half_period * 2;
			if (time > (period - tolerance)) {
				if (time < (period + tolerance)) {
					state = n > 0 ? 5 : 9;
					n--;	//	data = 0
					half_period = (half_period + time) / 3;
				}
				else
					goto erro;
			}
			else if (time <= (half_period + tolerance)) {
				if (time >= half_period - tolerance) {
					state = 4;
					half_period = (half_period + time) / 2;
				}
				else
					goto erro;
			}
				
	trace[idx++].half_period = half_period;
			break;
		case 4: {
			time = measure_elapsed();
			measure_restart(time);
	trace[idx].state = state;
	trace[idx].data = data;
	trace[idx].n = n;
	trace[idx].time = time;
			cyg_uint32 tolerance = half_period / 2;
			if (time > (half_period + tolerance) ||
				(time < (half_period - tolerance)))
				goto erro;
			state = n > 0 ? 3 : 7;
			data |= 1 << n--;	
			half_period = (half_period + time) / 2;
	trace[idx++].half_period = half_period;
			break;
		}
		case 5: {
			time = measure_elapsed();
			measure_restart(time);
	trace[idx].state = state;
	trace[idx].data = data;
	trace[idx].n = n;
	trace[idx].time = time;
			cyg_uint32 tolerance = half_period / 2;
			cyg_uint32 period = half_period * 2;
			if (time > (period - tolerance)) {
				if (time < (period + tolerance)) {
					state = n > 0 ? 3 : 7;
					data |= 1 << n--;
					half_period = (half_period + time) / 3;
				}
				else
					goto erro;
			}
			else if (time <= (period - tolerance)) {
				if (time >= half_period - tolerance) {
					state = 6;
					half_period = (half_period + time) / 2;
				}
				else
					goto erro;
			}
	trace[idx++].half_period = half_period;
			break;
		}
		case 6: {
			time = measure_elapsed();
			measure_restart(time);
	trace[idx].state = state;
	trace[idx].data = data;
	trace[idx].n = n;
	trace[idx].time = time;
			cyg_uint32 tolerance = half_period / 2;
			if (time > (half_period + tolerance) ||
				(time < (half_period - tolerance)))
				goto erro;
			state = n > 0 ? 5 : 9;
			--n;	//	data = 0
			half_period = (half_period + time) / 2;
	trace[idx++].half_period = half_period;
			break;
		}
		case 7: {
			time = measure_elapsed();
	trace[idx].state = state;
	trace[idx].data = data;
	trace[idx].n = n;
	trace[idx].time = time;
			cyg_uint32 tolerance = half_period / 2;
			if (time > (half_period + tolerance) ||
				(time < (half_period - tolerance)))
				goto erro;
			state = 9;
	trace[idx++].half_period = half_period;
			break;
		}
		case 8:
		erro:
			state = 8;
			;	//	situa��o de erro
	}
	if (state == 9) {
		cyg_alarm_disable(ir_alarm_handle);
		state = 0;
		cyg_mbox_tryput(ir_mbox_handle, (void *)data);
	}
	HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_TIMER1_BASE +
		CYGARC_HAL_LPC2XXX_REG_TxIR, CYGARC_HAL_LPC2XXX_REG_TxIR_CR1);
	cyg_interrupt_unmask(IR_INTERRUPT);
}

static void ir_alarm_handler(cyg_handle_t handle, cyg_addrword_t data) {
	state = 0;
}

void ir_init() {
	cyg_handle_t		sys_counter_handle;

	cyg_handle_t sys_clk_handle = cyg_real_time_clock();
	cyg_clock_to_counter(sys_clk_handle, &sys_counter_handle);
	cyg_alarm_create(sys_counter_handle, ir_alarm_handler, 0, &ir_alarm_handle, &ir_alarm_obj);
	
	cyg_mbox_create(&ir_mbox_handle, &ir_mbox_obj);

	cyg_interrupt_create(IR_INTERRUPT, CYGNUM_HAL_PRI_HIGH, 0,
		&ir_isr, &ir_dsr, &ir_interrupt_handle, &ir_interrupt_obj);
	cyg_interrupt_attach(ir_interrupt_handle);
//    cyg_interrupt_configure(IR_INTERRUPT, false, false);
	cyg_interrupt_acknowledge(IR_INTERRUPT);

	measure_init();
	
	bit_init();

	cyg_interrupt_unmask(IR_INTERRUPT);
}

cyg_uint32 ir_read() {
	return (cyg_uint32) cyg_mbox_get(ir_mbox_handle);
}
