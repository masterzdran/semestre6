/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2009
	
	Buffer de caracteres com disciplina FIFO e acesso ao bloco
*/

#include <assert.h>
#include <string.h>
#include "fbuffer.h"
#include "defs.h"

/*------------------------------------------------------------------------------
	Operações de escrita
*/

void fbuffer_write_char(Fbuffer * b, char c) {
    *b->put = c;
    if (++b->put == b->data_end)
        b->put = b->data;
    ++b->count_put;
}

size_t fbuffer_write_block(Fbuffer * b, char * data, size_t size) {
    size_t n_bytes1 = min(fbuffer_write_block_size(b), size);
   	memcpy(fbuffer_write_block_ptr(b), data, n_bytes1);
    fbuffer_write_seek(b, n_bytes1);
    size -= n_bytes1;
	if (size == 0)
		return n_bytes1;
    size_t n_bytes2 = min(fbuffer_write_block_size(b), size);
   	memcpy(fbuffer_write_block_ptr(b), data + n_bytes1, n_bytes2);
    fbuffer_write_seek(b, n_bytes2);
    size -= n_bytes2;
    return n_bytes1 + n_bytes2;
}

void fbuffer_write_seek(Fbuffer * b, size_t n) {
	assert(b->put < b->data_end);
    b->put += n;
    if (b->put >= b->data_end)
        b->put -= b->size;
    b->count_put += n;
	assert(b->put < b->data_end);
}

/*------------------------------------------------------------------------------
	Operações de leitura
*/

char fbuffer_read_char(Fbuffer * b) {
    char c = *b->get;
    if(++b->get == b->data_end)
        b->get = b->data;
    ++b->count_get;
    return c;
}

size_t fbuffer_read_block(Fbuffer * b, char * buffer, size_t size) {
    size_t n_bytes1 = min(fbuffer_read_block_size(b), size);
   	memcpy(buffer, fbuffer_read_block_ptr(b), n_bytes1);
    fbuffer_read_seek(b, n_bytes1);
    size -= n_bytes1;
	if (size == 0)
		return n_bytes1;
    size_t n_bytes2 = min(fbuffer_read_block_size(b), size);
   	memcpy(buffer + n_bytes1, fbuffer_read_block_ptr(b), n_bytes2);
    fbuffer_read_seek(b, n_bytes2);
    size -= n_bytes2;
    return n_bytes1 + n_bytes2;
}

void fbuffer_read_seek(Fbuffer * b, size_t n) {
	assert(b->get < b->data_end);
    b->get += n;
    if (b->get >= b->data_end)
        b->get -= b->size;
    b->count_get += n;
	assert(b->get < b->data_end);
}

