/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2009
	
	Gestor de porta s�rie por interrup��o
*/

#ifndef SERIAL_H
#define SERIAL_H

#include "fbuffer.h"
#include "types.h"

typedef struct {
	Fbuffer * rx_buffer, * tx_buffer;
	U32 addr;
	int irq;
	int tx_stopped;
} Serial;

#define DEFINE_SERIAL(name, uart, intr)		\
DEFINE_FBUFFER(rx_buffer_##name, 100);		\
DEFINE_FBUFFER(tx_buffer_##name, 100);		\
static Serial name = {&rx_buffer_##name, &tx_buffer_##name, uart, intr}

void serial_init(Serial * serial, long baud, int dbits, int sbits, char parity);
void serial_write_char(Serial * serial, U8 c);
U8 serial_read_char(Serial * serial);
size_t serial_write_block(Serial * serial, const U8 * data, size_t size);
size_t serial_read_block(Serial * serial, U8 * buffer, size_t size);
size_t serial_size(Serial * serial);

#endif
