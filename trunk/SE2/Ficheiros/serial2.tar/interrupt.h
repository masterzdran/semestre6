/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2009
	
	Interface para manipula��o do sistema de interrup��es
*/
#ifndef INTERRUPT_H
#define INTERRUPT_H

typedef void (*Isr)(void*);

void interrupt_init();
void interrupt_set_isr(int number, Isr isr, void * obj);
void interrupt_mask(int number);
void interrupt_unmask(int number);
void interrupt_configure(int number, int edge, int direction);
void interrupt_priority(int number, int priority);
void interrupt_end();
void interrupt_enable();
void interrupt_disable();
int interrupt_save_disable();
void interrupt_restore(int);

#define NESTED

#endif
