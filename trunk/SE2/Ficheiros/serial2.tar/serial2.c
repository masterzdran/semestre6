/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2009
	
	Gestor de porta s�rie por interrup��o para UART da fam�lia 8250
*/
#include "lpc2106.h"
#include "io.h"
#include "serial2.h"
#include "interrupt.h"

void serial_isr(Serial * serial) {
	U32 iir = io_read_u32(serial->addr + LPC2XXX_UxIIR);
	while ( (iir & LPC2XXX_UxIIR_Pending) == 0) {
        switch (iir & LPC2XXX_UxIIR_MASK) {
			case LPC2XXX_UxIIR_RDA:	{	/* Receiver data available */
				U8 c = io_read_u32(serial->addr + LPC2XXX_UxRBR);
				fbuffer_write_char(serial->rx_buffer, c);
				if (fbuffer_full(serial->rx_buffer)) {
					U32 aux = io_read_u32(serial->addr + LPC2XXX_UxIER);
					io_write_u32(serial->addr + LPC2XXX_UxIER, aux & ~LPC2XXX_UxIER_RXDATA);
				}
				break;
			}
			case LPC2XXX_UxIIR_THRE: {	/* THRE interrupt */
				if ( ! fbuffer_empty(serial->tx_buffer)) {
					U8 c = fbuffer_read_char(serial->tx_buffer);
					io_write_u32(serial->addr + LPC2XXX_UxTHR, c);
				}
				else
					serial->tx_stopped = 1;
			}
		}
		iir = io_read_u32(serial->addr + LPC2XXX_UxIIR);
    }
    interrupt_end();
}

void serial_write_char(Serial * serial, U8 c) {
	while (fbuffer_full(serial->tx_buffer))
		;
	fbuffer_write_char(serial->tx_buffer, c);
	if (serial->tx_stopped) {
		serial->tx_stopped = 0;
		U8 c = fbuffer_read_char(serial->tx_buffer);
		io_write_u32(serial->addr + LPC2XXX_UxTHR, c);
	}
}

size_t serial_write_block(Serial * serial, const U8 * data, size_t size) {
	int i;
	for (i = 0; i < size; ++i) {
		while (fbuffer_full(serial->tx_buffer))
			;
		fbuffer_write_char(serial->tx_buffer, *data++);
	}
	if (serial->tx_stopped) {
		serial->tx_stopped = 0;
		U8 c = fbuffer_read_char(serial->tx_buffer);
		io_write_u32(serial->addr + LPC2XXX_UxTHR, c);
	}
    return size;
}

U8 serial_read_char(Serial * serial) {
	while (fbuffer_empty(serial->rx_buffer))
      	;
	U8 c = fbuffer_read_char(serial->rx_buffer);
	U32 aux = io_read_u32(serial->addr + LPC2XXX_UxIER);
	io_write_u32(serial->addr + LPC2XXX_UxIER, aux | LPC2XXX_UxIER_RXDATA);
    return c;	
}

size_t serial_read_block(Serial * serial, U8 * buffer, size_t size) {
	int i;
    for (i = 0; i < size; ++i) {
		while (fbuffer_empty(serial->rx_buffer))
			;
		*buffer++ = fbuffer_read_char(serial->rx_buffer);
	}
	U32 aux = io_read_u32(serial->addr + LPC2XXX_UxIER);
	io_write_u32(serial->addr + LPC2XXX_UxIER, aux | LPC2XXX_UxIER_RXDATA);
	return size;
}

size_t serial_size(Serial * serial) {
	return fbuffer_count(serial->rx_buffer);
}

void serial_init(Serial * serial, long baud, int dbits, int sbits, char parity) {
	serial->tx_stopped = 1;

    /* Calcular e programar o factor de divisao para o Baud Rate */
    unsigned br_factor = PCLK / (baud << 4);
    if ((br_factor) == 0)
        br_factor = 1;
    io_write_u32(serial->addr + LPC2XXX_UxLCR, LPC2XXX_UxLCR_DLAB);
	io_write_u32(serial->addr + LPC2XXX_UxDLL, br_factor);
    io_write_u32(serial->addr + LPC2XXX_UxDLM, br_factor >> 8);

    /* Definir conteudo de LCR funcao do valor dos argumentos. */
    char aux = dbits >= 5 && dbits <= 8 ?
		LPC2XXX_UxLCR_WORD_LENGTH_5 + (dbits - 5) : LPC2XXX_UxLCR_WORD_LENGTH_8;
    if (sbits == 2)
        aux |= LPC2XXX_UxLCR_STOP_2;
    aux |= parity == 'e' ?
		LPC2XXX_UxLCR_PARITY_EVEN : parity == 'o' ? LPC2XXX_UxLCR_PARITY_ENA : 0;
    io_write_u32(serial->addr + LPC2XXX_UxLCR, aux);
	
	/*  Activar interrup��o de recep��o, a de transmiss�o */
  	io_write_u32(serial->addr + LPC2XXX_UxIER, LPC2XXX_UxIER_RXDATA | LPC2XXX_UxIER_THRE);

	/* Instalar rotina de interrup��o */
	interrupt_set_isr(serial->irq, (Isr)serial_isr, serial);
	interrupt_unmask(serial->irq);
}
