/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2009
*/
#include <stdio.h>
#include <stdarg.h>
#include <ctype.h>
#include "console.h"
#include "serial.h"
#include "lpc2106.h"
#include "io.h"
#include "defs.h"

void console_dump_hex (U8 * buffer, size_t size) {
	U16 total = 0;
	char line[74], * pl1, * pl2;
	U8 * p = buffer;
	while (size > 0) {
		int i;
		memset(line, ' ', sizeof line - 1);
		pl1 = line;
		pl2 = line + 55;
		line[sizeof line - 3] = '\n';
		line[sizeof line - 2] = '\r';
		line[sizeof line - 1] = '\0';
		pl1 += sprintf(pl1, "%04X: ", total);
		size_t nBytes = min((size_t)16, size);
		for (i = 0; i < nBytes; ++i, ++p) {
			pl1 += sprintf(pl1, "%02X ", *p);
			*pl2++ = (isprint(*p) && *p != '\t' &&
				*p != '\r' && *p != '\n' && *p != '\xc') ? *p : '.';
		}
		*pl1 = ' ';
		console_write_block(line, sizeof(line));
		total += nBytes;
		size -= nBytes;
	}
}

int console_printf(const char * fmt, ...) {
	char buf[256];
	va_list vlp;
	size_t r;
	va_start(vlp, fmt);
	if( (r = vsprintf(buf, fmt, vlp)) >= sizeof(buf) )
		console_write_block("ERROR: vsprintf - insufficient buffer size!\r\n", 46);
	console_write_block(buf, r);
	return r;
}

int console_vprintf(const char * fmt, va_list vlp) {
	char buf[256];
	size_t r;
	if( (r = vsprintf(buf, fmt, vlp)) >= sizeof(buf) )
		console_write_block("ERROR: vsprintf - insufficient buffer size!\r\n", 46);
	console_write_block(buf, r);
	return r;
}

#include <_stdio.h>

static int scan_read_char(void * str, int ch) {
	static char buffer[10];
	static int count = 0;
	if (ch == _WANT)
		if (count > 0)
			return buffer[--count];
		else
			return console_read_char();
	else if (ch >= 0)
		buffer[count++] = ch;
	return ch;
}

int console_scanf(const char *fmt, ...) {
	va_list vlp;

	va_start(vlp, fmt);
	return _scanf(scan_read_char, (void *) 0, fmt, vlp);
}

/*---------------------------------------------------------------------------*/

size_t console_write_block(const char * data, size_t size) {
 	serial_write_block(LPC210X_UART0, (U8*)data, size);
	return size;
}

void console_write_str(const char * str) {
	size_t size = strlen(str);
  	serial_write_block(LPC210X_UART0, (U8*)str, size);
}

void console_write_char(const char c) {
	serial_write_char(LPC210X_UART0, c);
}

char console_read_char() {
	return serial_read_char(LPC210X_UART0);
}

size_t console_read_block(char * buffer, size_t size) {
	return serial_read_block(LPC210X_UART0, (U8*) buffer, size);
}

size_t console_size() {
	return serial_size(LPC210X_UART0);
}

void console_init() {
	// switch on UART clock
	U32 aux = io_read_u32(LPC210X_SCB + LPC2XXX_PCONP);
	io_write_u32(LPC210X_SCB + LPC2XXX_PCONP, aux | LPC2XXX_PCONP_URT0);
	//	connect TxD0 and RxD0
	aux = io_read_u32(LPC210X_PCB + LPC2XXX_PINSEL0);
	io_write_u32(LPC210X_PCB + LPC2XXX_PINSEL0, 
		aux | LPC2XXX_PINSEL_TXD0 | LPC2XXX_PINSEL_RXD0);
	serial_init(LPC210X_UART0, 57600, 8, 1, 'n');
}

