/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2009
*/
#ifndef SERIAL_H
#define SERIAL_H

void serial_init(U32 uart, long baud, int dbits, int sbits, char parity);
void serial_write_char(U32 uart, U8 c);
U8 serial_read_char(U32 uart);
size_t serial_write_block(U32 uart, const U8 * data, size_t size);
size_t serial_read_block(U32 uart, U8 * buffer, size_t size);
size_t serial_size(U32 uart);
#endif
