/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2008

	Uart polling driver
*/

#include "types.h"
#include "io.h"
#include "lpc2106.h"
#include "serial.h"

void serial_init(U32 uart_base_address,
			long baud_rate,       
			int	data_bits,		// 5, 6, 7, 8
			int stop_bits,		// 1, 2
			char parity)		// 'e', 'o', 'n'
{
    // Desactivar todas as fontes de interrup��o
    io_write_u32(uart_base_address + LPC2XXX_UxIER, 0);

    // Calcular o factor de divisao para o Baud Rate
    unsigned br_factor = PCLK / (baud_rate * 16);
    if ((br_factor) == 0)
        br_factor = 1;

    // Programar o factor de divisao correspondente ao Baud Rate
    io_write_u32(uart_base_address + LPC2XXX_UxLCR, LPC2XXX_UxLCR_DLAB);
	io_write_u32(uart_base_address + LPC2XXX_UxDLL, br_factor);
    io_write_u32(uart_base_address + LPC2XXX_UxDLM, br_factor >> 8);

    // Calcular conteudo do LCR funcao do valor dos argumentos.

    char aux = data_bits >= 5 && data_bits <= 8 ?
		LPC2XXX_UxLCR_WORD_LENGTH_5 + (data_bits - 5) : LPC2XXX_UxLCR_WORD_LENGTH_8;
    if (stop_bits == 2)
        aux |= LPC2XXX_UxLCR_STOP_2;
    aux |= parity == 'e' ?
		LPC2XXX_UxLCR_PARITY_EVEN : parity == 'o' ? LPC2XXX_UxLCR_PARITY_ENA : 0;

    //  Definir o valor do Line Control Register
    io_write_u32(uart_base_address + LPC2XXX_UxLCR, aux);
}

U8 serial_read_char(U32 uart_base_address) {
	U32 aux;
	do {
		aux = io_read_u32(uart_base_address + LPC2XXX_UxLSR);
	} while ((aux & LPC2XXX_UxLSR_RDR) == 0);
	return io_read_u32(uart_base_address + LPC2XXX_UxRBR);
}

void serial_write_char(U32 uart_base_address, U8 c)  {
	U32 aux;
	do {
		aux = io_read_u32(uart_base_address + LPC2XXX_UxLSR);
	} while ((aux & LPC2XXX_UxLSR_THRE) == 0);
	io_write_u32(uart_base_address + LPC2XXX_UxTHR, c);
}

size_t serial_write_block(U32 uart_base_address, const U8 * data, size_t size) {
	int i;
	for (i = 0; i < size; ++i) {
		U32 aux;
		do {
			aux = io_read_u32(uart_base_address + LPC2XXX_UxLSR);
		} while ((aux & LPC2XXX_UxLSR_THRE) == 0);
		io_write_u32(uart_base_address + LPC2XXX_UxTHR, *data++);
	}
    return size;
}

size_t serial_read_block(U32 uart_base_address, U8 * buffer, size_t size) {
	int i;
    for (i = 0; i < size; ++i) {
		U32 aux;
		do {
			aux = io_read_u32(uart_base_address + LPC2XXX_UxLSR);
		} while ((aux & LPC2XXX_UxLSR_RDR) == 0);
		*buffer++ = io_read_u32(uart_base_address + LPC2XXX_UxRBR);
	}
	return size;
}

size_t serial_size(U32 uart_base_address) {
	return (io_read_u32(uart_base_address + LPC2XXX_UxLSR) & LPC2XXX_UxLSR_RDR) ? 1 : 0;
}
