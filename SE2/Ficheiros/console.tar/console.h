/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2009
*/
#ifndef CONSOLE_H
#define CONSOLE_H

#include <stdarg.h>
#include <string.h>
#include "types.h"
#include "serial.h"

void console_init();
void console_write_char(char c);
size_t console_write_block(const char * data, size_t size);
void console_write_str(const char * str);
int console_printf(const char * fmt, ...);
int console_vprintf(const char * fmt, va_list vlp);
void console_dump_hex(U8 * buffer, size_t size);

char console_read_char();
size_t console_read_block(char * buffer, size_t size);
int console_scanf(const char *fmt, ...);
size_t console_size();

#endif
