#ifndef __STDLIB_H
#define __STDLIB_H

unsigned long _stoul(const char * s, char * * endptr, int base);

#endif
