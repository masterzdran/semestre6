#ifndef _GLOBAL_H
#define _GLOBAL_H

#ifndef	min
#define min(a, b)	((a) < (b) ? (a) : (b))
#endif

#ifndef	size
#define	size(x)	(sizeof(x) / sizeof(x[0]))
#endif

#endif
