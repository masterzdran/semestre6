#include <assert.h>
#include <stdlib.h>

void _assert(char * msg) {
	abort();
}
