#include <time.h>

clock_t clock(void) {
	return 0;	/* Target dependent */
}
