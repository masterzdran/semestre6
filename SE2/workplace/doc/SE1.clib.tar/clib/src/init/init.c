extern void malloc_init();

void clib_init() {
	malloc_init();
}