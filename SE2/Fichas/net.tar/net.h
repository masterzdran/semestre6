/*	Instituto Superior de Engenharia de	Lisboa
	Ezequiel Conde,	2010
*/

#ifndef NETWORK_H
#define NETWORK_H

#include "uip.h"
#include "fbuffer.h"

typedef struct {
	char state;
#define FREE_MASK			0	/* Free position */
#define	ACCEPT_MASK			1	/* Ready to accept connection */
#define	CONNECT_MASK		2	/* Connection resquested */
#define	CONNECTED_MASK		3	/* Connected socket */
#define	CLOSE_MASK			4	/* Connection close request */
	uip_ipaddr_t	laddress;		/* local endpoint address */
	u16_t			lport;
	uip_ipaddr_t	raddress;		/* remote endpoint address */
	u16_t			rport;
	Fbuffer 		istream,		/* input data buffer */
					ostream;		/* output data buffer */
	size_t			sent_size;		/* To retransmitions */
	char *			sent_ptr;
	struct uip_conn * uip_conn;		/* Related connection in UIP */
} Socket;

Socket * net_server_accept(int port);
Socket * net_client_connect(char * server, int port);
size_t net_send_block(Socket * sock, char * buffer, size_t length);
void net_send_char(Socket * sock, char c);
size_t net_recv_block(Socket * sock, char * buffer, size_t length);
char net_recv_char(Socket * sock);
void net_close(Socket * sock);
void net_init(void);

#endif
