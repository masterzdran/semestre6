/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2009
	
	Buffer de caracteres com disciplina FIFO
*/

#ifndef FBUFFER_H
#define FBUFFER_H

#include <stdlib.h>
#include "utils.h"

typedef struct {
	char * data;
	char * data_end;
	char * put;
	char * get;
	int size;
	int count_put;
	int count_get;
} Fbuffer;

#define DEFINE_FBUFFER(name, size)		\
	static char fbuffer_data_##name[size];	\
	Fbuffer name = \
		{fbuffer_data_##name, &fbuffer_data_##name[size], \
			 fbuffer_data_##name, fbuffer_data_##name, size, 0, 0}
			 
static inline void fbuffer_init(Fbuffer * b, char * buffer, size_t size) {
	b->data = b->put = b->get = buffer; b->data_end = buffer + size;
	b->size = size;
	b->count_put = b->count_get = 0;
}
static inline void fbuffer_reset(Fbuffer * b) {
	b->put = b->get = b->data;
	b->count_put = b->count_get = 0;
}
static inline int fbuffer_count(Fbuffer * b) { return b->count_put - b->count_get; }
static inline int fbuffer_empty(Fbuffer * b) { return b->count_put == b->count_get; }
static inline int fbuffer_full(Fbuffer * b) { return fbuffer_count(b) == b->size; }
static inline int fbuffer_free(Fbuffer * b) { return b->size - fbuffer_count(b); }

static inline char * fbuffer_write_block_ptr(Fbuffer * b) { return b->put; }        
static inline size_t fbuffer_write_block_size(Fbuffer * b)
	{ return min(fbuffer_free(b), b->data_end - b->put); }
void fbuffer_write_char(Fbuffer * b, char c);
void fbuffer_write_seek(Fbuffer * b, size_t n);        
size_t fbuffer_write_block(Fbuffer * b, char * buffer, size_t size);

static inline char fbuffer_peek_char(Fbuffer *b) { return *b->get; }
static inline char * fbuffer_read_block_ptr(Fbuffer * b) { return b->get; }        
static inline size_t fbuffer_read_block_size(Fbuffer * b) 
	{ return min(fbuffer_count(b), b->data_end - b->get); }
char fbuffer_read_char(Fbuffer * b);
void fbuffer_read_seek(Fbuffer * b, size_t n);        
size_t fbuffer_read_block(Fbuffer * b, char * buffer, size_t size);

#endif
