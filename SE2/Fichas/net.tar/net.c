/*	Instituto Superior de Engenharia de	Lisboa
	Ezequiel Conde,	2010
	
*/
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <cyg/hal/hal_arch.h>	/* to stack size */
#include <cyg/infra/diag.h>
#include <cyg/kernel/kapi.h>
#include <pkgconf/libc_startup.h>
#include "fbuffer.h"
#include "net.h"
#include "ethernet.h"
#include "chrono.h"
#include "uip.h"
#include "uip_arp.h"

#if 0
#define TRACE(message, ...)		diag_printf(message, ##__VA_ARGS__)
#else
#define TRACE(...)
#endif

/*	Numero maximo de 'sockets' abertos simultaneamente
*/

static Socket sock_tab[3];

static char ibuffer[sizeof_array(sock_tab)][1024];
static char obuffer[sizeof_array(sock_tab)][1024];

static cyg_mutex_t uip_mutex;
static cyg_cond_t uip_cond;

/*------------------------------------------------------------------------------
	Auxiliary functions
*/
static inline cyg_uint16 high16(cyg_uint32 x) { return x >> 16; }

static inline cyg_uint8 high8(cyg_uint16 x) { return x >> 8; }

static inline cyg_uint16 low16(cyg_uint32 x) { return x; }

static inline cyg_uint8 low8(cyg_uint16 x) { return x; }

static void ascii_to_uip_ipaddr(char * address, uip_ipaddr_t uip_addr) {
	char aux[16], * ptr;
	strcpy(aux, address);
	ptr = strtok(aux, ".");
	uip_addr[0] = atoi(ptr);
	ptr = strtok(NULL, ".");
	uip_addr[0] |= atoi(ptr) << 8;
	ptr = strtok(NULL, ".");
	uip_addr[1] = atoi(ptr);
	ptr = strtok(NULL, "");
	uip_addr[1] |= atoi(ptr) << 8;
}

static Socket * find_socket_by_raddress(struct uip_conn * conn) {
	int i;
	for (i = 0; i < sizeof_array(sock_tab); ++i)
		if (memcmp(sock_tab[i].raddress, conn->ripaddr, sizeof(conn->ripaddr)) == 0)
			return & sock_tab[i];
	return 0;
}

static Socket * find_listen_socket(struct uip_conn * conn) {
	int i;
	for (i = 0; i < sizeof_array(sock_tab); ++i)
		if (sock_tab[i].lport == conn->lport &&	sock_tab[i].state == ACCEPT_MASK)
			return &sock_tab[i];
	return 0;
}

char * uip_ipaddr_to_ascii(uip_ipaddr_t uip_addr) {
	static char buffer[20];
	sprintf(buffer, "%d.%d.%d.%d",
		low8(uip_addr[0]), high8(uip_addr[0]),
		low8(uip_addr[1]), high8(uip_addr[1]));
	return buffer;
}

/*------------------------------------------------------------------------------
	Fechar uma liga��o
*/
void net_close(Socket * sock) {
	cyg_mutex_lock(&uip_mutex);
	sock->state = CLOSE_MASK;
	cyg_mutex_unlock(&uip_mutex);
}

/*------------------------------------------------------------------------------
	Aceitar liga��es no porto indicado
 */

Socket * net_server_accept(int port) {
	Socket * sock = 0;
	int i;
	cyg_mutex_lock(&uip_mutex);
	for (i = 0; i < sizeof_array(sock_tab); ++i)
		if (sock_tab[i].state == FREE_MASK)
			break;
	if (i == sizeof_array(sock_tab))
		goto exit;
	sock = &sock_tab[i];
	sock->lport = htons(port);
	sock->state = ACCEPT_MASK;
	uip_listen(htons(port));
	while (sock->state != CONNECTED_MASK)
		cyg_cond_wait(&uip_cond);
	uip_unlisten(htons(port));
exit:
	cyg_mutex_unlock(&uip_mutex);
	return sock;
}

/*------------------------------------------------------------------------------
	Estabelecer liga��o com servidor no endere�o e porto indicado
 */
Socket * net_client_connect(char * address, int port) {
	Socket * sock = 0;
	int i;
	cyg_mutex_lock(&uip_mutex);
	for (i = 0; i < sizeof_array(sock_tab); ++i)
		if (sock_tab[i].state == FREE_MASK)
			break;
	if (i == sizeof_array(sock_tab))
		goto exit;

	sock = &sock_tab[i];
	ascii_to_uip_ipaddr(address, sock->raddress);
	sock->rport = htons(port);
	sock->state = CONNECT_MASK;
	sock->uip_conn = uip_connect(&sock->raddress, sock->rport);
	while (sock->state == CONNECT_MASK)
		cyg_cond_wait(&uip_cond);
exit:
	cyg_mutex_unlock(&uip_mutex);
	return sock != 0 && sock->state == CONNECTED_MASK ? sock : 0;
}

/*------------------------------------------------------------------------------
	Enviar dados
 */
size_t net_send_block(Socket * sock, char * buffer, size_t length) {

}

void net_send_char(Socket * sock, char c) {

}

/*------------------------------------------------------------------------------
	Receber dados
*/
size_t net_recv_block(Socket * sock, char * buffer, size_t length) {
	size_t nbytes1 = 0, nbytes2 = 0;
	cyg_mutex_lock(&uip_mutex);
	while (fbuffer_count(&sock->istream) == 0 && sock->state == CONNECTED_MASK)
		cyg_cond_wait(&uip_cond);
	if (sock->state != CONNECTED_MASK)
		goto exit;
	nbytes1 = min(fbuffer_read_block_size(&sock->istream), length);
	memcpy(buffer, fbuffer_read_block_ptr(&sock->istream), nbytes1);
	fbuffer_read_seek(&sock->istream, nbytes1);
	nbytes2 = min(fbuffer_read_block_size(&sock->istream), length - nbytes1);
	if (nbytes2 > 0) {
		memcpy(buffer, fbuffer_read_block_ptr(&sock->istream), nbytes2);
		fbuffer_read_seek(&sock->istream, nbytes2);
	}
exit:
	cyg_mutex_unlock(&uip_mutex);
	return nbytes1 + nbytes2;
}

char net_recv_char(Socket * sock) {
	char aux = 0;
	cyg_mutex_lock(&uip_mutex);
	while (fbuffer_count(&sock->istream) == 0 && sock->state == CONNECTED_MASK)
		cyg_cond_wait(&uip_cond);
	if (sock->state == CONNECTED_MASK)
		aux = fbuffer_read_char(&sock->istream);
	cyg_mutex_unlock(&uip_mutex);
	return aux;
}

/*------------------------------------------------------------------------------
*/
void UIP_APPCALL(void) {

	if (uip_connected()) {
		TRACE("UIP_CONNECTED\n");
		Socket * sock;
		TRACE("--<local:%s:%d>--<remote:%s:%d>----------------------------------------------\r\n",
			uip_ipaddr_to_ascii(uip_hostaddr), ntohs(uip_conn->lport),
			uip_ipaddr_to_ascii(uip_conn->ripaddr), ntohs(uip_conn->rport));
		sock = find_listen_socket(uip_conn);
		if (sock) {
			sock->state = CONNECTED_MASK;
			fbuffer_reset(&sock->istream);
			fbuffer_reset(&sock->ostream);
			uip_conn->appstate = sock;
			sock->uip_conn = uip_conn;
			goto break1;
		}

		sock = find_socket_by_raddress(uip_conn);
		if (sock != 0 && sock->state == CONNECT_MASK) {
			sock->state = CONNECTED_MASK;
			fbuffer_reset(&sock->istream);
			fbuffer_reset(&sock->ostream);
			uip_conn->appstate = sock;
			sock->uip_conn = uip_conn;
			goto break1;
		}
	}

break1:
	if (uip_newdata()) {
		TRACE("UIP_NEWDATA\n");
		Socket * sock = uip_conn->appstate;
		if (sock->state == FREE_MASK)
			return;
		if (sock->state == CLOSE_MASK && fbuffer_empty(&sock->ostream)) {
			uip_close();
			sock->state = FREE_MASK;
			return;
		}
		Fbuffer * istream = &sock->istream;
		size_t len = uip_datalen();
		char * buf = uip_appdata;
		while (len > 0) {
			char * ptr = fbuffer_write_block_ptr(istream);
			size_t size = min(fbuffer_write_block_size(istream), len);
			memcpy(ptr, buf, size);
			fbuffer_write_seek(istream, size);
			buf += size;
			len -= size;
		}
	}
	
	if (uip_acked()) {
		TRACE("UIP_ACKDATA\n");
		Socket * sock = uip_conn->appstate;
		if (sock->state == FREE_MASK)
			return;
		if (sock->state == CLOSE_MASK && fbuffer_empty(&sock->ostream)) {
			uip_close();
			sock->state = FREE_MASK;
			return;
		}
		Fbuffer * ostream = &sock->ostream;
		fbuffer_read_seek(ostream, sock->sent_size);
		sock->sent_size = 0;
		if (fbuffer_count(ostream) > 0) {
			sock->sent_ptr = fbuffer_read_block_ptr(ostream);
			sock->sent_size = min(fbuffer_read_block_size(ostream), uip_mss());
//			TRACE("sent_ptr=%p, sent_size=%d\n", sock->sent_ptr, sock->sent_size);
			uip_send(sock->sent_ptr, sock->sent_size);
		}
	}
	
	if (uip_rexmit()) {
		TRACE("UIP_REXMIT\n");
		Socket * sock = uip_conn->appstate;
		if (sock->state == FREE_MASK)
			return;
		if (sock->state == CLOSE_MASK && 
			fbuffer_empty(&sock->ostream) &&
			sock->sent_size == 0) {
			uip_close();
			sock->state = FREE_MASK;
			return;
		}
		uip_send(sock->sent_ptr, sock->sent_size);
	}
	
	if (uip_poll()) {
		TRACE("UIP_POLL\n");
		Socket * sock = uip_conn->appstate;
		if (sock->state == FREE_MASK)
			return;
		if (sock->state == CLOSE_MASK && fbuffer_empty(&sock->ostream)) {
			uip_close();
			sock->state = FREE_MASK;
			return;
		}
		Fbuffer * ostream = &sock->ostream;
		if (fbuffer_count(ostream) > 0) {
			sock->sent_ptr = fbuffer_read_block_ptr(ostream);
			sock->sent_size = min(fbuffer_read_block_size(ostream), uip_mss());
			uip_send(sock->sent_ptr, sock->sent_size);
		}
	}

	if (uip_timedout())	{
		TRACE("UIP_TIMEDOUT\n");
		Socket * sock = uip_conn->appstate;
		sock->state = FREE_MASK;
	}
	
	if (uip_closed()) {
		TRACE("UIP_CLOSE\n");
		Socket * sock = uip_conn->appstate;
		sock->state = FREE_MASK;
	}
			
	if (uip_aborted()) {
		TRACE("UIP_ABORTED\n");
		Socket * sock = uip_conn->appstate;
		sock->state = FREE_MASK;
		uip_close();
	}
}

#define THREAD_STACK_SIZE		CYGNUM_HAL_STACK_SIZE_TYPICAL
#define THREAD_PRIORITY			CYGNUM_LIBC_MAIN_THREAD_PRIORITY

static char thread_stack[THREAD_STACK_SIZE];
static cyg_thread thread_desc;
static cyg_handle_t thread_hdl;

#define ETHER ((struct uip_eth_hdr *)&uip_buf[0])

static void thread(cyg_addrword_t data) {
	cyg_uint32 arp_timer = chrono_start();
	TRACE("uip thread started\n\r");
	while (1) {
		uip_len = ethernet_recv(uip_buf, UIP_BUFSIZE, nsec2tic(100000000));
		cyg_mutex_lock(&uip_mutex);
		if (uip_len > 0) {
//			static int count = 1;
//			sniffer(count++, chrono_start(), uip_buf, uip_len);
			if (ETHER->type == htons(UIP_ETHTYPE_IP)) {
				uip_arp_ipin();
				uip_input();
				/* If the above function invocation resulted in data that
					should be sent out on the network, the global variable
					uip_len is set to a value > 0. */
				if (uip_len > 0) {
					uip_arp_out();
					ethernet_send(uip_buf, uip_len, 0);
				}
			}
			else if (ETHER->type == htons(UIP_ETHTYPE_ARP)) {
				uip_arp_arpin();
				/* If the above function invocation resulted in data that
					should be sent out on the network, the global variable
					uip_len is set to a value > 0. */
				if (uip_len > 0) {
					ethernet_send(uip_buf, uip_len, 0);
				}
			}
		}
		else {
			int i;
			for (i = 0; i < UIP_CONNS; i++) {
				uip_periodic(i);
				/* If the above function invocation resulted in data that
					should be sent out on the network, the global variable
					uip_len is set to a value > 0. */
				if (uip_len > 0) {
					uip_arp_out();
					ethernet_send(uip_buf, uip_len, 0);
				}
			}

			/* Call the ARP timer function every 10 seconds. */
			if (chrono_timeout(arp_timer, nsec2tic(10LL * 1000000000))) {
				arp_timer = chrono_start();
				uip_arp_timer();
			}
		}
		cyg_cond_broadcast(&uip_cond);
		cyg_mutex_unlock(&uip_mutex);
	}
}

static struct uip_eth_addr ether_addr = {
	{0x02, 0x65, 0x7A, 0x65, 0x71, 00}
};

void net_init() {
	uip_ipaddr_t ipaddr;	int i;
	TRACE( "uip/socket test init\n\r" );

	ethernet_init(ether_addr.addr);

	uip_init();
	uip_setethaddr(ether_addr);

	uip_ipaddr(ipaddr, 1, 1, 1, 30);
	uip_sethostaddr(ipaddr);
	uip_ipaddr(ipaddr, 1, 1, 1, 1);
	uip_setdraddr(ipaddr);

	uip_ipaddr(ipaddr, 255,255,254,0);
	uip_setnetmask(ipaddr);
	
	for (i = 0; i <sizeof_array(sock_tab); ++i) {
		sock_tab[i].state = FREE_MASK;
		fbuffer_init(&sock_tab[i].istream, ibuffer[i], sizeof(ibuffer[i]));
		fbuffer_init(&sock_tab[i].ostream, obuffer[i], sizeof(obuffer[i]));
	}
	
	//cyg_flag_init(&uip_flags);
	cyg_mutex_init(&uip_mutex);
	cyg_cond_init(&uip_cond, &uip_mutex);

	cyg_thread_create( THREAD_PRIORITY, thread, (cyg_addrword_t) 75,
		"Thread net", (void *)thread_stack, sizeof(thread_stack),
		&thread_hdl, &thread_desc );
	cyg_thread_resume( thread_hdl );
}

void uip_log(char *m) {
  diag_printf("uIP log message: %s\n", m);
}

