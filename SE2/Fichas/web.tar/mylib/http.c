/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2010
	
	Funções auxiliares HTTP e HTML
*/

#include "stream.h"
#include "http.h"

/*------------------------------------------------------------------------------
	Gera um cabeçalho HTTP com um dado "Content-type" e " Content-length"
*/

void http_start(Stream * stream, char *content_type, int content_length ) {
	stream_printf(stream, "HTTP/1.1 200 OK\r\n"
						  "Server: Sistemas Embebidos II\r\n");
    if( content_type != NULL )
        stream_printf(stream, "Content-type: %s\r\n", content_type);
    if( content_length != 0 )
        stream_printf(stream, "Content-length: %d\r\n", content_length);
    stream_printf(stream, "Connection: close\r\n\r\n");    
}

/*------------------------------------------------------------------------------
	Adiciona uma linha em branco no fim da mensagem
*/

void http_finish(Stream * stream) {
	stream_printf(stream, "\r\n");
}

/*------------------------------------------------------------------------------
	Inserção de tags HTML
*/

void html_tag_begin(Stream * stream, char * tag, char * attr) {
    char * pad = "";
    if( attr == NULL )
        attr = pad;
    else if( attr[0] != 0 )
        pad = " ";
	stream_printf(stream, "<%s%s%s>\r\n", tag, pad, attr);
}

void html_tag_end(Stream * stream, char * tag) {
    stream_printf(stream, "<%s%s%s>\r\n","/",tag,"");
}

/*------------------------------------------------------------------------------
	Na resposta de um form, substitui '&' pelo terminador de string '\0',
	criando uma sequência de strings da forma "name=value".
	Substitui também o '+' pelo ' ' 
*/
void formdata_parse( char *data, char *list[], int size ) {
    char *p = data;
    int i = 0;
    list[i] = p;
    while( p && *p != 0 && i < size-1 ) {
        if( *p == '&' ) {
            *p++ = 0;
            list[++i] = p;
            continue;
        }
        if( *p == '+' )
            *p = ' ';
        p++;
    }
    list[++i] = 0;
}

/*------------------------------------------------------------------------------
	Pesquisa por um nome na lista de respostas de um form,
	depois de processadas por formdata_parse.
	Se encontrar retorna o ponteiro para o valor
*/
char * formlist_find( char *list[], char *name ) {
    while( *list != 0 ) {
        char *p = *list;
        char *q = name;
        while( *p == *q )
            p++, q++;
        if( *q == 0 && *p == '=' )
            return p + 1;
        list++;
    }
    return 0;
}

/*------------------------------------------------------------------------------
	Enviar uma página com uma mensagem a partir de uma string
*/
int http_send_html(Stream * stream, char * uri, char * request, void * arg) {
    html_begin(stream);
    stream_printf(stream, arg);
	html_end(stream);
	return 1;
}

/*------------------------------------------------------------------------------
	Enviar dados a partir de uma estrutura http_data
		typedef struct {
			char * content_type;
			U32 content_length;
			U8	* data;
		} http_data;
	Útil para enviar qualquer tipo de dados préformatados, como imagens.
*/
int http_send_data(Stream * stream, char * uri, char * request, void * arg ) {
    http_data * data = (http_data *)arg;
    http_start(stream, data->content_type, data->content_length);
    stream_write_block(stream, (char*)data->data, data->content_length);
	return 1;
}
