/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2010
*/

#include <assert.h>
#include <stdio.h>
#include <string.h>
#include "utils.h"

#include "stream.h"

void stream_write_char(Stream * stream, char c) {
	stream->device->write_char(stream->object, c);
}

size_t stream_write_block(Stream * stream, char * data, size_t size) {
   	stream->device->write_block(stream->object, data, size);
	return size;
}

void stream_write_string(Stream * stream, char * str) {
	size_t size = strlen(str);
	stream->device->write_block(stream->object, str, size);
}

int stream_printf(Stream * stream, const char * format, ...) {
	char buffer[256];
	va_list vlp;
	size_t size;
	va_start(vlp, format);
/*	size = vnsprintf(buffer, sizeof(buffer), format, vlp); */
	size = vsprintf(buffer, format, vlp);	/* Atenção PERIGO! */
	stream->device->write_block(stream->object, buffer, size);
	return size;
}

int stream_vprintf(Stream * stream, const char * format, va_list vlp) {
	char buffer[256];
	size_t size = vsprintf(buffer, format, vlp);
	stream->device->write_block(stream->object, buffer, size);
	return size;
}

char stream_read_char(Stream * stream) {
	assert(stream->device != 0);
	return stream->device->read_char(stream->object);
}

size_t stream_read(Stream * stream, char * buffer, size_t size) {
	assert(stream->device != 0);
	return stream->device->read_block(stream->object, buffer, size);
}

#if 0

#include <_stdio.h>

static int scan_read_char(void * stream, int ch) {
	static char buffer[10];
	static int count = 0;
	if (ch == _WANT)
		if (count > 0)
			return buffer[--count];
		else
			return (stream->device->read_char(stream->object);
	else if (ch >= 0)
		buffer[count++] = ch;
	return ch;
}

int stream_scanf(Stream * stream, const char *format, ...) {
	va_list vlp;
	va_start(vlp, format);
	return _scanf(scan_read_char, stream, format, vlp);
}

#endif

size_t stream_getline(Stream * stream, char * buffer, size_t size) {
	char c;
	size_t index = 0;
	size -= 2;
	while (1) {
		c = stream->device->read_char(stream->object);
		buffer[index++] = c;
		if (c == '\r') {
			c = stream->device->read_char(stream->object);
			if (c == '\n') {
				--index;
				goto exit;
			}
			buffer[index++] = c;
		}
		if (index >= size)
			goto exit;
	}
exit:
	return index;
}

void stream_set_device(Stream * stream, Stream_device * device, void * object) {
	stream->device = device; 
	stream->object = object; 
}


