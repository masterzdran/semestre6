/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2010
*/
#ifndef STREAM_H
#define STREAM_H

#include <stdarg.h>
#include <stdlib.h>

typedef struct {
	void (*write_char)(void *, char c);
	size_t (*write_block)(void *, char * data, size_t size);
	char (*read_char)(void *);
	size_t (*read_block)(void *, char * buffer, size_t size);
} Stream_device;

typedef struct {
	Stream_device * device;
	void * object;
} Stream;

void stream_write_char(Stream * stream, char c);
size_t stream_write_block(Stream * stream, char * data, size_t size);
void stream_write_string(Stream * stream, char * str);

char stream_read_char(Stream * stream);
size_t stream_read_block(Stream * stream, char * buffer, size_t size);

/*	formatted interface */
int stream_printf(Stream * stream, const char * fmt, ...);
int stream_vprintf(Stream * stream, const char * fmt, va_list vlp);

int stream_scanf(Stream * stream, const char *fmt, ...);
size_t stream_getline(Stream * stream, char * buffer, size_t size);

void stream_set_device(Stream * stream, Stream_device * device, void * object);

#endif

