/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2010
	
	Funções auxiliares HTTP e HTML
*/

#ifndef HTTP_H
#define HTTP_H

#include <cyg/infra/cyg_type.h>
#include "stream.h"

/* =============================================================================
	Tabela de recursos
*/

typedef int http_handler(Stream *, char * uri, char * formdata, void * arg);

typedef struct {
    char         * pattern;
    http_handler * handler;
    void         * arg;
} http_table_entry;

/* =============================================================================
*/

int http_send_html(Stream *, char * filename, char * request, void * arg);

typedef struct {
    char * content_type;
    cyg_uint32 content_length;
    cyg_uint8 * data;
} http_data;

#define HTTP_DATA( __name, __type, __length, __data ) \
	http_data __name = { __type, __length, __data }

int http_send_data(Stream *, char * filename, char * request, void * arg);

/* =============================================================================
*/

void http_start(Stream *, char * content_type, int content_length );
void http_finish(Stream * stream);

#define html_begin(stream)                   \
        http_start(stream, "text/html", 0 ); \
        html_tag_begin(stream, "html", "" )

#define html_end(stream)                     \
        html_tag_end(stream, "html" );       \
        http_finish(stream)

void html_tag_begin(Stream * stream, char * tag, char * attr);
void html_tag_end(Stream * stream, char * tag);

/* -----------------------------------------------------------------------------
*/

#define html_head(stream, __title, __meta )( {				\
    stream_printf(stream, "<head><title>%s", __title);		\
    stream_printf(stream, "</title>%s</head>\r\n", __meta); \
})

#define html_body_begin(stream, __attr )     \
	html_tag_begin(stream, "body", __attr )

#define html_body_end(stream)               \
	html_tag_end(stream, "body" )

#define html_heading(stream, __level, __heading ) \
    stream_printf(stream,"<h%d>%s</h%d>\r\n",__level,__heading,__level)

/* -----------------------------------------------------------------------------
*/

#define html_url(stream, __text, __link )         \
	stream_printf(stream, "<a href=\"%s\">%s</a>\r\n",__link,__text)

#define html_para_begin(stream, __attr )     \
	html_tag_begin(stream, "p", __attr )

#define html_image(stream, __source, __alt, __attr )				\
	stream_printf(stream, "<%s %s=\"%s\" %s=\"%s\" %s>\r\n", "img",	\
                 "src",__source,									\
                 "alt",__alt,										\
                 (__attr)?(__attr):"" )

/* -----------------------------------------------------------------------------
	table
*/

#define html_table_begin(stream, __attr )     \
	html_tag_begin(stream, "table", __attr)

#define html_table_end(stream)               \
	html_tag_end(stream, "table" );

#define html_table_header(stream, __content, __attr ) ({	\
    html_tag_begin(stream, "th", __attr);					\
    stream_printf(stream, "%s", __content );				\
    html_tag_end(stream, "th");								\
})

#define html_table_row_begin(stream, __attr )     \
	html_tag_begin(stream, "tr", __attr )

#define html_table_row_end(stream)               \
	html_tag_end(stream, "tr" )

#define html_table_data_begin(stream, __attr )     \
	html_tag_begin(stream, "td", __attr )

#define html_table_data_end(stream)               \
	html_tag_end(stream, "td" )

/* -----------------------------------------------------------------------------
	form
*/

#define html_form_begin(stream, __url, __attr )      \
	stream_printf(stream, "<%s %s=\"%s\" %s>\r\n","form", \
                "action",__url,                         \
                (__attr)?(__attr):"" )

#define html_form_end(stream)               \
	html_tag_end(stream, "form" )

#define html_form_input(stream, __type, __name, __value, __attr ) ({ 			\
    char *__lattr = (__attr);                                                   \
    stream_printf(stream, "<%s %s=\"%s\" %s=\"%s\" %s=\"%s\" %s>\r\n","input", \
            "type",__type,                                                      \
            "name",__name,                                                      \
            "value",__value,                                                    \
            __lattr?__lattr:"" );                                               \
})

#define html_form_input_radio(stream, __name, __value, __checked) \
	html_form_input(stream, "radio", __name, __value, (__checked)?"checked":"" )

#define html_form_input_checkbox(stream, __name, __value, __checked ) \
	html_form_input(stream, "checkbox", __name, __value, (__checked)?"checked":"" )

#define html_form_input_hidden(stream, __name, __value ) \
	html_form_input(stream, "hidden", __name, __value, "" )

#define html_form_select_begin(stream, __name, __attr )      \
	stream_printf(stream, "<%s %s=\"%s\" %s>\r\n","select",      \
		"name",__name,                                 \
		(__attr)?(__attr):"" )

#define html_form_option(stream, __value, __label, __selected) ({ \
	stream_printf(stream, "<%s %s=\"%s\" %s>\r\n","option",        \
		"value", __value,                                      \
		(__selected)?"selected":"" );                          \
		stream_printf(stream, __label);			               \
})

#define html_form_select_end(stream) \
	html_tag_end(stream, "select" );

/* -----------------------------------------------------------------------------
	list
*/

#define html_unordered_list_begin(stream)      \
	html_tag_begin(stream, "ul", "")

#define html_unordered_list_end(stream)      \
	html_tag_end(stream, "ul")

#define html_list_item(stream, item) \
    stream_printf(stream,"<li>%s</li>\r\n", item)

/* =============================================================================
*/

void formdata_parse(char *data, char *list[], int size);

char * formlist_find(char *list[], char *name );

#endif

