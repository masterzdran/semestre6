/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2010
	
	Mini servidor web sobre eCos
*/

#include <time.h>
#include <stdio.h>
#include <cyg/hal/hal_arch.h>	// For stack size
#include <cyg/kernel/kapi.h>	// Kernel API.
#include <cyg/infra/diag.h>		// For diagnostic printing.

#include "net.h"
#include "http.h"
#include "stream.h"

#if 1
#define TRACE(message, ...)		diag_printf(message, ##__VA_ARGS__)
#else
#define TRACE(...)
#endif

/*------------------------------------------------------------------------------
*/
static Stream_device stream_socket = {
	write_char: net_send_char,
	write_block: net_send_block,
	read_char: net_recv_char,
	read_block: net_recv_block,
};

static Stream stream;

/*------------------------------------------------------------------------------
	Tabela de páginas do servidor
*/

#define LED_PIN	15

int led_page(Stream * stream, char *uri, char *formdata, void *arg );

http_table_entry http_table[] = {
	{ "/led.html", led_page, LED_PIN }
};

int http_table_len = sizeof_array(http_table);

/*------------------------------------------------------------------------------
	Mensagem de recurso não encontrado
*/
static char page_not_found[] =
"<head><title>Page not found</title></head>\r\n"
"<body><h2>O recurso pretendido nao esta disponivel.</h2></body>\r\n";

void http_process(Stream * stream) {
	char request[256];
	char line[40];
	char * formdata;
	char * uri;

	/* ler a primeira linha */
	stream_getline(stream, request, sizeof(request));
	TRACE("Request <%s>\r\n", request);
	
	/* esperar pela linha em branco */
	while ( stream_getline(stream, line, sizeof(line)))
		;

    char * p;
   	uri = p = request + 4;
	while( *p != ' ' && *p != '?' )
		p++;
	if( *p == '?' )
		formdata = p + 1;
	*p = 0;
	if (formdata != NULL ) {
		while( *p != ' ' )
			p++;
		*p = 0;
	}
	
	TRACE("table: %p...%d\r\n", http_table, http_table_len);
	http_table_entry * entry;
 	int i;
	for (entry = http_table, i = 0; i < http_table_len; ++i) {
		TRACE("try %p: %s\r\n", entry, entry->pattern);
		if (strcmp(uri, entry->pattern) == 0) {
			TRACE("calling %p: %s\r\n", entry, entry->pattern);
			if (entry->handler(stream, uri, formdata, entry->arg))
				break;
		}
		entry++;
	}
	if (i >= http_table_len) {
		TRACE("Not found %s\r\n", uri);
		http_send_html(stream, NULL, NULL, page_not_found);
	}
}

int main(void) {
	diag_printf("\r\n-------------------------------------------------------\r\n"
				   "HTTP mini server\r\n\r");  
	while (1) {
		Socket * socket = net_server_accept(80);
		stream_set_device(&stream, &stream_socket, socket);
		http_process(&stream);
		net_close(socket);
	}
	return 0;
}

#define LPC2XXX_PINSEL0_GPIO(p)			(~(3 << ((p) << 1)))

void cyg_user_start( void ) {
	net_init();
	
	cyg_uint32 iodir;
	HAL_READ_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE +
		CYGARC_HAL_LPC2XXX_REG_IODIR, iodir);
	HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE + 
		CYGARC_HAL_LPC2XXX_REG_IODIR,
		iodir |	1 << LED_PIN);
	
	cyg_uint32 pinsel;
	HAL_READ_UINT32(CYGARC_HAL_LPC2XXX_REG_PIN_BASE + 
		CYGARC_HAL_LPC2XXX_REG_PINSEL0, pinsel);
	HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_PIN_BASE + 
		CYGARC_HAL_LPC2XXX_REG_PINSEL0,
		pinsel & LPC2XXX_PINSEL0_GPIO(LED_PIN));
}
