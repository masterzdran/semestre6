#include <stdio.h>
#include <cyg/hal/hal_io.h>             // low level i/o
#include <cyg/hal/var_io.h>             // common registers
#include "http.h"
#include "utils.h"

int led_page(Stream * stream, char *uri, char *formdata, void *arg ) {
	char string[33];
	cyg_uint32 value;

	if (formdata != 0) {
		char * formlist[10], * p;
		formdata_parse(formdata, formlist, sizeof_array(formlist));
		p = formlist_find(formlist, "led");
		if (p != 0)
			if (*p == '1')
				HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE +
					CYGARC_HAL_LPC2XXX_REG_IOSET, 1 << (int)arg);	
			else
				HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE +
					CYGARC_HAL_LPC2XXX_REG_IOCLR, 1 << (int)arg);	
	}
	html_begin(stream);
	html_head(stream, "LED", "");    
	html_body_begin(stream, "");
	{
		html_heading(stream, 3, "Sistemas Embebidos II - LPC2106/ENC28J60" );
		
		html_form_begin(stream, uri, "" );        
		{
		html_table_begin(stream, "" );
		{
			html_table_row_begin(stream, "" );
			{
				html_table_data_begin(stream, "" );
				stream_printf(stream, "P0.%d", (int)arg);
				html_table_data_begin(stream, "" );
				HAL_READ_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE +
					CYGARC_HAL_LPC2XXX_REG_IOSET, value);
				sprintf(string, "%d", (value >> ((int) arg) & 1));
				html_form_input(stream, "text", "led", string, "size=8");
			}
			html_table_row_end(stream);
		}
		html_table_end(stream);

		html_form_input(stream, "submit", "submit", "Submit", "");                
		html_form_input(stream, "reset", "reset", "Reset", "");

		}
		html_tag_end(stream, "font");
		html_form_end(stream);
	}
	html_body_end(stream);
	html_end(stream);
	return 1;
}
