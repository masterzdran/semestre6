#ifndef CYGONCE_PKGCONF_LIBC_H
#define CYGONCE_PKGCONF_LIBC_H
/*
 * File <pkgconf/libc.h>
 *
 * This file is generated automatically by the configuration
 * system. It should not be edited. Any changes to this file
 * may be overwritten.
 */


#endif
