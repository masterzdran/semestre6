#ifndef CYGONCE_PKGCONF_IO_SERIAL_GENERIC_16X5X_H
#define CYGONCE_PKGCONF_IO_SERIAL_GENERIC_16X5X_H
/*
 * File <pkgconf/io_serial_generic_16x5x.h>
 *
 * This file is generated automatically by the configuration
 * system. It should not be edited. Any changes to this file
 * may be overwritten.
 */


#endif
