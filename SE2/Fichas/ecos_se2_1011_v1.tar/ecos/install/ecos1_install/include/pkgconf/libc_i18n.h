#ifndef CYGONCE_PKGCONF_LIBC_I18N_H
#define CYGONCE_PKGCONF_LIBC_I18N_H
/*
 * File <pkgconf/libc_i18n.h>
 *
 * This file is generated automatically by the configuration
 * system. It should not be edited. Any changes to this file
 * may be overwritten.
 */

#define CYGPKG_LIBC_I18N_LOCALES 1
#define CYGSEM_LIBC_I18N_PER_THREAD_MB 1
#define CYGNUM_LIBC_I18N_MAX_LOCALE_NAME_SIZE 2
#define CYGNUM_LIBC_I18N_MAX_LOCALE_NAME_SIZE_2
#define CYGIMP_LIBC_I18N_CTYPE_INLINES 1

#endif
