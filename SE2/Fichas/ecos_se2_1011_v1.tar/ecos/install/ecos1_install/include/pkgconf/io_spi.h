#ifndef CYGONCE_PKGCONF_IO_SPI_H
#define CYGONCE_PKGCONF_IO_SPI_H
/*
 * File <pkgconf/io_spi.h>
 *
 * This file is generated automatically by the configuration
 * system. It should not be edited. Any changes to this file
 * may be overwritten.
 */

#define CYGPKG_IO_SPI_OPTIONS 1

#endif
