#ifndef CYGONCE_PKGCONF_IO_SERIAL_ARM_LPC2XXX_H
#define CYGONCE_PKGCONF_IO_SERIAL_ARM_LPC2XXX_H
/*
 * File <pkgconf/io_serial_arm_lpc2xxx.h>
 *
 * This file is generated automatically by the configuration
 * system. It should not be edited. Any changes to this file
 * may be overwritten.
 */


#endif
