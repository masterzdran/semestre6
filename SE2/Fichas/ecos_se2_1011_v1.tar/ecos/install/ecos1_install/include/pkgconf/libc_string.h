#ifndef CYGONCE_PKGCONF_LIBC_STRING_H
#define CYGONCE_PKGCONF_LIBC_STRING_H
/*
 * File <pkgconf/libc_string.h>
 *
 * This file is generated automatically by the configuration
 * system. It should not be edited. Any changes to this file
 * may be overwritten.
 */

#define CYGIMP_LIBC_STRING_INLINES 1
#define CYGFUN_LIBC_STRING_BSD_FUNCS 1
#define CYGPKG_LIBC_STRING_STRTOK 1
#define CYGSEM_LIBC_STRING_PER_THREAD_STRTOK 1
#define CYGNUM_LIBC_STRING_STRTOK_TRACE_LEVEL 0
#define CYGNUM_LIBC_STRING_STRTOK_TRACE_LEVEL_0
#define CYGFUN_LIBC_STRING_STRDUP 1

#endif
