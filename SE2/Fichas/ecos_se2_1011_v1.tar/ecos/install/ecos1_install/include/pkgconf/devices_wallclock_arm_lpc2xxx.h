#ifndef CYGONCE_PKGCONF_DEVICES_WALLCLOCK_ARM_LPC2XXX_H
#define CYGONCE_PKGCONF_DEVICES_WALLCLOCK_ARM_LPC2XXX_H
/*
 * File <pkgconf/devices_wallclock_arm_lpc2xxx.h>
 *
 * This file is generated automatically by the configuration
 * system. It should not be edited. Any changes to this file
 * may be overwritten.
 */

#define CYGIMP_WALLCLOCK_HARDWARE 1

#endif
