#include <time.h>
#include <stdio.h>
#include <cyg/infra/diag.h>
#include <cyg/infra/cyg_type.h>         // base types
#include <cyg/hal/hal_io.h>             // low level i/o
#include <cyg/hal/var_io.h>             // common registers
#include "lcd.h"
#include "draw.h"
#include "widget.h"
#include "button.h"
#include "chrono.h"
#include "rtc.h"

/*==============================================================================
	Dados relacionados com o despertador
*/

struct {
	struct tm tp;
	int state;
} alarm;

#define ALARM_PIN	16

void alarm_set(int on) {
	if (on)
		HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE + 
			CYGARC_HAL_LPC2XXX_REG_IOSET, 1 << ALARM_PIN);
	else
		HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE + 
			CYGARC_HAL_LPC2XXX_REG_IOCLR, 1 << ALARM_PIN);
}

void alarm_init() {
	cyg_uint32 iodir;
	HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE +
		CYGARC_HAL_LPC2XXX_REG_IOSET, 1 << ALARM_PIN);
	HAL_READ_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE +
		CYGARC_HAL_LPC2XXX_REG_IODIR, iodir);
	HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE +
		CYGARC_HAL_LPC2XXX_REG_IODIR, iodir | 1 << ALARM_PIN);
}

/*==============================================================================
	Eventos
*/
enum event_type {
	EVENT_KEY_PUSH,			/* Tecla premida */
	EVENT_KEY_RELEASE,		/* Tecla largada */
	EVENT_RTC,
	EVENT_TIMEOUT,
	EVENT_NONE
};

typedef struct {
	enum event_type type;
	int value;
} event_t;

#define UP		1
#define DOWN	0
#define RIGHT	5
#define LEFT	3
#define OK		2
#define CANC	4

static struct {
	cyg_uint32 time, initial, active;
} event_timer;

static void event_timer_start(cyg_uint32 time) {
	event_timer.active = 1;
	event_timer.initial = chrono_start();
	event_timer.time = time;
}

static int event_read(event_t * event) {
	int i;

	/* comandos dos bot�es */
	enum Button_transition aux;
	for (i = 0; i < N_BUTTONS; ++i) {
		aux = button_get_transition(i);
		if (aux == BUTTON_TO_ON) {
			event->value = i;
			diag_printf("Botao = %d\n\r", i);
			return event->type = EVENT_KEY_PUSH;
		}
	}

	/* altera��o do estado do rel�gio */
	if (rtc_changed())
		return event->type = EVENT_RTC;

	/* verificar temporiza��es */
	if (event_timer.active) {
		if (chrono_timeout(event_timer.initial, event_timer.time)) {
			event_timer.active = 0;
			return event->type = EVENT_TIMEOUT;
		}		
	}
	return event->type = EVENT_NONE;
}

/*==============================================================================
	M�quina de estados da aplica��o
*/

void state_machine_init(int s);

void state_machine_during();

void state_machine_change(int s);

typedef struct {
	void (* enter)();
	void (* during)();
	void (* leave)();
} State;

static State * state;		/* Estado corrente */

/*------------------------------------------------------------------------------
	Estado 0 - apresenta��o
*/

static Wg_analog_clock state0_clock;
static struct tm state0_tp;

static void state0_enter() {
	fill_rectangle(0, 0, 131, 131, WHITE);
	rtc_read(&state0_tp);
	wg_analog_clock_init(&state0_clock, 65, 65, 50, BLACK, YELLOW, CYAN);
	wg_analog_clock_write(&state0_clock, state0_tp.tm_hour, state0_tp.tm_min, state0_tp.tm_sec);
}

static void state0_during() {
	event_t event;

	event_read(&event);
	switch (event.type) {
		case EVENT_KEY_PUSH:
			state_machine_change(1);
			break;
		case EVENT_RTC:
			rtc_read(&state0_tp);
			wg_analog_clock_write(&state0_clock, state0_tp.tm_hour, state0_tp.tm_min, state0_tp.tm_sec);
			if (state0_tp.tm_hour == alarm.tp.tm_hour && state0_tp.tm_min == alarm.tp.tm_min) {
				alarm_set(1);
			}
			else {
				alarm_set(0);
			}
			break;
		default:;
	}
}

static void state0_leave() {
	;
}

/*------------------------------------------------------------------------------
	Estado 1 - menu
*/
static Wg_text state1_menu[3];
static int state1_menu_index;

static void state1_enter() {
	fill_rectangle(0, 0, 131, 131, WHITE);
	wg_text_init(&state1_menu[0], 20, 40, "Relogio");
	wg_text_init(&state1_menu[1], 20, 60, "Despertador");
	wg_text_init(&state1_menu[2], 20, 80, "Contraste");
	state1_menu_index = 0;
	wg_text_focus_in(&state1_menu[0]);
	event_timer_start(10000);
}

static void state1_during() {
	event_t event;
	event_read(&event);
	if (event.type == EVENT_KEY_PUSH) {
		event_timer_start(10000);
		switch(event.value) {
			case DOWN:
				wg_text_focus_out(&state1_menu[state1_menu_index]);
				if (++state1_menu_index == sizeof_array(state1_menu))
					state1_menu_index = 0;
				wg_text_focus_in(&state1_menu[state1_menu_index]);
				break;
			case OK:
				switch (state1_menu_index) {
					case 0:
						wg_text_focus_out(&state1_menu[state1_menu_index]);
						state_machine_change(2);
						break;
					case 1:
						wg_text_focus_out(&state1_menu[state1_menu_index]);
						state_machine_change(3);
						break;
					case 2:
						wg_text_focus_out(&state1_menu[state1_menu_index]);
						state_machine_change(4);
						break;
				}
				break;
			case CANC:
				state_machine_change(0);
				break;
			case UP:
				wg_text_focus_out(&state1_menu[state1_menu_index]);
				if (state1_menu_index-- == 0)
					state1_menu_index = sizeof_array(state1_menu) - 1;
				wg_text_focus_in(&state1_menu[state1_menu_index]);
				break;
		}
	}
	if (event.type == EVENT_TIMEOUT)
		state_machine_change(0);
}

static void state1_leave() {
	event_timer.active = 0;
}

/*------------------------------------------------------------------------------
	Estado 2 - acerto do relogio
*/
static Wg_analog_clock state2_clock;
static Wg_text state2_menu[6];
static int state2_menu_index;
static Wg_text state2_sep[2];
static struct tm state2_tp;

static void state2_enter() {
	fill_rectangle(0, 0, 131, 131, WHITE);
	rtc_read(&state2_tp);
	wg_text_init(&state2_menu[0], 25,				 		  90, rtc_text(state2_tp.tm_hour));
	wg_text_init(&state2_sep[0],  25 + 2 * draw_text_width(), 90, ":");
	wg_text_init(&state2_menu[1], 25 + 3 * draw_text_width(), 90, rtc_text(state2_tp.tm_min));
	wg_text_init(&state2_sep[1],  25 + 5 * draw_text_width(), 90, ":");
	wg_text_init(&state2_menu[2], 25 + 6 * draw_text_width(), 90, rtc_text(state2_tp.tm_sec));
	wg_text_init(&state2_menu[3], 0,						  102, rtc_text(state2_tp.tm_mday));
	wg_text_init(&state2_menu[4], 0 + 3 * draw_text_width(), 102, rtc_text_month(state2_tp.tm_mon));
	wg_text_init(&state2_menu[5], 0 + 12 * draw_text_width(), 102, rtc_text(state2_tp.tm_year));
	state2_menu_index = 0;
	wg_text_focus_in(&state2_menu[0]);

	wg_analog_clock_init(&state2_clock, 65, 45, 35, BLACK, GREEN, CYAN);
	wg_analog_clock_write(&state2_clock, state2_tp.tm_hour, state2_tp.tm_min, state2_tp.tm_sec);
}
	
static void state2_during() {
	event_t event;
	event_read(&event);
	if (event.type == EVENT_KEY_PUSH) {
		switch(event.value) {
			case DOWN:
				switch (state2_menu_index) {
					case 0:
						rtc_down_hour(&state2_tp);
						wg_text_write(&state2_menu[0], rtc_text(state2_tp.tm_hour));
						break;
					case 1:
						rtc_down_min(&state2_tp);
						wg_text_write(&state2_menu[1], rtc_text(state2_tp.tm_min));
						break;
					case 2:
						rtc_down_sec(&state2_tp);
						wg_text_write(&state2_menu[2], rtc_text(state2_tp.tm_sec));
						break;
					case 3:
						rtc_down_day(&state2_tp);
						wg_text_write(&state2_menu[3], rtc_text(state2_tp.tm_mday));
						break;
					case 4:
						rtc_down_month(&state2_tp);
						wg_text_write(&state2_menu[4], rtc_text_month(state2_tp.tm_mon));
						break;
					case 5:
						rtc_down_year(&state2_tp);
						wg_text_write(&state2_menu[5], rtc_text(state2_tp.tm_year));
						break;
				}
				wg_analog_clock_write(&state2_clock, state2_tp.tm_hour, state2_tp.tm_min, state2_tp.tm_sec);
				break;
			case LEFT:
				wg_text_focus_out(&state2_menu[state2_menu_index]);
				if (state2_menu_index-- == 0)
					state2_menu_index = sizeof_array(state2_menu) - 1;
				wg_text_focus_in(&state2_menu[state2_menu_index]);
				break;
			case OK:
				rtc_write(&state2_tp);
			case CANC:
				state_machine_change(1);
				break;
			case UP:
				switch (state2_menu_index) {
					case 0:
						rtc_up_hour(&state2_tp);
						wg_text_write(&state2_menu[0],  rtc_text(state2_tp.tm_hour));
						break;
					case 1:
						rtc_up_min(&state2_tp);
						wg_text_write(&state2_menu[1],  rtc_text(state2_tp.tm_min));
						break;
					case 2:
						rtc_up_sec(&state2_tp);
						wg_text_write(&state2_menu[2], rtc_text(state2_tp.tm_sec));
						break;
					case 3:
						rtc_up_day(&state2_tp);
						wg_text_write(&state2_menu[3], rtc_text(state2_tp.tm_mday));
						break;
					case 4:
						rtc_up_month(&state2_tp);
						wg_text_write(&state2_menu[4], rtc_text_month(state2_tp.tm_mon));
						break;
					case 5:
						rtc_up_year(&state2_tp);
						wg_text_write(&state2_menu[5], rtc_text(state2_tp.tm_year));
						break;
				}
				wg_analog_clock_write(&state2_clock, state2_tp.tm_hour, state2_tp.tm_min, state2_tp.tm_sec);
				break;
			case RIGHT:
				wg_text_focus_out(&state2_menu[state2_menu_index]);
				if (++state2_menu_index == sizeof_array(state2_menu))
					state2_menu_index = 0;
				wg_text_focus_in(&state2_menu[state2_menu_index]);
				break;
		}
	}
}

static void state2_leave() {
	;
}

/*------------------------------------------------------------------------------
	Estado 3 - acerto do despertador
*/
static Wg_analog_clock state3_clock;
static Wg_check_box state3_check;
static Wg_text state3_mode;
static int state3_focus;

static void state3_enter() {
	fill_rectangle(0, 0, 131, 131, WHITE);
	wg_analog_clock_init(&state3_clock, 65, 45, 35, BLACK, GREEN, CYAN);
	wg_analog_clock_write(&state3_clock, alarm.tp.tm_hour, alarm.tp.tm_min, alarm.tp.tm_sec);
	wg_check_init(&state3_check, 20, 100, "Activado", alarm.state);
	state3_focus = 0;
	wg_text_init(&state3_mode, 100, 20, "H");

}
	
static void state3_during() {
	event_t event;
	event_read(&event);
	if (event.type == EVENT_KEY_PUSH) {
		switch(event.value) {
			case UP:
				switch (state3_focus) {
					case 0:	/* Hora */
						rtc_up_hour(&alarm.tp);
						wg_analog_clock_write(&state3_clock, alarm.tp.tm_hour, alarm.tp.tm_min, alarm.tp.tm_sec);
						break;
					case 1:	/* Minuto */
						rtc_up_min(&alarm.tp);
						wg_analog_clock_write(&state3_clock, alarm.tp.tm_hour, alarm.tp.tm_min, alarm.tp.tm_sec);
						break;
					case 2: /* Activar? */
						wg_check_set_state(&state3_check, 1);
						break;
				}
				break;
			case DOWN:
				switch (state3_focus) {
					case 0:	/* Hora */
						rtc_down_hour(&alarm.tp);
						wg_analog_clock_write(&state3_clock, alarm.tp.tm_hour, alarm.tp.tm_min, alarm.tp.tm_sec);
						break;
					case 1:	/* Minuto */
						rtc_down_min(&alarm.tp);
						wg_analog_clock_write(&state3_clock, alarm.tp.tm_hour, alarm.tp.tm_min, alarm.tp.tm_sec);
						break;
					case 2: /* Activar? */
						wg_check_set_state(&state3_check, 0);
						break;
				}
				break;
			case OK:
			case CANC:
				state_machine_change(1);
				break;
			case RIGHT:
				switch (state3_focus) {
					case 0:
						state3_focus = 1;
						wg_text_write(&state3_mode, "M");
						break;
					case 1:
						state3_focus = 2;
						wg_text_write(&state3_mode, "");
						wg_check_focus_in(&state3_check);
						break;
					case 2:
						state3_focus = 0;
						wg_check_focus_out(&state3_check);
						wg_text_write(&state3_mode, "H");
						break;
				}
				break;
			case LEFT:
				switch (state3_focus) {
					case 2:
						state3_focus = 1;
						wg_text_write(&state3_mode, "M");
						break;
					case 0:
						state3_focus = 2;
						wg_text_write(&state3_mode, "");
						wg_check_focus_in(&state3_check);
						break;
					case 1:
						state3_focus = 0;
						wg_check_focus_out(&state3_check);
						wg_text_write(&state3_mode, "H");
						break;
				}
				break;
		}
	}
}

static void state3_leave() {
	;
}

/*------------------------------------------------------------------------------
	Estado 4 - configurar o contraste do display
*/
static Wg_text state4_title;
static Wg_text state4_contrast;

extern int lcd_read_contrast();
extern int lcd_inc_contrast();
extern int lcd_dec_contrast();

static void state4_enter() {
	char string[20];
	int contrast;
	fill_rectangle(0, 0, 131, 131, WHITE);
	wg_text_init(&state4_title, 25, 10, "Contraste");
	contrast = lcd_read_contrast();
	sprintf(string, "%d", contrast);
	wg_text_init(&state4_contrast, 25, 30, string);
	fill_rectangle(0, 50, 20, 20, RED);
	fill_rectangle(20, 50, 20, 20, GREEN);
	fill_rectangle(40, 50, 20, 20, BLUE);
	fill_rectangle(60, 50, 20, 20, YELLOW);
	fill_rectangle(80, 50, 20, 20, WHITE);
	fill_rectangle(100, 50, 20, 20, BLACK);
	draw_hor_line(0, 80, 50, BLACK);
	draw_hor_line(0, 82, 50, BLACK);
	draw_hor_line(0, 84, 50, BLACK);
	draw_ver_line(50, 80, 50, BLACK);
	draw_ver_line(48, 80, 50, BLACK);
	draw_ver_line(46, 80, 50, BLACK);
}
	
static void state4_during() {
	char string[20];
	int contrast;
	event_t event;
	event_read(&event);
	if (event.type == EVENT_KEY_PUSH) {
		switch(event.value) {
			case DOWN:
				contrast = lcd_dec_contrast();
				sprintf(string, "%d", contrast);
				wg_text_write(&state4_contrast, string);
				break;
			case OK:
			case CANC:
				state_machine_change(1);
				break;
			case UP:
				contrast = lcd_inc_contrast();
				sprintf(string, "%d", contrast);
				wg_text_write(&state4_contrast, string);
				break;
		}
	}
}

static void state4_leave() {
	;
}

/*------------------------------------------------------------------------------
*/
static State states[] = {
	{state0_enter, state0_during, state0_leave},	/* Estado 0 - apresenta��o */
	{state1_enter, state1_during, state1_leave},	/* Estado 1 - menu */
	{state2_enter, state2_during, state2_leave},	/* Estado 2 - acerto do rel�gio */
	{state3_enter, state3_during, state3_leave},	/* Estado 3 - despertador */
	{state4_enter, state4_during, state4_leave}};	/* Estado 4 - contraste */

void state_machine_init(int s) {
	state = &states[s];
	state->enter();
}

void state_machine_step() {
	state->during();
}

void state_machine_change(int s) {
	state->leave();
	state = &states[s];
	state->enter();
}

void application_init() {
	struct tm tm;
	tm.tm_sec = 0;
	tm.tm_min = 45;
	tm.tm_hour = 3;
	tm.tm_mday = 1;
	tm.tm_mon = 4;
	tm.tm_year = 111;
	mktime(&tm);
	rtc_write(&tm);
	rtc_read(&alarm.tp);
}

int main() {
	button_init();
	alarm_init();
	lcd_init();
	lcd_backlight(1);
	application_init();
	state_machine_init(0);
	while (1) {
		state_machine_step();
	}
}
