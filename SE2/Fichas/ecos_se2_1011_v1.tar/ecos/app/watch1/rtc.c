/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2011

	Funções auxiliares para manipulação do relógio e calendário
*/

#include <time.h>
#include <stdio.h>
#include "rtc.h"

static char * month_text[] = {
	"Janeiro  ",
	"Fevereiro",
	"Marco    ",
	"Abril    ",
	"Maio     ",
	"Junho    ",
	"Julho    ",
	"Agosto   ",
	"Setembro ",
	"Outubro  ",
	"Novembro ",
	"Dezembro "
};

char * rtc_text_month(int month) {
	return month_text[month];
}

char * rtc_text(int value) {
	static char text[20];
	sprintf(text, "%02d", value);
	return text;
}

void rtc_write(struct tm * tp) {
	time_t t = mktime(tp);
	cyg_libc_time_settime(t);
}

void rtc_read(struct tm * tp) {
	time_t t;
	time(&t);
	*tp = *localtime(&t);
}

int rtc_changed() {
	static time_t previous, t;
	time(&t);
	if (previous + 60 <= t) {
		previous = t;
		return 1;
	}
	return 0;
}

