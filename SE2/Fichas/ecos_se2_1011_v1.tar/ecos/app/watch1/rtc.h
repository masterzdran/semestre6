/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2011

	Funções auxiliares para manipulação do relógio e calendário
*/
#ifndef RTC_H
#define RTC_H

#include <time.h>

static inline void rtc_down_hour(struct tm * tp) {
	if (tp->tm_hour-- == 0)
		tp->tm_hour = 23; 
}

static inline void rtc_down_min(struct tm * tp) {
	if (tp->tm_min-- == 0)
		tp->tm_min = 59; 
}

static inline void rtc_down_sec(struct tm * tp) {
	if (tp->tm_sec-- == 0)
		tp->tm_sec = 59; 
}

static inline void rtc_down_day(struct tm * tp) {
	if (tp->tm_mday-- == 1)
		tp->tm_mday = 31; 
}

static inline void rtc_down_month(struct tm * tp) {
	if (tp->tm_mon-- == 0)
		tp->tm_mon = 11; 
}

static inline void rtc_down_year(struct tm * tp) {
	--tp->tm_year; 
}

static inline void rtc_up_hour(struct tm * tp) {
	if (++tp->tm_hour == 24)
		tp->tm_hour = 0; 
}

static inline void rtc_up_min(struct tm * tp) {
	if (++tp->tm_min == 60)
		tp->tm_min = 0; 
}

static inline void rtc_up_sec(struct tm * tp) {
	if (++tp->tm_sec == 60)
		tp->tm_sec = 0; 
}

static inline void rtc_up_day(struct tm * tp) {
	if (++tp->tm_mday == 31)
		tp->tm_mday = 1; 
}

static inline void rtc_up_month(struct tm * tp) {
	if (++tp->tm_mon == 12)
		tp->tm_mon = 0; 
}

static inline void rtc_up_year(struct tm * tp) {
	++tp->tm_year;
}

char * rtc_text_month(int month);
char * rtc_text(int value);
void rtc_write(struct tm * tp);
void rtc_read(struct tm * tp);
int rtc_changed();
void rtc_init();

#endif
