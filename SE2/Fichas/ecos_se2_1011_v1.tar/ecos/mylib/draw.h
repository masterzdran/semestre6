/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2009

	Func�es b�sicas de desenho
*/

#ifndef DRAW_H
#define DRAW_H

#include <cyg/infra/cyg_type.h>

void draw_point(int x, int y, int color);
void draw_line(int x0, int y0, int x1, int y1, int color);
/*void draw_polygon(struct {int x; int y;} * points, int n_points, int color);
void fill_polygon(struct {int x; int y;} * points, int n_points, int color); */
void draw_ellipse(int x, int y, int rx, int ry, int color);
void fill_ellipse(int x, int y, int rx, int ry, int color);
void write_image(int x, int y, int dx, int dy, cyg_uint8 * image);

void draw_hor_line(int x, int y, int  dx, int color);
void draw_ver_line(int x, int y, int  dy, int color);
void draw_rectangle(int x, int y, int dx, int dy, int color);
void fill_rectangle(int x, int y, int dx, int dy, int color);
void draw_circle(int x, int y, int r, int color);
void fill_circle(int x, int y, int r, int color);
void draw_text(int x, int y, char * text, int color);
int draw_text_width();
int draw_text_height();
void write_bitmap(int x, int y, int dx, int dy, cyg_uint8 *);

#endif
