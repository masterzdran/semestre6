/*	Instituto Superior de Engenharia de	Lisboa
	Ezequiel Conde,	2010
*/
#ifndef CHRONO_H
#define CHRONO_H

/*	Estas fun��es l�m o contador de tics que � um contador a 32 bit,
	1 tic � normalmente 10 ms,
	portanto d� para medir tempos at� 10 ms * 2^32 = 497 dias,
	com a precis�o de 10 ms */

#include <cyg/kernel/kapi.h>
#include <cyg/hal/hal_intr.h>

static inline cyg_uint32 chrono_start(void) { return cyg_current_time(); }

static inline cyg_uint32 chrono_restart(cyg_uint32 i, cyg_uint32 t) { return i + t; }

static inline cyg_uint32 chrono_elapsed(cyg_uint32 i) {	return cyg_current_time() - i; }

/*-----------------------------------------------------------------------------
*/

static inline int chrono_timeout(cyg_uint32 i, cyg_uint32 t) { return chrono_elapsed(i) > t; }
 
static inline void chrono_wait(cyg_uint32 i, cyg_uint32 t) {
	cyg_uint32 elapsed = chrono_elapsed(i);
	if (elapsed < t)
		cyg_thread_delay(t - elapsed);
}

static inline cyg_uint32 chrono_remainder(cyg_uint32 i, cyg_uint32 t) {
	cyg_uint32 elapsed = chrono_elapsed(i);
	return elapsed < t ? t - elapsed : 0;
}

static inline void chrono_delay(cyg_uint32 d) {
	cyg_thread_delay(d);
}

static inline cyg_uint64 tick2nsec(cyg_uint32 ticks) {
	return ticks * CYGNUM_HAL_RTC_NUMERATOR / CYGNUM_HAL_RTC_DENOMINATOR;
}

static inline cyg_uint32 nsec2tic(cyg_uint64 nsec) {
	return nsec * CYGNUM_HAL_RTC_DENOMINATOR / CYGNUM_HAL_RTC_NUMERATOR;
}
static inline cyg_uint32 usec2tic(cyg_uint32 usec) {
	return usec * CYGNUM_HAL_RTC_DENOMINATOR / (CYGNUM_HAL_RTC_NUMERATOR / 1000);
}
static inline cyg_uint32 msec2tic(cyg_uint32 msec) {
	return msec * CYGNUM_HAL_RTC_DENOMINATOR / (CYGNUM_HAL_RTC_NUMERATOR / 1000000);
}
#endif

