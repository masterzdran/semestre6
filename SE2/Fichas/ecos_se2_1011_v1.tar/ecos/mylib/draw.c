/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2009

	Implementa��o das func�es b�sicas de desenho independente do dispositivo
*/

#include "lcd.h"
#include "draw.h"

void draw_point(int x, int y, int color) {
	lcd_draw_point(x, y, color);
}

void draw_hor_line(int x, int y, int  dx, int color) {
	lcd_draw_hor_line(x, y, dx, color);
}

void draw_ver_line(int x, int y, int  dy, int color) {
	lcd_draw_ver_line(x, y, dy, color);
}

void fill_rectangle(int x, int y, int dx, int dy, int color) {
	lcd_fill_rectangle(x, y, dx, dy, color);
}

void write_bitmap(int x, int y, int dx, int dy, cyg_uint8 * bitmap) {
	lcd_copy_rectangle(x, y, dx, dy, bitmap);
}

void draw_line(int x0, int y0, int x1, int y1, int color) {
	int dy = y1 - y0;
	int dx = x1 - x0;
	int stepx, stepy;
	if (dy < 0) { 
		dy = -dy;
		stepy = -1;
	} else {
		stepy = 1; 
	}
	if (dx < 0) {
		dx = -dx;
		stepx = -1;
	} else {
		stepx = 1; 
	}
	dy <<= 1;
	dx <<= 1;
	draw_point(x0, y0, color);
	if (dx > dy) {
		int fraction = dy - (dx >> 1);
		while (x0 != x1) {
			if (fraction >= 0) {
				y0 += stepy;
				fraction -= dx;
			}
			x0 += stepx;
			fraction += dy;
			draw_point(x0, y0, color);
		}
	} else {
		int fraction = dx - (dy >> 1);
		while (y0 != y1) {
			if (fraction >= 0) {
				x0 += stepx;
				fraction -= dy;
			}
			y0 += stepy;
			fraction += dx;
			draw_point(x0, y0, color);
		}
	}
}

void draw_rectangle(int x, int y, int dx, int dy, int color) {
	draw_hor_line(x, y, dx, color);
	draw_hor_line(x, y + dy - 1, dx, color);
	draw_ver_line(x, y, dy, color);
	draw_ver_line(x + dx - 1, y, dy, color);
}

void draw_ellipse(int x, int y, int rx, int ry, int color) {
/* Algorithm from IEEE CG&A Sept 1984 p.24 */
	int t1 = rx * rx, t2 = t1 * 2, t3 = t2 * 2;
	int t4 = ry * ry, t5 = t4 * 2, t6 = t5 * 2;
	int t7 = rx * t5, t8 = t7 * 2, t9 = 0;
	int d1 = t2 - t7 + t4 / 2;
	int d2 = t1 / 2 - t8 + t5;
	int ex = rx, ey = 0;
	while (d2 < 0) {
		draw_point(x + ex, y + ey, color);
		draw_point(x + ex, y - ey, color);
		draw_point(x - ex, y + ey, color);
		draw_point(x - ex, y - ey, color);
		ey++;
		t9 += t3;
		if (d1 < 0) {
			d1 += t9 + t2;
			d2 += t9;
		} else {
			ex--;
			t8 -= t6;
			d1 += t9 + t2 - t8;
			d2 += t9 + t5 - t8;
		}
	}
	do {
		draw_point(x + ex, y + ey, color);
		draw_point(x + ex, y - ey, color);
		draw_point(x - ex, y + ey, color);
		draw_point(x - ex, y - ey, color);
		ex--;
		t8 -= t6;
		if (d2 < 0) {
			ey++;
			t9 += t3;
			d2 += t9 + t5 - t8;
		} else {
			d2 += t5 - t8;
		}
	}
	while (ex >= 0);
}

void fill_ellipse(int x, int y, int rx, int ry, int color) {
	int t1 = rx * rx, t2 = t1 * 2, t3 = t2 * 2;
	int t4 = ry * ry, t5 = t4 * 2, t6 = t5 * 2;
	int t7 = rx * t5, t8 = t7 * 2, t9 = 0;
	int d1 = t2 - t7 + t4 / 2;
	int d2 = t1 / 2 - t8 + t5;
	int ex = rx, ey = 0;
	while (d2 < 0) {
		draw_hor_line(x - ex, y + ey, ex << 1, color);
		draw_hor_line(x - ex, y - ey, ex << 1, color);
		ey++;
		t9 += t3;
		if (d1 < 0) {
			d1 += t9 + t2;
			d2 += t9;
		} else {
			ex--;
			t8 -= t6;
			d1 += t9 + t2 - t8;
			d2 += t9 + t5 - t8;
		}
	}
	do {
		draw_hor_line(x - ex, y + ey, ex << 1, color);
		draw_hor_line(x - ex, y - ey, ex << 1, color);
		ex--;
		t8 -= t6;
		if (d2 < 0) {
			ey++;
			t9 += t3;
			d2 += t9 + t5 - t8;
		} else {
			d2 += t5 - t8;
		}
	} 
	while (ex >= 0);
}

#include "font.c"
/*	A tabela de fontes come�a no caracter espa�o

cyg_uint8 font[] = {
...
0x7f,	'E'
0x40,
0x40,
0x40,
0x7e,
0x40,
0x40,
0x40,
0x7f,
0x00,
0x00,
...
*/

void draw_text(int x, int y, char * text, int color) {
	int i, j, t = 0;
	while (*text != '\0') {
		cyg_uint8 * bitmap = &font[(*text++ - ' ') * 11];
		for (j = 0; j < 11; ++j)
			for (i = 0; i < 8; ++i)
				if (bitmap[j] & (1 << i))
					draw_point(x + (t * 8) + (8 - i), y + j, color);
		t++;
	}
}

int draw_text_width() {
	return 8;
}

int draw_text_height() {
	return 11;
}
