#ifndef DEFS_H
#define DEFS_H

#define max(a,b) ((a)>(b)?(a):(b))

#define min(a,b) ((a)<(b)?(a):(b))

#define sizeof_array(x) (sizeof(x) / sizeof(x[0]))

#if 0
#define	offsetof(TYPE, MEMBER) (size_t) \
	((char *)&(((TYPE *)0)->MEMBER) - (char *) 0)
#endif

#if 1
#define containerof(TYPE, MEMBER, ADDRESS) \
	((TYPE *) ((char *)(ADDRESS) - offsetof(TYPE, MEMBER)))
#endif

#if 0
#define containerof(ptr, type, member) ({ \
                const typeof( ((type *)0)->member ) *__mptr = (ptr); \
                (type *)( (char *)__mptr - offsetof(type,member) );})
#endif

#endif
