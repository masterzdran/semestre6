#ifndef COLOR_H
#define COLOR_H

enum Color { WHITE = 0xFFF, BLACK = 0x000, RED = 0xF00, GREEN = 0x0F0, BLUE = 0x00F, CYAN = 0x0FF,
			 MAGENTA = 0xF0F, YELLOW = 0xFF0, BROWN = 0xB22, ORANGE = 0xFA0, PINK = 0xF6A };

#endif
