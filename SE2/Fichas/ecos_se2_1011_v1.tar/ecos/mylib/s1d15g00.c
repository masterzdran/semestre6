/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2011

	Acesso ao controlador S1D15G00
	Func�es b�sicas de desenho em formato RGB
*/

#include <pkgconf/hal.h>
#include <cyg/infra/cyg_type.h>         // base types
#include <cyg/hal/hal_io.h>             // low level i/o
#include <cyg/hal/var_io.h>             // common registers

#include <cyg/infra/diag.h>
#include <cyg/kernel/kapi.h>
#include <cyg/io/spi_lpc2xxx.h>
#include "defs.h"

#define RESET_PIN	14
#define CS_PIN		8
#define BACKLIGHT_PIN	10

#define LPC2XXX_PINSEL0_GPIO(p)			(~(3 << ((p) << 1)))

static void cs(int select) {
	if (select)
		HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE +
			CYGARC_HAL_LPC2XXX_REG_IOCLR, 1 << CS_PIN);
	else
		HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE +
			CYGARC_HAL_LPC2XXX_REG_IOSET, 1 << CS_PIN);		
}

cyg_spi_bitbang_dev_t spi_s1d15g00_dev CYG_SPI_DEVICE_ON_BUS(2) = {

    .spi_device.spi_bus = &cyg_spi_lpc2xxx_bus2.spi_bus,

    .spi_cpha	= 0,		// Clock phase (0 or 1)
    .spi_cpol	= 0,   	    // Clock polarity (0 or 1)
	.spi_lsbf	= 0,		// MSBF
    .spi_nbits 	= 9,		// bits per word

	.spi_cs		= cs
};

/* Epson S1D15G00 LCD controller command codes */
#define DISON	0xAF	/* Display on */
#define DISOFF	0xAE	/* Display off */
#define DISNOR	0xA6 	/* Normal display */
#define DISINV	0xA7 	/* Inverse display */
#define COMSCN	0xBB 	/* Common scan direction */
#define DISCTL	0xCA 	/* Display control */
#define SLPIN	0x95 	/* Sleep in */
#define SLPOUT	0x94	/* Sleep out */
#define PASET	0x75 	/* Page address set */
#define CASET	0x15	/* Column address set */
#define DATCTL	0xBC	/* Data scan direction, etc. */
#define RGBSET8 0xCE	/* 256-color position set */
#define RAMWR	0x5C	/* Writing to memory */
#define RAMRD	0x5D	/* Reading from memory */
#define PTLIN	0xA8	/* Partial display in */
#define PTLOUT	0xA9	/* Partial display out */
#define RMWIN	0xE0	/* Read and modify write */
#define RMWOUT	0xEE	/* End */
#define ASCSET	0xAA	/* Area scroll set */
#define SCSTART	0xAB	/* Scroll start set */
#define OSCON	0xD1	/* Internal oscillation on */
#define OSCOFF	0xD2	/* Internal oscillation off */
#define PWRCTR	0x20	/* Power control */
#define VOLCTR	0x81	/* Electronic volume control */
#define VOLUP	0xD6	/* Increment electronic control by 1 */
#define VOLDOWN	0xD7	/* Decrement electronic control by 1 */
#define TMPGRD	0x82	/* Temperature gradient set */
#define EPCTIN	0xCD	/* Control EEPROM */
#define EPCOUT	0xCC	/* Cancel EEPROM control */
#define EPMWR	0xFC	/* Write into EEPROM */
#define EPMRD	0xFD	/* Read from EEPROM */
#define EPSRRD1	0x7C	/* Read register 1 */
#define EPSRRD2	0x7D	/* Read register 2 */
#define NOP		0x25 	/* NOP instruction */


#define SPI_DEV	(cyg_spi_device *)&spi_s1d15g00_dev

static inline void write_command(cyg_uint8 command) {
	cyg_uint16 out_buffer[] = {~0x100 & command};
	cyg_uint16 in_buffer[sizeof(out_buffer)];
	cyg_spi_transaction_transfer(SPI_DEV, true, sizeof_array(out_buffer),
		(cyg_uint8*)out_buffer, (cyg_uint8*)in_buffer, false);
}

static inline void write_data(cyg_uint8 data) {
	cyg_uint16 out_buffer[] = {0x100 | data};
	cyg_uint16 in_buffer[sizeof(out_buffer)];
	cyg_spi_transaction_transfer(SPI_DEV, true, sizeof_array(out_buffer),
		(cyg_uint8*)out_buffer, (cyg_uint8*)in_buffer, false);
}

void lcd_backlight(int on) {
	if (on)
		HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE + CYGARC_HAL_LPC2XXX_REG_IOSET,
			1 << BACKLIGHT_PIN);
	else
		HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE + CYGARC_HAL_LPC2XXX_REG_IOCLR,
			1 << BACKLIGHT_PIN);
}

static int contrast = 42;

int lcd_read_contrast(void) {
	return contrast;
}

int lcd_inc_contrast(void) {
	if (++contrast >= 64)
		contrast = 0;
	cyg_spi_transaction_begin(SPI_DEV);
	write_command(VOLCTR);
	write_data(contrast);
	write_data(3);
	cyg_spi_transaction_end(SPI_DEV);
	return contrast;
}

int lcd_dec_contrast(void) {
	if (--contrast < 0)
		contrast = 63;
	cyg_spi_transaction_begin(SPI_DEV);
	write_command(VOLCTR);
	write_data(contrast);
	write_data(3);
	cyg_spi_transaction_end(SPI_DEV);
	return contrast;
}

void lcd_init(void) {

	/* deactivate RESET and BACKLIGHT */
	HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE + CYGARC_HAL_LPC2XXX_REG_IOSET,
		1 << RESET_PIN);
	HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE + CYGARC_HAL_LPC2XXX_REG_IOSET,
		1 << BACKLIGHT_PIN);	

	/* program CS, BACKLIGHT and RESET pins as outputs */
	HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE + CYGARC_HAL_LPC2XXX_REG_IOSET,
		1 << CS_PIN);
	cyg_uint32 iodir;
	HAL_READ_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE + CYGARC_HAL_LPC2XXX_REG_IODIR, iodir);
	HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE + CYGARC_HAL_LPC2XXX_REG_IODIR,
		iodir |	(1 << CS_PIN) | (1 << RESET_PIN) | (1 << BACKLIGHT_PIN));

	/* switch pins to GPIO */
	cyg_uint32 pinsel;
	HAL_READ_UINT32(CYGARC_HAL_LPC2XXX_REG_PIN_BASE + CYGARC_HAL_LPC2XXX_REG_PINSEL0, pinsel);
	HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_PIN_BASE + CYGARC_HAL_LPC2XXX_REG_PINSEL0,
		pinsel & LPC2XXX_PINSEL0_GPIO(CS_PIN) &
		LPC2XXX_PINSEL0_GPIO(RESET_PIN) & LPC2XXX_PINSEL0_GPIO(BACKLIGHT_PIN));
		
	/* reste controller */
	HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE + CYGARC_HAL_LPC2XXX_REG_IOCLR, 1 << RESET_PIN);				/* activar o sinal reset */
	HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE + CYGARC_HAL_LPC2XXX_REG_IOCLR, 1 << RESET_PIN);				/* activar o sinal reset */
	HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE + CYGARC_HAL_LPC2XXX_REG_IOSET, 1 << RESET_PIN);				/* desactivar o sinal reset */

	cyg_spi_transaction_begin(SPI_DEV);

	write_command(DISCTL);		/*	display control */
	write_data(0x00);			/* P1: 0x00 = 2 divisions, switching period=8 (default) */
	write_data(32);				/* P2: nlines/4 - 1 = 132/4 - 1 = 32) */
	write_data(00);				/* P3: 0x00 = no inversely highlighted lines */
	write_command(COMSCN);		/* COM scan */
	write_data(1);				/* P1: 0x01 = Scan 1->80, 160<-81 */
	write_command(OSCON);		/* Internal oscilator ON */
	write_command(SLPOUT);		/* sleep out */
	write_command(VOLCTR);		/* Voltage control (contrast setting) */
	write_data(contrast);		/* P1 = 32 volume value (experiment with this value to get the best contrast) */
	write_data(3);				/* P2 = 3 resistance ratio (only value that works) */
	write_command(PWRCTR);		/* Power control */
	write_data(0x0f);			/* reference voltage regulator on, circuit voltage follower on, BOOST ON */
	write_command(DATCTL);		/* Data control */
	write_data(0x00);			/* P1: 0x00 = page address normal, column address normal, address scan in column direction */
	write_data(0x00);			/* P2: 0x00 = RGB sequence (default value) */
	write_data(0x02);			/* P3: 0x02 = Grayscale -> 16 (selects 12-bit color, type A) */	
	write_command(DISON);		/* Display on */

	cyg_spi_transaction_end(SPI_DEV);
}

/*	Color image

	0			 |1			  |2			|3			 |4			   |5			|6			pixel
	RRRRGGGG BBBBRRRR GGGGBBBB RRRRGGGG BBBBRRRR GGGGBBBB RRRRGGGG BBBBRRRR GGGGBBBB RRRRGGGG
	0		 1		  2		   3		4		 5		  6		   7		8		 9			mem�ria
	7	   0 7		0
*/

void lcd_draw_point(int x, int y, int color) {
	cyg_spi_transaction_begin(SPI_DEV);
	write_command(CASET);		/* Column address set (command 0x2A) */
	write_data(x);
	write_data(x);
	write_command(PASET);		/* Page address set (command 0x2B) */
	write_data(y);
	write_data(y);
	write_command(RAMWR);		/* write memory */
	write_data(color >> 4);
	write_data((color << 4) & 0xf0);
	write_data(0);
	write_command(NOP);
	cyg_spi_transaction_end(SPI_DEV);
}

void lcd_draw_hor_line(int x, int y, int  dx, int color) {
	int i;
	cyg_spi_transaction_begin(SPI_DEV);
	write_command(CASET);
	write_data(x);
	write_data(x + dx - 1);
	write_command(PASET);
	write_data(y);
	write_data(y);
	write_command(RAMWR);
	for (i = (dx + 1) / 2; i > 0; --i) {
		write_data(color >> 4);
		write_data(((color << 4) & 0xf0) | ((color >> 8) & 0xf));
		write_data(color);
	}
	write_command(NOP);
	cyg_spi_transaction_end(SPI_DEV);
}
	
void lcd_draw_ver_line(int x, int y, int  dy, int color) {
	int i;
	cyg_spi_transaction_begin(SPI_DEV);
	write_command(CASET);
	write_data(x);
	write_data(x);
	write_command(PASET);
	write_data(y);
	write_data(y + dy - 1);
	write_command(RAMWR);
	for (i = (dy + 1) / 2; i > 0; --i) {
		write_data(color >> 4);
		write_data(((color << 4) & 0xf0) | ((color >> 8) & 0xf));
		write_data(color);
	}
	write_command(NOP);
	cyg_spi_transaction_end(SPI_DEV);
}

void lcd_fill_rectangle(int x, int y, int dx, int dy, int color) {
	int i;
	cyg_spi_transaction_begin(SPI_DEV);
	write_command(CASET);
	write_data(x);
	write_data(x + dx - 1);
	write_command(PASET);
	write_data(y);
	write_data(y + dy - 1);
	write_command(RAMWR);
	for (i = (dx * dy + 1) / 2; i > 0; --i) {
		write_data(color >> 4);
		write_data(((color << 4) & 0xf0) | ((color >> 8) & 0xf));
		write_data(color);
	}
	write_command(NOP);
	cyg_spi_transaction_end(SPI_DEV);
}

void lcd_copy_rectangle(int x, int y, int dx, int dy, cyg_uint8 * bitmap) {
	int i;
	cyg_spi_transaction_begin(SPI_DEV);
	write_command(CASET);
	write_data(x);
	write_data(x + dx - 1);
	write_command(PASET);
	write_data(y);
	write_data(y + dy - 1);
	write_command(RAMWR);
	for (i = (dx * dy + 1) / 2 + 1; i > 0; --i) {
		write_data(*bitmap++);
	}
	write_command(NOP);
	cyg_spi_transaction_end(SPI_DEV);
}
