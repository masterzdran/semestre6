/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2009

	Objectos gr�ficos para interface de utilizador
*/

#include <stdlib.h>
#include <string.h>
#include "defs.h"
#include "lcd.h"
#include "widget.h"
#include "color.h"

/*------------------------------------------------------------------------------
	Mensagem de texto
*/

void wg_text_init(Wg_text * this, int x, int y, char * text) {
	strncpy(this->text, text, sizeof(this->text));
	this->x = x;
	this->y = y;
	this->text_color = BLACK;
	this->background_color = WHITE;
	this->focus = 0;
	this->dx = 0;
	this->dy = 0;
	wg_text_paint(this);
}

void wg_text_paint(Wg_text * this) {
	fill_rectangle(this->x, this->y, this->dx + 1, this->dy + 1, this->background_color);
	this->dx = strlen(this->text) * draw_text_width();
	this->dy = draw_text_height();
	draw_text(this->x, this->y, this->text, this->text_color);
	if (this->focus)
		draw_line(this->x, this->y + this->dy, this->x + this->dx, this->y + this->dy, this->text_color);
}

void wg_text_position(Wg_text * this, int x, int y) {
	this->x = x;
	this->y = y;
}

void wg_text_color(Wg_text * this, int text_color, int background_color) {
	this->text_color = text_color;
	this->background_color = background_color;
}

void wg_text_write(Wg_text * this, char * text) {
	strncpy(this->text, text, sizeof(this->text) - 1);
	wg_text_paint(this);
}

void wg_text_clean(Wg_text * this) {
	int dx = strlen(this->text) * draw_text_width();
	int dy = draw_text_height();
	fill_rectangle(this->x, this->y, dx + 1, dy + 1, this->background_color);
	wg_text_paint(this);
}

void wg_text_focus_in(Wg_text * this) {
	this->focus = 1;
	wg_text_paint(this);
}

void wg_text_focus_out(Wg_text * this) {
	this->focus = 0;
	wg_text_paint(this);
}

/*------------------------------------------------------------------------------
	Caixa de marca��o
*/

void wg_check_init(Wg_check_box * this, int x, int y, char * text, int s) {
	strncpy(this->text, text, sizeof(this->text));
	this->x = x;
	this->y = y;
	this->text_color = BLACK;
	this->background_color = WHITE;
	this->focus = 0;
	this->dx = 0;
	this->dy = 0;
	this->state = s;
	wg_check_paint(this);
}

void wg_check_paint(Wg_check_box * this) {
	fill_rectangle(this->x, this->y, this->dx + 1, this->dy + 1, this->background_color);
	this->dx = strlen(this->text) * draw_text_width();
	this->dy = draw_text_height();
	draw_text(this->x + draw_text_width() + 4, this->y, this->text, this->text_color);
	if (this->focus)
		draw_hor_line(this->x + draw_text_width() + 4, this->y + this->dy, this->dx, this->text_color);
	draw_rectangle(this->x, this->y, draw_text_width(), draw_text_height(), this->text_color);
	if (this->state == 1) {
		draw_line(this->x, this->y, this->x + draw_text_width() - 1, this->y + draw_text_height() - 1, this->text_color);
		draw_line(this->x + draw_text_width() - 1, this->y, this->x, this->y + draw_text_height() - 1, this->text_color);
	}
}

void wg_check_position(Wg_check_box * this, int x, int y) {
	this->x = x;
	this->y = y;
}

void wg_check_color(Wg_check_box * this, int text_color, int background_color) {
	this->text_color = text_color;
	this->background_color = background_color;
}

void wg_check_focus_in(Wg_check_box * this) {
	this->focus = 1;
	wg_check_paint(this);
}

void wg_check_focus_out(Wg_check_box * this) {
	this->focus = 0;
	wg_check_paint(this);
}

void wg_check_set_state(Wg_check_box * this, int s) {
	this->state = s;
	wg_check_paint(this);
}

int wg_check_get_state(Wg_check_box * this) {
	return this->state;
}

/*------------------------------------------------------------------------------
	Lista de elementos
*/
Icon scroll_up = {8, 9, (cyg_uint8 *)
	"\x1c"
	"\x36"
	"\x63"
	"\x49"
	"\x1c"
	"\x36"
	"\x63"
	"\x41"
};

Icon scroll_down = {8, 9, (cyg_uint8 *)
	"\x41"
	"\x63"
	"\x36"
	"\x1c"
	"\x49"
	"\x63"
	"\x36"
	"\x1c"
	"\x08"
};

void wg_list_paint(Wg_list * this) {
	char * * ptr;
	int i, dx = this->columns * draw_text_width() + 2;
	/* Desenhar a quadricula */
	int line_height = draw_text_height() + 2 + 2 + 1;
	draw_ver_line(this->x, this->y, this->lines * line_height, BLACK); 
	draw_ver_line(this->x + dx, this->y, this->lines * line_height, BLACK); 
	for (i = 0; i < this->lines; ++i)
		draw_hor_line(this->x, this->y + i * line_height, dx, BLACK);
	draw_hor_line(this->x, this->y + i * line_height, dx, BLACK);
	
	/* Escrever o texto */
	for (i = 0, ptr = this->begin; ptr < this->end; ++ptr, ++i)
		if (ptr == this->current) {
			fill_rectangle(this->x + 1, this->y + 1 + line_height * i, dx - 1, line_height - 1, BLACK);
			draw_text(this->x + 3, this->y + 3 + line_height * i, *ptr, WHITE);
		}		
		else {
			fill_rectangle(this->x + 1, this->y + 1 + line_height * i, dx - 1, line_height - 1, WHITE);
			draw_text(this->x + 3, this->y + 3 + line_height * i, *ptr, BLACK);
		}
	/* Indica��o de scroll. Se existirem elementos na lista para al�m dos vis�veis */
	fill_rectangle(this->x + dx + 2, this->y + 2, scroll_up.dx, scroll_up.dy, WHITE);
	if (this->begin > this->list_begin)
		write_bitmap(this->x + dx + 2, this->y + 2, scroll_up.dx, scroll_up.dy, scroll_up.bitmap);
	fill_rectangle(this->x + dx + 2, this->y + line_height * (this->lines - 1) + 3, scroll_down.dx, scroll_down.dy, WHITE);
	if (this->end < this->list_ptr)
		write_bitmap(this->x + dx + 2, this->y + line_height * (this->lines - 1) + 3,
			scroll_down.dx, scroll_down.dy, scroll_down.bitmap);
}

#if 0
void wg_list_init(Wg_list * this, int x, int y, int columns, int lines, int list_size, int line_size) {
	char * * ptr;
	this->x = x;
	this->y = y;
	this->columns = columns;
	this->lines = lines;
	this->list_begin = this->list_ptr = this->begin = 
		this->end = this->current = malloc(list_size * sizeof (char *));
	this->list_end = this->list_begin + list_size;
	for (ptr = this->list_begin; ptr < this->list_end; ++ptr) {
		*ptr = malloc(line_size);
/*		assert(*ptr != 0); */
	}
	this->line_size = line_size;
	wg_list_paint(this);
}

#endif

void wg_list_add(Wg_list * this, char * text) {
	if (this->list_ptr < this->list_end)
		strncpy(*this->list_ptr++, text, this->line_size);
	if (this->end - this->begin < this->lines)
		this->end++;
	wg_list_paint(this);
}

void wg_list_remove(Wg_list * this, char * text) {
	char * * ptr;
	for (ptr = this->list_begin; ptr < this->list_ptr; ++ptr)
		if (strcmp(*ptr, text) == 0) {
			char * aux = *ptr;
			memmove(ptr, ptr + 1, (this->list_ptr - ptr) * sizeof(char*));
			*this->list_ptr-- = aux;
			if (this->list_ptr < this->end)
				this->end--;
			break;
		}
	wg_list_paint(this);
}

void wg_list_up(Wg_list * this) {
	if (this->current > this->begin)
		this->current--;
	else if (this->begin > this->list_begin) {
		this->begin--;
		this->end--;
		this->current--;
	}
	wg_list_paint(this);
}

void wg_list_down(Wg_list * this) {
	if (this->current < this->end - 1)
		this->current++;
	else if (this->end < this->list_ptr && this->end - this->begin == this->lines) {
		this->begin++;
		this->end++;
		this->current++;
	}
	wg_list_paint(this);
}

char * wg_list_current(Wg_list * this) {
	return *this->current;
}

/*------------------------------------------------------------------------------
	Rel�gio anal�gico
*/
static int sin_table[] = {
	-1000,
	-995,
	-978,
	-951,
	-914,
	-866,
	-809,
	-743,
	-669,
	-588,
	-500,
	-407,
	-309,
	-208,
	-105,
	0,
	105,	
	208,
	309,
	407,
	500,	
	588,
	669,
	743,	
	809,
	866,
	914,
	951,
	978,
	995,
	1000,		/* sin(15 * 90 / 15) */
	995,		/* sin(14 * 90 / 15) */
	978,		/* sin(13 * 90 / 15) */
	951,		/* sin(12 * 90 / 15) */
	914,		/* sin(11 * 90 / 15) */
	866,		/* sin(10 * 90 / 15) */
	809,		/* sin(9 * 90 / 15) */
	743,		/* sin(8 * 90 / 15) */
	669,		/* sin(7 * 90 / 15) */
	588,		/* sin(6 * 90 / 15) */
	500,		/* sin(5 * 90 / 15) */
	407,		/* sin(4 * 90 / 15) */
	309,		/* sin(3 * 90 / 15) */
	208,		/* sin(2 * 90 / 15) */
	105,		/* sin(1 * 90 / 15) */
	0,			/* sin(0 * 90 / 15) */
	-105,	
	-208,
	-309,
	-407,
	-500,	
	-588,
	-669,
	-743,	
	-809,
	-866,	
	-914,
	-951,	
	-978,	
	-995,	
	-1000
};

static int cos_table[] = {
	0,
	105,	
	208,
	309,
	407,
	500,	
	588,
	669,
	743,	
	809,
	866,	
	914,
	951,	
	978,	
	995,	
	1000,
	995,
	978,
	951,
	914,
	866,
	809,
	743,
	669,
	588,
	500,
	407,
	309,
	208,
	105,
	0,
	-105,	
	-208,
	-309,
	-407,
	-500,	
	-588,
	-669,
	-743,	
	-809,
	-866,	
	-914,
	-951,	
	-978,	
	-995,	
	-1000,
	-995,	
	-978,	
	-951,	
	-914,
	-866,	
	-809,
	-743,	
	-669,
	-588,
	-500,	
	-407,
	-309,
	-208,
	-105,	
	0,
};

/* O parametro � o minuto do lugar */
#define cos(x)	cos_table[x]
#define sin(x)	sin_table[x]

#define ANALOG_SIZE				32
#define MINUTE_POINTER_SIZE		28
#define HOUR_POINTER_SIZE 		20

void wg_analog_clock_init(Wg_analog_clock * this, int x, int y, int size, int pc, int mc, int bc) {
	this->x = x;
	this->y = y;
	this->size = size;
	this->pointer_color = pc;
	this->mark_color = mc;
	this->background_color = bc;
	this->hour_pointer = size - 3 * size / 8;
	this->min_pointer = size - size / 8;
	fill_ellipse(x + size * cos(5) / 1000,  y + size * sin(5) / 1000 , 2, 2, this->mark_color);	/* 1 horas */
	fill_ellipse(x + size * cos(10) / 1000, y + size * sin(10) / 1000, 2, 2, this->mark_color);	/* 2 horas */
	fill_ellipse(x + size * cos(15) / 1000, y + size * sin(15) / 1000, 3, 3, this->mark_color);	/* 3 horas */
	fill_ellipse(x + size * cos(20) / 1000, y + size * sin(20) / 1000, 2, 2, this->mark_color);	/* 4 horas */
	fill_ellipse(x + size * cos(25) / 1000, y + size * sin(25) / 1000, 2, 2, this->mark_color);	/* 5 horas */
	fill_ellipse(x + size * cos(30) / 1000, y + size * sin(30) / 1000, 3, 3, this->mark_color);	/* 6 horas */
	fill_ellipse(x + size * cos(35) / 1000, y + size * sin(35) / 1000, 2, 2, this->mark_color);	/* 7 horas */
	fill_ellipse(x + size * cos(40) / 1000, y + size * sin(40) / 1000, 2, 2, this->mark_color);	/* 8 horas */
	fill_ellipse(x + size * cos(45) / 1000, y + size * sin(45) / 1000, 3, 3, this->mark_color);	/* 9 horas */
	fill_ellipse(x + size * cos(50) / 1000, y + size * sin(50) / 1000, 2, 2, this->mark_color);	/* 10 horas */
	fill_ellipse(x + size * cos(55) / 1000, y + size * sin(55) / 1000, 2, 2, this->mark_color);	/* 11 horas */
	fill_ellipse(x + size * cos(60) / 1000, y + size * sin(60) / 1000, 3, 3, this->mark_color);	/* 12 horas */
	wg_analog_clock_paint(this);
}

void wg_analog_clock_paint(Wg_analog_clock * this) {
	int aux = ((this->hour % 12) * 60 / 12) + (this->min * 5 / 60);
	int x = this->x, y = this->y;
	fill_ellipse(x, y, this->min_pointer, this->min_pointer, this->background_color); /* limpar */
	fill_ellipse(x, y, 2, 2, BLACK);	/* centro */
	draw_line(x, y, x + this->hour_pointer * cos(aux) / 1000, y + this->hour_pointer * sin(aux) / 1000, this->pointer_color);
	draw_line(x, y, x + this->min_pointer * cos(this->min) / 1000, y + this->min_pointer * sin(this->min) / 1000, this->pointer_color);
}

void wg_analog_clock_write(Wg_analog_clock * this, int hour, int minute, int second) {
	this->hour = hour;
	this->min = minute;
	this->sec = second;
	wg_analog_clock_paint(this);
}	

void wg_analog_clock_set_color(Wg_analog_clock * this, int pc, int mc, int bc) {
	this->pointer_color = pc;
	this->mark_color = mc;
	this->background_color = bc;
}

void wg_analog_clock_set_geometry(Wg_analog_clock * this, int x, int y, int size) {
	this->x = x;
	this->y = y;
	this->size = size;
}

void wg_update() {
}
