/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2009

	Objectos gr�ficos para interface de utilizador
*/

#ifndef GUI_H
#define GUI_H

#include "defs.h"
#include "draw.h"
#include "color.h"

typedef struct {
	int dx, dy;
	cyg_uint8 * bitmap;
} Icon;

/*------------------------------------------------------------------------------
	Linha de texto
*/
typedef struct {
	int x, y, dx, dy;
	char text[240];
	int text_color, background_color;
	int focus;
} Wg_text;

void wg_text_init(Wg_text * this, int x, int y, char * text);
void wg_text_paint(Wg_text * this);
void wg_text_position(Wg_text * this, int x, int y);
void wg_text_color(Wg_text * this, int text_color, int background_color);
void wg_text_write(Wg_text * this, char * text);
void wg_text_clean(Wg_text * this);
void wg_text_focus_in(Wg_text * this);
void wg_text_focus_out(Wg_text * this);

/*------------------------------------------------------------------------------
	Caixa de marca��o
*/
typedef struct {
	int x, y, dx, dy;
	char text[240];
	int text_color, background_color;
	int focus;
	int state;
} Wg_check_box;

void wg_check_init(Wg_check_box * this, int x, int y, char * text, int s);
void wg_check_paint(Wg_check_box * this);
void wg_check_position(Wg_check_box * this, int x, int y);
void wg_check_color(Wg_check_box * this, int text_color, int background_color);
void wg_check_focus_in(Wg_check_box * this);
void wg_check_focus_out(Wg_check_box * this);
void wg_check_set_state(Wg_check_box * this, int);
int wg_check_get_state(Wg_check_box * this);

/*------------------------------------------------------------------------------
	Lista de strings
*/
typedef struct {
	int x, y;
	int columns, lines;
	char ** list_begin, ** list_end, ** list_ptr, ** begin, ** end, ** current;
	int line_size;
} Wg_list;

void wg_list_init(Wg_list * this, int x, int y, int columns, int lines, int list_size, int line_size);
void wg_list_paint(Wg_list * this);
void wg_list_set_geometry(Wg_list * this, int x, int y, int dx, int dy);
void wg_list_add(Wg_list * this, char * text);
void wg_list_remove(Wg_list * this, char * text);
void wg_list_up(Wg_list * this);
void wg_list_down(Wg_list * this);
char * wg_list_current(Wg_list * this);

/*------------------------------------------------------------------------------
		Rel�gio anal�gico
*/
typedef struct {
	int x, y, size;
	int hour_pointer, min_pointer, sec_pointer;
	int hour, min, sec;
	int pointer_color, mark_color, background_color;
} Wg_analog_clock;

void wg_analog_clock_init(Wg_analog_clock * this, int x, int y, int size, int pc, int mc, int bc);
void wg_analog_clock_paint(Wg_analog_clock * this);
void wg_analog_clock_set_geometry(Wg_analog_clock * this, int x, int y, int size);
void wg_analog_clock_set_color(Wg_analog_clock * this, int pc, int mc, int bc);
void wg_analog_clock_write(Wg_analog_clock * this, int hour, int minute, int second);

void wg_update(void);

#endif
