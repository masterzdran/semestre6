/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2011

	Interface para display gráfico
*/
#ifndef LCD_H
#define LCD_H

void lcd_init(void);
void lcd_backlight(int on);

void lcd_draw_point(int x, int y, int color);
void lcd_draw_hor_line(int x, int y, int  dx, int color);
void lcd_draw_ver_line(int x, int y, int  dy, int color);
void lcd_fill_rectangle(int x, int y, int dx, int dy, int color);
void lcd_copy_rectangle(int x, int y, int dx, int dy, unsigned char * bitmap);

#endif
