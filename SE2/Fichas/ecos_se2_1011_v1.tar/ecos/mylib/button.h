/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2009

	Interface para botões ou teclado
*/

#ifndef BUTTON_H
#define BUTTON_H

#define N_BUTTONS	6

enum Button_state		{ BUTTON_OFF = 0, BUTTON_ON = 1 };
enum Button_transition	{ BUTTON_NONE, BUTTON_TO_OFF, BUTTON_TO_ON }; 

enum Button_state 		button_get_state(int button);
enum Button_transition	button_get_transition(int button);
void button_init(void);

static inline int button_on(int button)
	{ return button_get_state(button) == BUTTON_ON; } 

static inline int button_off(int button) 
	{ return button_get_state(button) == BUTTON_OFF; } 

static inline int button_to_on(int button)
	{ return button_get_transition(button) == BUTTON_TO_ON; } 

static inline int button_to_off(int button)
	{ return button_get_transition(button) == BUTTON_TO_OFF; }

#endif
