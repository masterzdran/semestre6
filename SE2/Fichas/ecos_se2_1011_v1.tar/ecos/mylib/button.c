/*	Instituto Superior de Engenharia de Lisboa
	Ezequiel Conde, 2011

	Interface para bot�es ou teclado ligados em matriz de 2x3
	Implementa��o para o GPIO do LPC2106 
*/

#include <cyg/infra/cyg_type.h>         // base types
#include <cyg/hal/hal_io.h>             // low level i/o
#include <cyg/hal/var_io.h>             // common registers
#include "button.h"
#include "chrono.h"
#include "defs.h"

#define COLUMN_START_PIN	2
#define ROW_START_PIN		11

/*------------------------------------------------------------------------------

			Scan Code
		-------------
		| x	| x	| x	|									^ ^
		-------------									| |
		\______/ \___/									Z Z
			|	   |									Z Z
			|	   |									| |
			|	   | COLUMN		---------				| |
			|	   +------------|      0|---------------+ |    P0.2
			|					|      1|-----------------+    P0.3
			|					---------               | |
			|											| |
			|					---------				| |
			|	ROW	        	|	   0|---------------+-+    P0.11
			+------------------ |	   1|---------------+-+    P0.12
								|	   2|---------------+-+    P0.13
								---------				| |
*/

static int key_pressed(int code) {
	cyg_uint32 aux;
	HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE + CYGARC_HAL_LPC2XXX_REG_IOSET, 7 << ROW_START_PIN);
	HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE + CYGARC_HAL_LPC2XXX_REG_IOCLR, 1 << (ROW_START_PIN + (code >> 1 & 3)));
	HAL_READ_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE + CYGARC_HAL_LPC2XXX_REG_IOPIN, aux);
	return (~aux & 1 << (COLUMN_START_PIN + (code & 1))) != 0;
}

#define BUTTON_DEBOUNCE	3	/*	30 ms */

static struct {
	enum Button_state new, old;
	cyg_uint32 time;
} button_state[N_BUTTONS];

/*	Devolve o estado actual do botão
	No caso de estar dentro do periodo de bouce devolve o valor guardado
*/
enum Button_state button_get_state(int button) {
	if (chrono_timeout(button_state[button].time, BUTTON_DEBOUNCE)) {
		button_state[button].time = chrono_start();
		button_state[button].new = key_pressed(button);
	}
	return button_state[button].new;
}

/*	Detecta se houve mudan衠de estado do bot䯠desde 
	a chamada anterior a esta fun褯s ou ࡦun褯 button_get_state.
*/
enum Button_transition button_get_transition(int button) {
    enum Button_state new, old = button_state[button].old;
    button_get_state(button);
    new = button_state[button].old = button_state[button].new;
    return old == new ? BUTTON_NONE : (new == BUTTON_ON ? BUTTON_TO_ON : BUTTON_TO_OFF);
}

void button_init() {
	/* Seleccionar os pinos para o GPIO */
	cyg_uint32 pinsel;
	HAL_READ_UINT32(CYGARC_HAL_LPC2XXX_REG_PIN_BASE + CYGARC_HAL_LPC2XXX_REG_PINSEL0, pinsel);
	HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_PIN_BASE + CYGARC_HAL_LPC2XXX_REG_PINSEL0,
		pinsel & ~(0x3f << ROW_START_PIN * 2 | 0xf << COLUMN_START_PIN * 2));
			
	/* Programar linhas como sa�das e colunas como entradas */
	cyg_uint32 iodir;
	HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE + CYGARC_HAL_LPC2XXX_REG_IOSET, 7 << ROW_START_PIN);
	HAL_READ_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE + CYGARC_HAL_LPC2XXX_REG_IODIR, iodir);
	HAL_WRITE_UINT32(CYGARC_HAL_LPC2XXX_REG_IO_BASE + CYGARC_HAL_LPC2XXX_REG_IODIR,
		(iodir & ~(3 << COLUMN_START_PIN)) | 7 << ROW_START_PIN);
	int i;
	for (i = 0; i < sizeof_array(button_state); ++i)
		button_state[i].time = chrono_start();
}
