-- ************* Teste 6 ************
--tempo t3
use db_si_ap
insert into conta values(3,0)

--tempo t5
insert into conta values(4,5000)

