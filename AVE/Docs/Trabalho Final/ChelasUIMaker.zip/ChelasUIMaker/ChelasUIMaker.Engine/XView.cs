﻿
namespace ChelasUIMaker.Engine
{
    using System.Windows.Forms;
    public class XView
    {
        public System.Windows.Forms.Form Control { get; set; }
    }
}