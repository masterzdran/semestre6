using System;
using System.Reflection;
using System.Text;
using System.ComponentModel;


/*********************************************************************
	Automatiza��o de preenchimento de campos atrav�s de Custom Attributes
	a partir de recolha de dados pelo Standard Input

  Pretende-se automatizar:
  
  - a string a mostrar na recolha de dados antes e depois de erro de introdu��o de dados
  
  - A formata��o a aplicar ao campo string
  
  - A valida��o a aplicar ao campo
  
  Apenas s�o tratados campos de tipos num�ricos e strings
  
  Jorge Martins, Junho 2004
***********************************************************************/


namespace LoadValues {


    /**************************************
     *      Tipos de Teste
     *************************************/

    [Description("Informa��o sobre Pessoa")]
    class Pessoa
    {
    }

    // indica a mensagem a mostrar ao utilizador aquando da leitura de um aluno
    [Description("Informa��o sobre aluno")]
    class Aluno : Pessoa
    {
        // o atributo define um crit�rio para a formata��o
        // de strings e um n�mero m�ximo de caracteres
        // Assuma   a seguinte defini��o do  enumerado CaseConvertion 
        // enum CaseConvertion { Upper, Lower, Name }
        // onde:
        //     Upper � indica convers�o para ma�usculas
        //     Lower � Indica convers�o para minusculas
        //     Name  - A primeira letra de cada palavra em maiusculas
        [Format(CaseConvertion.Name, MaxChars = 20)]
        public string nome;

        // o atributo define o range de valores poss�veis para o campo
        [Range(min = 10, max = 20)]
        // indica a mensagem a mostrar ao utilizador aquando da leitura do campo
        [Description("M�dia do curso")]
        public int media;

        [Range(min = 0)]
        public int numero;

        // atributo define o conjunto de strings poss�veis para o campo
        [Names("Electr�nica", "Inform�tica", "Hardware")]
        [Format(CaseConvertion.Upper)]
        public string curso;

        // a atributo diz que o campo n�o faz parte dos campos a ler
        [NoReadable]
        public string[] disciplinas;

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("nome={0}\n", nome);
            sb.AppendFormat("media={0}\n", media);
            sb.AppendFormat("numero={0}\n", numero);
            sb.AppendFormat("curso={0}\n", curso);
            return sb.ToString();
        }
    }

    /*************************************************
     * Fim dos tipos de teste
     ************************************************/
  
    /* Custom attributes de formata��o dos valores recolhidos */

	enum CaseConvertion {
		Upper, Lower, Name, NoCase
	}
	
	[AttributeUsage(AttributeTargets.Field)]
	abstract class FormatterAttribute : Attribute {
		 public abstract object format(object o);
	}
	
    class NullFormatterAttribute : FormatterAttribute {
		 override public object format(object o) { return o; }
	}
	
	class FormatAttribute : FormatterAttribute {
		private int _maxChars;
		
		
		public int MaxChars {
			get {
			   return _maxChars;
			}
			
			set {
				_maxChars = value;
			}
		}
		
		private CaseConvertion cc;
		
		public FormatAttribute(CaseConvertion cc) {
			this.cc = cc;
			MaxChars=0;
		}
		
		override public object format(object o) {
			string s = o as string;
			if (s==null) return o;
			  
			switch (cc) {
				case CaseConvertion.Lower:	
					s = s.ToLower(); break;
				case CaseConvertion.Upper:
					s = s.ToUpper();break;
				case CaseConvertion.Name:
					string[] words= s.Split(' ');
					StringBuilder sb = new StringBuilder();
					bool isFirstWord=true;
					foreach (string word in words) {
						if (!isFirstWord) sb.Append(" "); else isFirstWord=false;
						sb.Append(word.Substring(0,1).ToUpper());
						if (sb.Length > 1) sb.Append(word.Substring(1).ToLower());
					}
					s = sb.ToString();
					break;
				 default:
					break;
				}
				return s;
			}
	}


    /* Custom attributes de valida��o dos valores recolhidos */

	 
	[AttributeUsage(AttributeTargets.Field, Inherited=false)]
	abstract class ValidatorAttribute : Attribute {
		 public abstract bool validate(object o);
		 public abstract string message();
	}
	
	 
	class RangeAttribute : ValidatorAttribute {
		public int _min = int.MinValue;
		public int max = int.MaxValue;
		
		
		public int min {
			set {
			  _min=value;	  
			}
			get {
				return _min;
			}
		}
		
		
		
		override public bool validate(object o) {
		    bool isInt = o is int;
		    if (!isInt) return false;
		    int v = (int) o;
			return v >= min && v <= max;	
		}	 
		
		override public string message() {
			return String.Format("({0},{1})", min,max);
		}
	}
	
	
	
    class NullValidatorAttribute : ValidatorAttribute {
		 override public  bool validate(object o) { return true; }
		 override public  string message() { return ""; }
	}
	
	
	
	class NamesAttribute : ValidatorAttribute {
		public string[] names;
	 
		public NamesAttribute(params string[] names) {
			this.names = names;
		}
		
		override public bool validate(object o) {
			 
			string v =  o as string;
			if (v == null) return false;
			foreach (string s in names) {
				if (s == v) return true;
			}
			return false;
		}	
		
		override public  string message() { 
		  StringBuilder sb = new StringBuilder("(");
		  bool isFirstName = true;
		  foreach (string name in names) {
				if (!isFirstName) sb.Append(" ");
				else isFirstName=false;
				sb.Append(name);
	      }
	      sb.Append(")");
		  return sb.ToString();
		}	 
	}
	
	[AttributeUsage(AttributeTargets.Field)]
	class NoReadableAttribute : Attribute {}


    /* Custom attributes de apresenta��o dos valores recolhidos */

	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Field, Inherited=true)]
	class DescriptionAttribute : Attribute {
		private string description;
	 
		public DescriptionAttribute(string description) {
			this.description = description;
		}
		
		public string Description {
			get { return description; }
		}
		 
	}
	
	
    /*
     * classe que constr�i um objecto a partir de valores lidos do standard input
     */
	class Reader {
		// metodos est�ticos auxiliares para a leitura
		private static NullValidatorAttribute nat = new NullValidatorAttribute();
	 	private static NullFormatterAttribute nullFormatter = new NullFormatterAttribute();
	
		
	  static void ProcessField(string name, FieldInfo f, object o) {
		  object  val;
	
		  Console.Write("{0}: ", name);
		  object[] vats = f.GetCustomAttributes(typeof(ValidatorAttribute), true);
		  ValidatorAttribute vat=nat;
		  if (vats.Length>0) vat = (ValidatorAttribute) vats[0];
		  
		  object[] fats = f.GetCustomAttributes(typeof(FormatterAttribute), true);
		  FormatterAttribute fat=nullFormatter;
		  if (fats.Length>0) fat = (FormatterAttribute) fats[0];
			while (true) {
			  try {
			    val = Convert.ChangeType(Console.ReadLine(),f.FieldType);
			    if (!vat.validate(val)) throw new Exception();
			    f.SetValue(o, fat.format(val));
			    return;
				}	 
				catch (Exception ) {
					Console.Write("{0}{1}): ", name,vat.message() );
				}
			}
		}
		
	
	  static DescriptionAttribute getDescription(MemberInfo t) { 	
			object[] attrs =  t.GetCustomAttributes(typeof(DescriptionAttribute), true);
			if (attrs.Length > 0) return (DescriptionAttribute) attrs[0];
			else return null;	
		}
		
	    static bool isReadableField(FieldInfo f) {
			return  !f.IsDefined(typeof(NoReadableAttribute), false);
		}
		
	   static string getFieldDescription(FieldInfo f) {
	    DescriptionAttribute da=getDescription(f);
		 	if (da!=null) return da.Description;
			return f.Name;	
		}
		
		
		// algoritmo gen�rico de recolha de campos
		public object readObject(Type t) {
            // cria��o da inst�ncia
			ConstructorInfo cti = t.GetConstructor(System.Type.EmptyTypes);
			object obj = cti.Invoke( new object[0]);
			if (obj==null) return null;
			DescriptionAttribute da = getDescription(t);
			
			// escrever titulo
			if (da != null) 	Console.WriteLine(da.Description);
				 
			FieldInfo[] fields = t.GetFields(BindingFlags.Public | BindingFlags.Instance);
			foreach (FieldInfo f in fields) {
				if (isReadableField(f)) { 	// testar se � Readable
					string name= getFieldDescription(f);		
					// ver de que tipo � (s� se tratam strings e inteiros)
					ProcessField(name, f, obj);
				
				}		
			}
			return obj;
		 }
	}
	

	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Tester  {
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args) {
			//
			// TODO: Add code to start application here
			//
			// testar atributos do tipo aluno
			
		 
		  
		  Reader r = new Reader();
		  
		  Aluno a = (Aluno) r.readObject(typeof(Aluno));
		  Console.WriteLine(a.ToString());
		  
		}
	} 
}
