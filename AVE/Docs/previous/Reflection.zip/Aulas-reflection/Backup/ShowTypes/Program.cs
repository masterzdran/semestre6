using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Reflection.Emit;
using System.Threading;

namespace Reflection 
{
	class A {
		protected int i2;
	}
	
	class B : A {
		int i2;
	}
	
	interface I1 {
	}
	
	interface I2: I1 {
	}
	
	class ShowTypes {
	    static BindingFlags BF = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
		public static void showFields(Type t) {
		    if (t==typeof(object)) return;
		    showFields(t.BaseType);
			FieldInfo[]  fields = t.GetFields(BF);
			foreach (FieldInfo fi in fields) {
				if (fi.DeclaringType==t) Console.WriteLine(fi.Name);
			}
		
		}
	}
	
 
	
	class TypeUtils : I2{
		public static bool isAssignableFrom(Type t1, Type t2) {
		    if (t1==t2) return true;
		    if (t1 == null || t2==null) return false;
			if (t1.IsInterface) {
				// ent�o pode ser um tipo que implemente a interface
			    Type[] interfaces = t2.GetInterfaces();
			    foreach(Type t in interfaces) {
					if (t1== t) return true;
				}
			}
			else {
				// caso n�o seja uma interface ent�o ter� de ser do mesmo tipo ou  derivado
				
				do {
					t2= t2.BaseType;
					if (t1==t2) return true;
					
				} while (t2 != null);
				
			}
			return false;
				
		}
	}
	
	class Program
	{
		static void Main(string[] args)
		{
			ShowTypes.showFields(typeof(B));
			
		 	Console.WriteLine();
		 
			
			Console.WriteLine(TypeUtils.isAssignableFrom(typeof(Object), typeof(TypeUtils)));
			Console.WriteLine(TypeUtils.isAssignableFrom(typeof(I1), typeof(I1)));
			Console.WriteLine(TypeUtils.isAssignableFrom(typeof(I1), typeof(I2)));
			Console.WriteLine(TypeUtils.isAssignableFrom(typeof(I1), typeof(TypeUtils)));
			Console.WriteLine(TypeUtils.isAssignableFrom(typeof(I2), typeof(TypeUtils)));
			Console.WriteLine(TypeUtils.isAssignableFrom(typeof(TypeUtils), typeof(I2)));
		 
			
		
		}
	}
}
