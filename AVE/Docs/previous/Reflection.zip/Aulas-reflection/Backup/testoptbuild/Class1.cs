//#define WithAttributes

using System;
using System.Text;



namespace ReflectionTest
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	/// 
#if WithAttributes
	class MyOptions : Options 
	{
		[Option(Nickname="o", Description="Defines a certain execution condition")]
        public bool boolval = false;

        [Option(Nickname = "o2")]
		public bool boolval2=false;

		[Option(Nickname="i", Description="A numeric value to parameterize program")]
		public int intval=3;

		public override String ToString() 
		{
			StringBuilder sb = new StringBuilder();
			sb.Append("boolval=" + boolval + "\n");
			sb.Append("intval=" +  intval + "\n");
			return sb.ToString();
		}
	}
#else
    	class MyOptions : Options 
	{
		 
        public bool boolval = false;
		public bool boolval2=false;
		public int  intval=3;

		public override String ToString() 
		{
			StringBuilder sb = new StringBuilder();
			sb.Append("boolval=" + boolval + "\n");
            sb.Append("boolval2=" + boolval2 + "\n");
			sb.Append("intval=" +  intval + "\n");
			return sb.ToString();
		}
	}
#endif

	class Class1
	{
	
		static void Main(string[] args) {
			
			MyOptions o = new MyOptions();
            o.load(args);

            Console.WriteLine("Options:");
			Console.WriteLine(o);

            Console.WriteLine("Arguments:");
            Array.ForEach(o.Arguments, Console.WriteLine);
		}
	}
}
