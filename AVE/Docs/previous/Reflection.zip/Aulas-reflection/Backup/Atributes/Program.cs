/*
 * Defini��o, utiliza��o e verifica��o de atributos
 * 
 * JMartins, 2008
 *
 * *********************************************************************************/

using System;
using System.Collections.Generic;
using System.Text;

namespace Atributes
{
	[AttributeUsage(AttributeTargets.Method | AttributeTargets.Class,	AllowMultiple=true)]
	class TestedBy : Attribute {
		public  string programmer;
		public  string dataTeste;
		
		public TestedBy(string programmer) {
			this.programmer=programmer;
		}

        public TestedBy()
        {
            programmer = null; dataTeste = null;
        }

        public string Programmer
        {
            set { programmer = value; }
            get { return programmer; }
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("programmer=");
            sb.Append(programmer);
            sb.Append(',');
            sb.Append("dataTeste=");
            sb.Append(dataTeste);
            return sb.ToString();


        }
	}
			
		
	[TestedBy(Programmer = "Joao" )]
    [TestedBy(Programmer = "Carlos", dataTeste="29/12/2008")]
	class Program
	{
		
		[Obsolete("Usar em alternativa xpto2")]
		[TestedBy("Joao", dataTeste="21/3/2007")]
		[TestedBy("Carlos", dataTeste="21/4/2007")]
		public static void xpto() {
		}

        #region Use Attributes
        public static void showAttributes(Type t)
        {
            object[] attrs = t.GetCustomAttributes(true);
            foreach (Attribute a in attrs)
            {
                Console.WriteLine(a.GetType().Name + "=" + a);
            }
        } 
        #endregion
		
		static void Main(string[] args)
		{
			xpto();

            #region Use Attributes
		            showAttributes(typeof(Program));
            #endregion

        }
	}
}
