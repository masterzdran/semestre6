 
using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Collections.Generic;
using System.Xml;
 

/*
 *  Serializa um objecto no seguinte formato XML:
 *  <object>
 *    < �fieldname�  type="�typename�" value="�valor (se tipo primitivo ou string)'" >
 *    </�fieldname�> 
 *    ....
 *  </object>
 *  Esta solu��o usa o suporte DOM (Document Object Model) presente no namespace System.Xml
 */
namespace Serialization {

 
    class C
    {
        private double fc = 5.23;

        public override string ToString()
        {
            return "f de C= " + fc;
        }
    }

  
	class B {
		private double f = 3.1415;
		
		public override string  ToString() {
		  return "f de B= " + f;
		}
	}
	
  
	class A : B{
		int a=3;
        C c1 = new C();
		string s="<ola>";
		
		public override string  ToString() {
		  return "a= " + a + ", s=" + s + ", " + base.ToString();
		}
  
	}

	class SimpleFormatter {
	  /*
	     Campo est�tico para facilitar a aplica��o de binding flags
	  */
	  private const BindingFlags bindingFlags = 
	     BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance;
	     
	  #region GetSerializableFieldsComplete
	   private static void getSerializableFields(Type t, List<FieldInfo> ar) {
		  if (t != typeof(object)) {
		      getSerializableFields(t.BaseType,ar);
			  FieldInfo[] fields = t.GetFields(bindingFlags);
			  foreach(FieldInfo f in fields) {
					 if (f.DeclaringType == t) ar.Add(f);
			  }
		  }
	  }
	  
	  /*
	   * obtem um array com os campos a serializar
	   */
	  private static FieldInfo[] getSerializableFields(Type t)  {
         List<FieldInfo> ar = new List<FieldInfo>();
	     getSerializableFields(t,ar);
	     return  ar.ToArray();
	  }
	  #endregion	  
	 
	  
	  /*
	   *  Verifica se a informa��o sobre o campo faz match com a informa��o presente na stream
	   * de serializa��o
	   */
	  private static bool matchField(FieldInfo field, Type objType, string fieldName) {
		return (field.FieldType.IsAssignableFrom(objType) && field.Name == fieldName);
	  }
	  
	
	   
	  /*-----------------------------------------------------
	    Algoritmos de Serializa��o/Deserializa��o
	  --------------------------------------------------------*/
	  /*
	   * Algoritmo de Serializa��o simples. Apenas sabe serializar tipos primitivos, strings e tipos
	   * compostos directa ou indirectamente pore estes. 
	   */
	  private  void Serialize(object obj, Type type, XmlElement elem,XmlDocument doc) {
		  elem.SetAttribute("type", type.FullName);
		  if (type == typeof(System.String) || type.IsPrimitive) {
		    elem.SetAttribute("value", obj.ToString());
		    return;
		  }
		  FieldInfo[] fields = getSerializableFields(type);
		  foreach(FieldInfo f in fields) {
		        string s = f.DeclaringType.Name;
				XmlElement child= doc.CreateElement(f.Name);
				object v = f.GetValue(obj);
				elem.AppendChild(child);
				Serialize(v,  v.GetType(), child, doc);
		  }     
	  }
	  
	   
	  private  object DesSerialize(XmlElement elem, Type type) {
	    object obj = null;
	    string val = elem.GetAttribute("value");
	    if (val != "")
	      return Convert.ChangeType(val,type);
	   
	    /* cria��o de um novo objecto do tipo "type"
		 * Necessita que o tipo tenha um constructor sem par�metros
		 */
	    ConstructorInfo ctor = type.GetConstructor(new Type[0]);
	    obj = ctor.Invoke(new object[0]);
	    FieldInfo[] fields = getSerializableFields(type);
	    int currField=0;
	    foreach (XmlElement field in elem.ChildNodes) {
	      FieldInfo fc = fields[currField];
	      string fieldTypeName = field.GetAttribute("type");
	      Type objType= Type.GetType(fieldTypeName);
	      if (!matchField(fc,objType, field.Name) )
	          throw new Exception("Invalid serialization stream!");
	      fc.SetValue(obj, DesSerialize(field,  objType));
	      currField++;
	    }
		return obj;
	  }
	  
	  public  object  DesSerialize( Stream s) {
		XmlDocument doc = new XmlDocument();
		doc.Load(s);
		XmlElement root = doc.DocumentElement;
		return DesSerialize(root, Type.GetType(root.GetAttribute("type")));   
	  }
	
	
	  public  void  Serialize(object obj, Stream s) {
	    Type t = obj.GetType();
	    
		XmlDocument doc = new XmlDocument();
		XmlElement root= doc.CreateElement("object");
		doc.AppendChild(root);
		 
		Serialize(obj, t, root,doc);
		doc.Save(s);   
	  }
	  
	}
	  
	class Program {
		static void Main(string[] args)  {
		
		    Stream s = new FileStream("object.xml",FileMode.Create);
		    
		    SimpleFormatter f = new SimpleFormatter();
		    A aa = new A();
		    f.Serialize(aa, s);
		    s.Close();
		    
		    
			Stream si = new FileStream("object.xml",FileMode.Open);
			A a2= (A) f.DesSerialize(si);
			System.Console.WriteLine(a2);
	 
			 
		}
	}
}
