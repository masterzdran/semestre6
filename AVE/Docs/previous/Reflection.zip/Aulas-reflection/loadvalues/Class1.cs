using System;
using System.Reflection;
using System.Text;
using System.ComponentModel;

namespace loadvalues {

	enum CaseConvertion {
		Upper, Lower, Name, NoCase
	}
	
	[AttributeUsage(AttributeTargets.Field)]
	abstract class FormatterAttribute : Attribute {
		 public abstract object format(object o);
	}
	
  class NullFormatterAttribute : FormatterAttribute {
		 override public object format(object o) { return o; }
	}
	
	class FormatAttribute : FormatterAttribute {
		public int MaxChars;
		private CaseConvertion cc;
		
		public FormatAttribute(CaseConvertion cc) {
			this.cc = cc;
			MaxChars=0;
		}
		
		override public object format(object o) {
			string s = o as string;
			if (s==null) return o;
		  
			  
			switch (cc) {
				case CaseConvertion.Lower:	
					s = s.ToLower(); break;
				case CaseConvertion.Upper:
					s = s.ToUpper();break;
				case CaseConvertion.Name:
					string[] words= s.Split(' ');
					StringBuilder sb = new StringBuilder();
					bool isFirstWord=true;
					foreach (string word in words) {
						if (!isFirstWord) sb.Append(" "); else isFirstWord=false;
						sb.Append(word.Substring(0,1).ToUpper());
						if (sb.Length > 1) sb.Append(word.Substring(1).ToLower());
					}
					s = sb.ToString();
					break;
				 default:
					break;
				}
				return s;
			}
	}
	
	[AttributeUsage(AttributeTargets.Field)]
	abstract class ValidatorAttribute : Attribute {
		 public abstract bool validate(object o);
		 public abstract string message();
	}
	
	
	class RangeAttribute : ValidatorAttribute {
		private int min;
		private int max;
		
		public RangeAttribute(int min, int max) {
			 this.min = min; this.max=max;
		}
		
		override public bool validate(object o) {
		  try {
				int v = (int) o;
				return v >= min && v <= max;
			}
			catch(Exception e ) {
				return false;
			}	
		}	 
		
		override public string message() {
			return String.Format("({0},{1})", min,max);
		}
	}
	
  class NullValidatorAttribute : ValidatorAttribute {
		 override public  bool validate(object o) { return true; }
		 override public  string message() { return ""; }
	}
	
	[AttributeUsage(AttributeTargets.All)]
	class DescriptionAttribute : Attribute {
		private string description;
	 
		public DescriptionAttribute(string description) {
			this.description = description;
		}
		
		public string Description {
			get { return description; }
		}
		 
	}
	
	class NamesAttribute : ValidatorAttribute {
		public string[] names;
	 
		public NamesAttribute(params string[] names) {
			this.names = names;
		}
		
		override public bool validate(object o) {
			try {
				string v = (string) o;
				foreach (string s in names) {
					if (s == v) return true;
				}
				return false;
			
			}
			catch(Exception e) {
				return false;
			}
		}	
		override public  string message() { 
		  StringBuilder sb = new StringBuilder("(");
		  bool isFirstName = true;
		  foreach (string name in names) {
				if (!isFirstName) sb.Append(" ");
				else isFirstName=false;
				sb.Append(name);
			}
			sb.Append(")");
		  return sb.ToString();
		}	 
	}
	
	[AttributeUsage(AttributeTargets.Field)]
	class NoReadableAttribute : Attribute {
	}
	
	[Description( "Informa��o sobre Pessoa") ]
	class Pessoa {
	}
	
	// indica a mensagem a mostrar ao utilizador aquando da leitura de um aluno
	[Description( "Informa��o sobre aluno") ]
	class Aluno : Pessoa  {
			// o atributo define um crit�rio para a formata��o
			// de strings e um n�mero m�ximo de caracteres
			// Assuma   a seguinte defini��o do  enumerado CaseConvertion 
			// enum CaseConvertion { Upper, Lower, Name }
			// onde:
				//     Upper � indica convers�o para ma�usculas
				//     Lower � Indica convers�o para minusculas
				//     Name  - A primeira letra de cada palavra em maiusculas
			[Format(CaseConvertion.Name, MaxChars=20 )]
			public string nome;

			// o atributo define o range de valores poss�veis para o campo
			[Range(10,20)]
			// indica a mensagem a mostrar ao utilizador aquando da leitura do campo
			[Description("M�dia do curso") ]
			[TypeConverter(typeof(string))]

			public int media;

			//[Range(min=0)]
			public int  numero;

			// atributo define o conjunto de strings poss�veis para o campo
			[Names( "Electr�nica", "Inform�tica", "Hardware") ]
			[Format(CaseConvertion.Upper)]
			public string curso;

			// a atributo diz que o campo n�o faz parte dos campos a ler
			[NoReadable]
			public string[] disciplinas;
			
			public override string ToString() {
				StringBuilder sb=new StringBuilder();
				sb.AppendFormat("nome={0}\n", nome);
				sb.AppendFormat("media={0}\n", media);
				sb.AppendFormat("numero={0}\n", numero);
				sb.AppendFormat("curso={0}\n", curso);
				return sb.ToString();
			}
	}

	class Reader {
		// metodos est�ticos auxiliares para a leitura
		private static NullValidatorAttribute nat = new NullValidatorAttribute();
	 	private static NullFormatterAttribute nullFormatter = new NullFormatterAttribute();
	
		
		public static void ProcessIntField(string name, FieldInfo f, object o) {
			object val=null;
	
		  Console.Write("{0}: ", name);
		  object[] vats = f.GetCustomAttributes(typeof(ValidatorAttribute), false);
		  ValidatorAttribute vat=nat;
		  if (vats.Length>0) vat = (ValidatorAttribute) vats[0];
		
			while (true) {
			  try {
			    val = Convert.ChangeType(Console.ReadLine(),f.FieldType);
			    if (!vat.validate(val)) throw new Exception();
			    f.SetValue(o, val);
			    return;
				}	 
				catch (Exception e) {
					Console.Write("{0}{1}): ", name,vat.message() );
				}
			}
		 
		}
		
		
	  static void ProcessField(string name, FieldInfo f, object o) {
			object  val;
	
		  Console.Write("{0}: ", name);
		  object[] vats = f.GetCustomAttributes(typeof(ValidatorAttribute), false);
		  ValidatorAttribute vat=nat;
		  if (vats.Length>0) vat = (ValidatorAttribute) vats[0];
		  
		  object[] fats = f.GetCustomAttributes(typeof(FormatterAttribute), false);
		  FormatterAttribute fat=nullFormatter;
		  if (fats.Length>0) fat = (FormatterAttribute) fats[0];
			while (true) {
			  try {
			    val = Convert.ChangeType(Console.ReadLine(),f.FieldType);
			    if (!vat.validate(val)) throw new Exception();
			    f.SetValue(o, fat.format(val));
			    return;
				}	 
				catch (Exception e) {
					Console.Write("{0}{1}): ", name,vat.message() );
				}
			}
		}
		
	
	  static DescriptionAttribute getDescription(Type t) { 	
			object[] attrs =  t.GetCustomAttributes(typeof(DescriptionAttribute), false);
			if (attrs.Length > 0) return (DescriptionAttribute) attrs[0];
			else return null;	
		}
		
	  static bool isReadableField(FieldInfo f) {
			object[] fattrs = f.GetCustomAttributes(typeof(NoReadableAttribute), false);
			return  (fattrs.Length == 0);
		}
		
	  static string getFieldDescription(FieldInfo f) {
		 	object[] attrs =  f.GetCustomAttributes(typeof(DescriptionAttribute), false);
			if (attrs.Length > 0) return ((DescriptionAttribute) attrs[0]).Description;
			else return f.Name;	
		}
		
		 
		public void readObject(object obj) {
		  Type t = obj.GetType();
		  DescriptionAttribute da = getDescription(t);
		  if (da != null) 	Console.WriteLine(da.Description);
			 
			FieldInfo[] fields = t.GetFields();
			foreach (FieldInfo f in fields) {
				if (isReadableField(f)) { 	// testar se � Readable
					string name= getFieldDescription(f);		
					// ver de que tipo � (s� se tratam strings e inteiros)
				  ProcessField(name, f, obj);
			 
				}		
			}
		}
	}
	

	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args) {
			//
			// TODO: Add code to start application here
			//
			// testar atributos do tipo aluno
		  Aluno a = new Aluno();
		  Reader r = new Reader();
		  
		  r.readObject(a);
		  Console.WriteLine(a.ToString());
		}
	} 
}
