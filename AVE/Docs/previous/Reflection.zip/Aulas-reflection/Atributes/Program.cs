/*
 * Defini��o, utiliza��o e verifica��o de atributos
 * 
 * JMartins, 2008
 *
 * *********************************************************************************/
#define  WITH_INVOKE_NATIVE

using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Runtime.InteropServices;

namespace Atributes
{

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Auto)]
    class OSVERSIONINFO
    {
        public UInt32 OSVersionInfoSize = 0;
        public UInt32 MajorVersion = 0;
        public UInt32 MinorVersion = 0;
        public UInt32 BuildNumber = 0;
        public UInt32 PlatformId = 0;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 128)]
        public String CSDVersion = null;

        public OSVERSIONINFO()
        {
            OSVersionInfoSize = (UInt32)Marshal.SizeOf(this);
        }
        
    }

    class MyClass
    {
        [DllImport("Kernel32", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern Boolean GetVersionEx([In, Out] OSVERSIONINFO version);

        [DllImport("user32.dll")]
        public static extern int MessageBoxA(int p, string m, string h, int t);

    }

	[AttributeUsage(AttributeTargets.Method | AttributeTargets.Class,	AllowMultiple=true)]
	class TestedBy : Attribute {
		public  string programmer;
		public  string dataTeste;
		
		public TestedBy(string programmer) {
			this.programmer=programmer;
		}

        public TestedBy()
        {
            programmer = null; dataTeste = null;
        }

        public string Programmer
        {
            set { programmer = value; }
            get { return programmer; }
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("programmer=");
            sb.Append(programmer);
            sb.Append(',');
            sb.Append("dataTeste=");
            sb.Append(dataTeste);
            return sb.ToString();


        }
	}
			
	[Serializable]
	[TestedBy(Programmer = "Joao" )]
    [TestedBy(Programmer = "Carlos", dataTeste="29/12/2008")]
	class Program
	{
		
		[Obsolete("Usar em alternativa xpto2")]
        #region WITH_TESTED_ATTRIBUTE
        [TestedBy("Joao", dataTeste="21/3/2007")]
		[TestedBy("Carlos", dataTeste="21/4/2007")]
        #endregion
        public static void xpto() {
		}

        #region Use Attributes
        public static void showAttributes(Type t)
        {
            object[] attrs = t.GetCustomAttributes(true);
            foreach (Attribute a in attrs)
            {
                Console.WriteLine(a.GetType().Name + "=" + a);
            }
        } 
        #endregion
		
		static void Main(string[] args)
		{
#if WITH_INVOKE_NATIVE
            OSVERSIONINFO os = new OSVERSIONINFO();
            MyClass.MessageBoxA(0, "Hello World!", "DLLImport Sample", 0);
            MyClass.GetVersionEx(os);
#endif


            xpto();

            #region Use Attributes
            showAttributes(typeof(Program));
            #endregion

        }
	}
}
