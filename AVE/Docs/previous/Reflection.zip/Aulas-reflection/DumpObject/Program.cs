/*
 * Utiliza��o de introspec��o para apresentar o estado de um objecto qualquer
 * Os casos especiais s�o ignorados, nomedamente campos de tipos array e delegates
 * 
 * Jorge Martins, 2009
 */

using System;
using System.Reflection;
using System.Collections.Generic;
using System.Text;

namespace Reflection 
{
    /* classes de teste */
    class T0
    {
        protected string s = "teste";
    }

    class T1 : T0
    {
        public int x;
        public int y;
        bool bit;
        EventHandler eh;
        private void Teste(object src, EventArgs a) { }

        public T1(int x, int y, bool bit)
        {
            this.x = x; this.y = y; this.bit = bit;
            eh += Teste;
        }
    }

    class T2
    {
        T1 t1;
        int z;
        T1[] vals = { new T1(2, 3, false), new T1(5, 6, true) };
        public T2(int x, int y, int z, bool bit)
        {
            t1 = new T1(x, y, bit);
            this.z = z;
        }

    }
    /* fim das classes de teste */
		
	class Utils
	{
        /* m�todo auxiliar para indentar devidamente o output */
		private static void indent(int level) {
			for (int i=0; i < level; ++i) {
				Console.Write("\t");
			}
		}
		
        /* m�todo auxiliar invocado recursivamente para mostrar os campos do objecto passado por argumento */
		private static void DumpGenericObject(int level, object o) {
			Type t = o.GetType();
			
			BindingFlags bf = BindingFlags.NonPublic|BindingFlags.Public |BindingFlags.Instance;
		
			while (t != typeof(System.Object)) {
				FieldInfo[] fields = t.GetFields(bf);
				foreach (FieldInfo f in fields) {
                    
						object v = f.GetValue(o);
						indent(level); Console.Write(f.Name + ": ");
						if (v==null) {
							Console.WriteLine("null");
						}
                        else if (v.GetType().IsPrimitive || v.GetType() == typeof(System.String))
                        {
                            Console.WriteLine(v.ToString());
                        }
                        else
                        {
                            Console.WriteLine();
                            DumpObject(level + 1, v);
                        }
				}
				t= t.BaseType;
			}
		}

      
        private static void showArray(int level, Array a)
        {
            bool first = true;
            indent(level); Console.WriteLine('[');

            foreach (object o in a)
            {
                if (first) first = false; else { indent(level+1); Console.WriteLine(", "); }
                DumpObject(level + 1, o);
                
            }
            indent(level); Console.WriteLine(']');
        }

        private static void showDelegate(int level, Delegate d)
        {
            indent(level);  Console.WriteLine("[[ {0} Delegate: {1} listeners ]]", d.GetType().Name, d.GetInvocationList().Length);
        }


        public static void DumpObject(int level, object o) {
            Type t = o.GetType();
            Array a = o as Array;
            if (a != null) showArray(level,a);
            else {
                Delegate d = o as Delegate;
                if (d != null) showDelegate(level, d);
                else DumpGenericObject(level, o);
            }
        }

		
        /* M�todo para mostrar, utilizando reflex�o, o estado do objecto passado por argumento */
		public static void DumpObject(object o) {
			DumpObject(0, o);
		}
		
		
        /* teste do m�todo DumpObject */
		static void Main(string[] args)
		{
			T2 t2 =  new T2(2,3,4,true );
			DumpObject(t2);
		}
	}
}
