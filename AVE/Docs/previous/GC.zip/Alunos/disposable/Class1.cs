using System;

namespace GC {


	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public sealed class OSHandle {
	  // This field holds the Win32 handle of the unmanaged resource.
	  private IntPtr handle;
	  // This constructor initializes the handle.
 	  OSHandle(IntPtr handle) { this.handle = handle; }
	  // When garbage is collected, the Finalize method, which will close the
	  // unmanaged resource's handle, is called.
	  ~OSHandle() {
          CloseHandle(handle);
	  }
	  
	  // Public method to return the value of the wrapped handle
	  public IntPtr ToHandle() { return handle; }
	  // Public implicit cast operator returns the value of the wrapped handle
 	  public static implicit operator IntPtr(OSHandle osHandle) {
	    return osHandle.ToHandle();
	  }
	  
	  // Private method called to free the unmanaged resource
	  [System.Runtime.InteropServices.DllImport("Kernel32")]
	  private extern static Boolean CloseHandle(IntPtr handle);
	  
	  public static void Main() {
	  }

	}

	
}
