using System;
using System.Collections.Generic;
using System.Text;

namespace CG1
{
	class Program
	{
		static void Main(string[] args)
		{
             
			Console.WriteLine("Mem�ria ocupada inicialmente: " + GC.GetTotalMemory(false));
            Console.WriteLine("Existem {0} gera��es", GC.MaxGeneration + 1);
          
			byte[] array = new byte[100000];
            Console.WriteLine("array na gera��o {0}", GC.GetGeneration(array));

		    Console.WriteLine("Mem�ria antes da recolha: " + GC.GetTotalMemory(false));
          
		    Console.WriteLine("Forcar recolha:");
            GC.Collect();
			//Console.WriteLine("array na gera��o {0}", GC.GetGeneration(array));

         
			Console.WriteLine("Mem�ria depois da recolha: " + GC.GetTotalMemory(false));

			//Console.WriteLine(array.ToString());
			
		}
	}
}
