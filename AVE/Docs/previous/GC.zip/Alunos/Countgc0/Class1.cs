#define WITH_WAITING
#define WITH_STOP_CREATION 

using System;
using System.Threading;

namespace Countgc0 {
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class NGCCounter {
    
		public static int  NGC=0;
		~NGCCounter() { 
			NGC++; // contabiliza o n�mero de GC de gera��o 0 	 
				   //  executadas pela aplica��o
#region STOPCREATION
#if WITH_STOP_CREATION		    
			if (!Environment.HasShutdownStarted) 
#endif				  
#endregion	
			  new  NGCCounter();
		  
		 }
			
			
		
	}

	class Application {
	
		static void Main() {
			new NGCCounter();
	      
		
	        for (int i=0; i < 10000; ++i) {
				for (int j=0; j < 10000; ++j) {
                    object[] o = { new object(), new object(), new object() };


                }
#region MyRegion
		#if WITH_WAITING
			        GC.WaitForPendingFinalizers();
			       
#endif 
	#endregion
                Console.Write(i + "\r");
			}
#region MyRegion
		#if WITH_WAITING		 
			GC.WaitForPendingFinalizers();
#endif 
	#endregion
			Console.WriteLine("foram efectuadas {0} gc de geracao 0", NGCCounter.NGC);
		 	Console.WriteLine("Via collection count: foram efectuadas {0} gc de geracao 0", GC.CollectionCount(0));
		 
			
		}
		
	}

	
}
