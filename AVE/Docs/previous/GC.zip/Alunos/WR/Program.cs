using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

public class CachedObject {
    private string name;
    internal CachedObject(string name) { this.name = name; }

    public string Name {
        get { return name; }
    }
}


public class Cache {
  
    // private static cache of well-known objects
    static IDictionary<String, CachedObject> table = new Dictionary<String, CachedObject>();

      // private static cache of well-known objects
    static IDictionary<String, GCHandle> table2 = new Dictionary<String, GCHandle>();

    // private static cache of well-known objects
    static IDictionary<String, WeakReference> table3 = new Dictionary<String, WeakReference>();

  
    // public accessor function
    public static CachedObject Get(string name) {
      CachedObject result;
      // check cache
      if (table.ContainsKey(name))
        result = table[name];
      else { 
        // create and cache if not there already
        result = new CachedObject(name);
        table[name] = result;
      }
      return result;
    }

   

    public static CachedObject Get2(string name) {
        CachedObject result=null;
        GCHandle? handle=null;

        if (table2.ContainsKey(name))
        {
            handle = table2[name];
            result = (CachedObject)handle.Value.Target;
        }
        // create and cache if not there already or has been GCed
        if (result == null) {
            result = new CachedObject(name);
            if (handle != null)  {
                Console.WriteLine("Before set target: handle new Target = {0}\n", handle.Value.Target);
                GCHandle h = handle.Value;
                h.Target = result;
                Console.WriteLine("After set target:handle new Target = {0}\n", handle.Value.Target);
            }
            else {
                handle = GCHandle.Alloc(result,GCHandleType.Weak);
                table2[name] = handle.Value;
            }
           
        }
        return result;
    }

    public static CachedObject Get3(string name)
    {
        CachedObject result = null;
        if (table3.ContainsKey(name))
            result = (CachedObject)table3[name].Target;

        // create and cache if not there already or has been GCed
        if (result == null)
        {
            result = new CachedObject(name);
            // cache weak reference only!
            table3[name] = new WeakReference(result);
        }
        return result;
    }

    public static void Main() {
        CachedObject a;  
        CachedObject b;

        //a = Cache.Get("teste");
        //b = Cache.Get("teste");
        //a=b=null;
        //GC.Collect();
        //a = Cache.Get("teste");

        a = Cache.Get2("teste");
        b = Cache.Get2("teste");
        a = b = null;
        GC.Collect();
        a = Cache.Get2("teste");

        //a = Cache.Get3("teste");
        //b = Cache.Get3("teste");
        //a=b=null;
        //GC.Collect();
        //a = Cache.Get3("teste");
    }
}


