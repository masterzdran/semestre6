/*--------------------------------------------------------------
 * Tentativa de cria��o de delegates weak reference
 * Justifique a semelhan�a do output em modo release e em modo debug
 *------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Reflection;

public static class Program {
    public static void Main() {
        // Construct a MailManager object
        MailManager mm = new MailManager();
        // Construct a Fax object
        Fax f = new Fax(mm);
        // Since no GCs have occurred, the Fax object
        // will receive the event notification
        mm.SimulateNewMail();
        //f = null;
        // Force a GC
        GC.Collect();
        // Since a GC has occurred, the Fax object
        // will not receive the event notification
        mm.SimulateNewMail();
        //f = null;
        GC.Collect();
        mm.SimulateNewMail();
    }
}


internal sealed class MailManager {
    // The collection maintains the set of WeakReferences to delegates
    private List<WeakReference> m_NewMailCallbacks = new List<WeakReference>();
    // This event is raised when new e-mail arrives
    public event EventHandler NewMail {
        add {
            // Construct a WeakReference around the passed-in delegate
            // and add the WeakReference to our collection
            m_NewMailCallbacks.Add(new WeakReference(value));   
        }
       
        remove {
                // Scan collection looking for a matching delegate and remove it
                for (Int32 n = 0; n < m_NewMailCallbacks.Count; n++) {
                    // Pull the WeakReference out of the collection
                    WeakReference wr = m_NewMailCallbacks[n];
                    // Try to turn the weak reference into a strong reference
                    EventHandler eh = (EventHandler) wr.Target;
                    if (eh == null) {
                        // The object was garbage collected
                        // Remove this entry from the collection
                        m_NewMailCallbacks.RemoveAt(n);
                        n--; // Go back an entry
                        continue; // Try the next entry
                    }
                    // The object was not garbage collected
                    // Does collection delegate match passed-in delegate
                    if ((eh.Target == value.Target) && (eh.Method == value.Method)) {
                        // Yes, they match. Remove it and return
                        m_NewMailCallbacks.RemoveAt(n);
                        break;
                    }
                }
        }
    }
    // Call this method to simulate new mail arriving
    public void SimulateNewMail() {
        Console.WriteLine("About to raise the NewMail event");
        OnNewMail(EventArgs.Empty);
    }

    // This method raises the NewMail event
    private void OnNewMail(EventArgs e) {
      
        // Scan our collection, calling back each delegate
        for (Int32 n = 0; n < m_NewMailCallbacks.Count; n++) {
            // Pull the WeakReference out of the collection
            WeakReference wr = m_NewMailCallbacks[n];
            // Try to turn the weak reference into a strong reference
            EventHandler eh = (EventHandler)wr.Target;
            if (eh == null) {
                // The object was garbage collected
                // Remove this entry from the collection
                m_NewMailCallbacks.RemoveAt(n);
                n--; // Go back an entry
            } else {
               
                // The object was not garbage collected
                // Invoke the delegate
                eh(this, e);
            }
        }
        
    }
}

internal sealed class MailManagerNew
{
    private struct EventHandlerWrapper
    {
        WeakReference targetWR;
        MethodInfo method;
        bool isStaticCallback;

        public EventHandlerWrapper(EventHandler eh)
        {
            isStaticCallback = eh.Target == null;
            if (!isStaticCallback) targetWR = new WeakReference(eh.Target);
            else targetWR = null;
            method = eh.Method;
        }

        public EventHandler Delegate
        {
            get
            {
                object target = null;
                if (!isStaticCallback)
                {
                    target = targetWR.Target;
                    if (target == null) return null; // object already reclaimed
                }
                return (EventHandler)System.Delegate.CreateDelegate(typeof(EventHandler), target, method);
            }
        }

        public object Target
        {
            get
            {

                return targetWR.Target;
            }
        }

        public MethodInfo  Method
        {
            get
            {

                return method;
            }
        }

        public bool IsStaticCallback
        {
            get { return isStaticCallback; }
        }
    }

    // The collection maintains the set of WeakReferences to delegates
    private List<EventHandlerWrapper> m_NewMailCallbacks = new List<EventHandlerWrapper>();

    // This event is raised when new e-mail arrives
    public event EventHandler NewMail
    {
        add
        {
            // Construct a WeakReference around the passed-in delegate
            // and add the WeakReference to our collection
            m_NewMailCallbacks.Add(new EventHandlerWrapper(value));
        }

        remove
        {
            // Scan collection looking for a matching delegate and remove it
            for (Int32 n = 0; n < m_NewMailCallbacks.Count; n++)
            {
                // Pull the WeakReference out of the collection
                EventHandlerWrapper wr = m_NewMailCallbacks[n];
                
                if (!wr.IsStaticCallback && wr.Target == null) 
                {
                    // The object was garbage collected
                    // Remove this entry from the collection
                    m_NewMailCallbacks.RemoveAt(n);
                    n--; // Go back an entry
                    continue; // Try the next entry
                }
                // The object was not garbage collected or is a static callback
                // Does collection delegate match passed-in delegate?
                if ((wr.Target == value.Target) && (wr.Method == value.Method))
                {
                    // Yes, they match. Remove it and return
                    m_NewMailCallbacks.RemoveAt(n);
                    break;
                }
              
            }
        }
    }
    // Call this method to simulate new mail arriving
    public void SimulateNewMail()
    {
        Console.WriteLine("About to raise the NewMail event");
        OnNewMail(EventArgs.Empty);
    }

    // This method raises the NewMail event
    private void OnNewMail(EventArgs e)
    {

        // Scan our collection, calling back each delegate
        for (Int32 n = 0; n < m_NewMailCallbacks.Count; n++)
        {
            // Pull the WeakReference out of the collection
            EventHandlerWrapper wr = m_NewMailCallbacks[n];
            // Try to turn the weak reference into a strong reference

            EventHandler eh = wr.Delegate;
            if (eh == null)
            {
                // The object was garbage collected
                // Remove this entry from the collection
                m_NewMailCallbacks.RemoveAt(n);
                n--; // Go back an entry
            }
            else
            {

                // The object was not garbage collected
                // Invoke the delegate
                wr.Delegate(this, e);
            }
        }

    }
}


internal sealed class Fax {
    // When constructed, register interest in the MailManager's NewMail event

    public Fax(MailManager mm)
    {
		mm.NewMail += GotMail;
    }
        

    // The method is called when NewMail arrives
    public void GotMail(Object sender, EventArgs e) {
        // Just prove that we got here
        Console.WriteLine("In Fax.GotMail");
    }
}
