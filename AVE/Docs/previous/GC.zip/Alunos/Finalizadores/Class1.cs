/*---------------------------------------------------------------
 * Compare os tempos e ocupa��o de mem�ria com e sem finalizadores
 *-------------------------------------------------------------*/
#region With Finalization
#define WITH_FINALIZATION
#endregion

using System;
using System.Threading;

namespace t1
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	
		   
	class AType {
        public static int nFinals = 0;
#region With Finalization
		#if WITH_FINALIZATION
		~AType() {
			  //Console.WriteLine("Em AType Finalizer, thread = {0}", Thread.CurrentThread.GetHashCode());
            nFinals++;
		}
#endif  
	#endregion
		
	}
	
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		
		static void Main(string[] args) {
            #region ShowThread
            //Console.WriteLine("Em Main, thread = {0}", Thread.CurrentThread.GetHashCode());
            #endregion
            
		    Console.WriteLine("Memoria ocupada no inicio= {0}", GC.GetTotalMemory(false));
	
		    DateTime t1 =  DateTime.Now;
	
		    AType[] tab= new AType[50000];

		    int ni=0;
			for (int i=0; i < tab.Length; ++i) {
			    ni++;
				tab[i] = new AType();
			}
			Console.WriteLine("Foram criadas {0} inst�ncias!", ni);
 
			Console.WriteLine("Objectos criados em {0} ms", (DateTime.Now - t1).TotalMilliseconds);
	
			Console.WriteLine("Memoria ocupada antes do collect= {0}", GC.GetTotalMemory(false));
	        tab = null;
			GC.Collect();

            #region With Finalization
#if WITH_FINALIZATION

            GC.WaitForPendingFinalizers();
           
            GC.Collect(); // Para qu�?
 
#endif
            #endregion
           
            Console.WriteLine("n finals = {0}", AType.nFinals);
            
			Console.WriteLine("Criacao/Destruicao em {0} ms", (DateTime.Now - t1).TotalMilliseconds);
			Console.WriteLine("Memoria ocupada apos o collect= {0}", GC.GetTotalMemory(false));
				
		    
			 
		}
	}
}
