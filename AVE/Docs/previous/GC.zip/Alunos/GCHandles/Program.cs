#define WITH_HANDLE

using System;
using System.Threading;
using System.Runtime.InteropServices;
using System.Collections.Generic;



public static class Program
{
    public static void Main() {
        // Create a Timer object that knows to call our TimerCallback
        // method once every 2000 milliseconds.
        Timer t = new Timer(TimerCallback, null, 0, 2000);


	
#region Handle
		#if WITH_HANDLE
        GCHandle handle= GCHandle.Alloc(t, GCHandleType.Normal);
#endif 
	#endregion
        // Wait for the user to hit <Enter>
        Console.ReadLine();

#region Handle
		#if WITH_HANDLE
			handle.Free();
		#endif 
	    GC.KeepAlive(t);
#endregion
        Console.ReadLine();

    }
   
	private static void TimerCallback(Object o)
    {
        // Display the date/time when this method got called.
        Console.WriteLine("In TimerCallback: " + DateTime.Now);
        // Force a garbage collection to occur for this demo.
        GC.Collect();
		
    }
}