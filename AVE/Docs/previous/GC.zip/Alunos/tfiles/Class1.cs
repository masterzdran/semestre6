#define WithUsing
//#define WITH_FINALIZER

using System;
using System.IO;


//ver implementa��o da FileWriter  

namespace tfiles {
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	
	class MyFileStream : FileStream {
		
		public MyFileStream(string fileName) : 
		    base(fileName, FileMode.Create, FileAccess.Write) {}

        ~MyFileStream()
        {
            Console.WriteLine("C� estou eu no destrutor de myStream!");
            Console.WriteLine("HasShutdownStarted= {0}", Environment.HasShutdownStarted);
        }

		protected override void Dispose(bool disposing) {
			Console.WriteLine("Dispose de MyFileStream, disposing= "+ disposing);
		    base.Dispose(disposing);
		}
	}
	
	class MyWriter  : IDisposable  {
		readonly int cacheSize=100;
		private byte[] cache;
		private Stream baseStream;
		private int cacheCurr;
		
		public MyWriter(Stream baseStream) {
			this.baseStream=baseStream;
			cache = new byte[cacheSize];
			cacheCurr=0;
		}
		
		public MyWriter(string fileName) {
			baseStream = new MyFileStream(fileName);
			cache = new byte[cacheSize];
			cacheCurr=0;
		}
		
		
		public void Close() {
		   ((IDisposable) (this)).Dispose();
		}

        protected virtual void Dispose(bool disposing) {
            flush(); 
			baseStream.Close();
        }

	    public  void  Dispose() {
            Dispose(true);
		}
		
		 
		public void write( byte b) {
			cache[cacheCurr++] = b;
			if (cacheCurr==cacheSize) {
			  if (baseStream==null) throw new Exception("baseStream inv�lida!");
			  baseStream.Write(cache, 0, cacheSize);
			  cacheCurr=0;
			}
		}
		
		void flush() {
			if (baseStream==null) throw new Exception("baseStream inv�lida!");
		
			if (cacheCurr > 0) {
				baseStream.Write(cache, 0, cacheCurr);
				cacheCurr=0;
			}
		}

		#if WITH_FINALIZER
			~MyWriter() {
				Console.WriteLine("C� estou eu no destrutor de MyWriter!");
				Dispose(false);
			} 
		#endif
		
		 
	}
	
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		
		static void test() {
			
			#if WithUsing
			using (MyWriter mw2 = new MyWriter("teste.txt")) {
			    mw2.write(65);
			    mw2.write(65);
			} 
			#else
                MyFileStream fs = new MyFileStream("teste.txt");
                MyWriter mw = new MyWriter(fs);
		        //MyWriter mw = new MyWriter("teste.txt");
			    mw.write(65);
			    mw.write(65);
			#endif
		}
		
	   
		
		[STAThread]
		static void Main(string[] args)
		{
		  
		    try {
				test();
				Console.WriteLine("Ficheiro criado com sucesso!");
			}
			 
			catch(Exception e) {
				Console.WriteLine("Erro: " + e.ToString());
			}
			
		
		}
	}
}
