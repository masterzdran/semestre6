
/*--------------------------------------------------------------------
 * Excerto da poss�vel implementa��o de uma soft reference
 *------------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.Text;

namespace GCUtils
{
    struct Pair<T,U> {
        public readonly T first;
        public readonly U second;

        public Pair(T first, U second) {
            this.first = first;
            this.second = second;
        }
    }

    internal class SoftReferenceManager {
        internal  const int MEM_TRESHOLD = 1024*1024*512; // 512 MB

        internal static LinkedList<SoftReference> softList;
        internal static LinkedList<WeakReference> weaksoftList;

        static SoftReferenceManager() {
            softList = new  LinkedList<SoftReference>();
            new SoftReferenceManager();
        }

        ~SoftReferenceManager()  {
            long usedmemory = GC.GetTotalMemory(false);
			if (usedmemory > MEM_TRESHOLD)
			{
                foreach (SoftReference sr in softList)
                    sr.setWeak();
                softList.Clear();
			}
			if (!Environment.HasShutdownStarted)  
				new SoftReferenceManager();

        }
    }

    public class SoftReference {
     
        public static SoftReference create(object obj) {
            SoftReference soft = new SoftReference(obj);
            LinkedListNode<SoftReference> wr = SoftReferenceManager.softList.AddLast(soft);
            return soft;
        }

        Object sref;
        WeakReference wref;

        private SoftReference(object o) {
            sref = o;
        }

        
        internal void setWeak() {
            if (wref == null) {
                wref = new WeakReference(sref);
                sref=null;
            }
        }
    }
            



    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
