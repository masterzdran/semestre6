/*-------------------------------------------------------
 * Tentativa de determina��o do n�mero de recolhas de gera��o 0.
 * Comparar com o valor devolvido por GC.CollectionCount(0)
 *----------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.Text;

class Spy
{
    public static int GCCounter = 0;
    ~Spy()
    {
        GCCounter++;
		// para qu� o c�digo seguinte?
        if (!Environment.HasShutdownStarted) {
            //GC.ReRegisterForFinalize(this);
            new Spy();
            
        }
        //else
        //    System.Console.WriteLine("Spy GC count = " + GCCounter);
    }
}

class Data {
    public static int TotalData=0;
    byte[] b = new byte[1000];

    //public Data() {
    //    TotalData++;
    //}
}

class Program
{

    static void Main(string[] args)
    {
        Spy spy = new Spy();
        byte[] b= new byte[1];
        Data d;
        for (long i = 0; i < 1000*1000; ++i)
        {
            d = new Data();

            #region MyRegion
            //Descomente a linha seguinte e justifique as diferen�as
            //GC.WaitForPendingFinalizers(); 
            #endregion
        }
        //GC.WaitForPendingFinalizers();
        Console.WriteLine("Total of Gen0 collections={0}", Spy.GCCounter);

        Console.WriteLine("GC(0) = " + GC.CollectionCount(0));
        Console.WriteLine("GC(1) = " + GC.CollectionCount(1));
        Console.WriteLine("GC(2) = " + GC.CollectionCount(2));
     
    }
}

