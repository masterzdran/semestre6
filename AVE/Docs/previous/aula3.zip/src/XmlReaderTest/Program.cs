﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.IO;

namespace Aula3
{
    class XmlReaderWriterTest
    {
        public static void WriteDocument(string name)
        {
            XmlTextWriter xtw = new XmlTextWriter(new StreamWriter(name));

            xtw.Indentation = 4;
            xtw.Formatting = Formatting.Indented;
           
            xtw.WriteStartDocument();
            xtw.WriteStartElement("xmlDoc");
            xtw.WriteAttributeString("val", "12");
            xtw.WriteAttributeString("test", "true");

            xtw.WriteStartElement("child");
            xtw.WriteAttributeString("name", "child1");
            xtw.WriteFullEndElement();

            xtw.WriteStartElement("child");
            xtw.WriteAttributeString("name", "child2");
            xtw.WriteEndElement();

            xtw.WriteEndElement();
            xtw.WriteEndDocument();
            xtw.Close();
        }

        private static void indent(int level) {
            for (int i=0; i < level; ++i) Console.Write(' ');
        }

        public static void ReadDocument(string name)
        {
            XmlTextReader xtr = new XmlTextReader(new StreamReader(name));

            while (xtr.Read())
            {
                if (xtr.NodeType == XmlNodeType.Element) 
                {

                    indent(xtr.Depth); Console.WriteLine("NodeType {0}, Name={1}", xtr.NodeType, xtr.Name);
                      
                    int i = xtr.AttributeCount;
                    while (--i >= 0)
                    {
                        xtr.MoveToAttribute(i);
                        indent(xtr.Depth + 2); Console.WriteLine("{0}={1}", xtr.Name, xtr.Value);
                 
                    }
                    if (xtr.IsEmptyElement)
                    {
                        indent(xtr.Depth); Console.WriteLine("Empty Element");
                    }
                  

                }
                else if (xtr.NodeType == XmlNodeType.EndElement)
                {
                    indent(xtr.Depth); Console.WriteLine("NodeType {0}, Name={1}", xtr.NodeType, xtr.Name);
                }
            }
        }





        static void Main(string[] args)
        {
            WriteDocument("test.xml");
            ReadDocument("test.xml");
         
        }
    }
}
