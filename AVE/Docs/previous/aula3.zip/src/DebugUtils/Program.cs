﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;

namespace Aula3
{
    class A
    {
        int p = 6;
        public int i;
    }

    class B : A
    {
        int j;
        A child;

        public B()
        {
            i = 1;
            j = 2;
            child = new A();
        }
    }
    class Program
    {
        private static IEnumerable<FieldInfo> getFields(Type t)
        {
            while (t != typeof(System.Object)) 
            {
                FieldInfo[] fields =
                    t.GetFields(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);

                foreach (FieldInfo f in fields)
                {
                    if (f.DeclaringType == t)
                        yield return f;
                }

                t = t.BaseType;
            }
        }

        private static void indent(int level) {
            for (int i=0; i < level; ++i) Console.Write("  ");
        }

        public static void DumpObject(object obj, int indentLevel)
        {
            if (obj==null) {
                Console.Write("null");
                return;
            }
         
            Type t = obj.GetType();
            if (t.IsPrimitive || t == typeof(String))
                Console.WriteLine(obj);
            else
            {
                if (indentLevel > 0) Console.WriteLine();
                foreach (FieldInfo fi in getFields(t))
                {
                    indent(indentLevel); 
                    Console.Write(fi.FieldType.Name + ' ' + fi.Name + ": ");
                    object fo = fi.GetValue(obj);
                    DumpObject(fo, indentLevel+1);
                }
            }
        }

        public static void DumpObject(string name, object obj)
        {
            Console.WriteLine("object " + name + ":");
            DumpObject(obj, 0);
            Console.WriteLine();
        }

        static void Main(string[] args)
        {
            DumpObject("Three", (object) 3);
            DumpObject("Message", "ola");
            DumpObject("B1", new B());
        }
    }
}
