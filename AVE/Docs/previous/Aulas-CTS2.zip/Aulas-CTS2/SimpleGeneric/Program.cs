using System;
using System.Collections.Generic;
using System.Text;

class GenericAlgorithms
{

	public static IEnumerable<T> GreaterThan<T>(IEnumerable<T?> vals, T refVal)
												where T : struct, IComparable<T>
	{
		foreach (T? t in vals)
		{
			if (t.HasValue && t.Value.CompareTo(refVal) > 0)
				yield return t.Value;
		}
	}
	
	public static IEnumerable<string> Names()
	{
		yield return "Joao";
		yield return "Joana";
		yield return "Rute";
	}

	public static IEnumerable<string> Names2()
	{
		return new List<string>( new string[] { "Joao", "Joana", "Rute" });
		 
	}
}
public class Names2 : IEnumerable<string> {
	
	 
	public IEnumerator<string>  GetEnumerator()
	{
		return new NamesIterator(this);
	}

  
	System.Collections.IEnumerator  System.Collections.IEnumerable.GetEnumerator()
	{
		return GetEnumerator();
	}


	private string[] names = { "Joao", "Joana", "Rute" };

	private class NamesIterator : IEnumerator<string> {
		int pos = -1;
		Names2 col;

		internal NamesIterator(Names2 col) {
			this.col = col;
		}

	 	public string  Current
		{
			get {  
				if (pos < 0 || pos >= col.names.Length) return null;
				return col.names[pos];
			}
		}

		public void  Dispose()
		{
			throw new NotImplementedException();
		}

		object  System.Collections.IEnumerator.Current
		{
			get {  
				return Current;
			}
		}

		public bool  MoveNext()
		{
			return ++pos < col.names.Length;
		}

		public void  Reset() {
			pos = -1;
		}

	}
}

class Generic0<T> where T: new() 
{
    T v;

    public Generic0(T v)
    {
        this.v = v;
    }

	public T create()
	{
		//T t =  null;
		//return t;
		return new T();
	}

	public override bool Equals(object obj)
	{
		if (v == null) return obj == null;
		return v.Equals(obj);
	}

    public void show()
    {
        Console.WriteLine(v);
    }
}

class Ponto : IComparable<Ponto>
{
    public readonly int  x, y;

    public Ponto(int x, int y)
    {
        this.x = x; this.y = y;
    }

	public Ponto( )
	{
		this.x = 1; this.y =1;
	}

    private double distance()
    {
        return Math.Sqrt(x * x + y * y);
    }
#region IComparable<Ponto> Members

   
    public int  CompareTo(Ponto other)
    {
        return (int) (distance() - other.distance());
    }

  

#endregion
}


class Generic1<T> : IComparable<T> where T: IComparable<T>
{
    T v;

    public Generic1(T v)
    {
        this.v = v;
    }

    public void show()
    {
        Console.WriteLine(v.ToString());
    }

	public static void gm<V>(V v) { }

	public  void gm2<V>(V v) { }


    public int CompareTo(T other)
    {
        string s = v.ToString();
        return v.CompareTo(other);
    }

    public void copyFrom(object o)
    {
		//if (!(o is T))
		//    throw new InvalidCastException();
        v = (T)o;
    }

}

class GenericUtils
{

    public static int countIf<T>(IEnumerable<T> col, Predicate<T> pred) {
        int n=0;
        foreach(T val in col ) {
            if (pred(val)) n++;
        }
        return n;
    }



    static void Main(string[] args)
    {
		foreach (string s in GenericAlgorithms.Names())
			Console.WriteLine(s);
	
		Console.WriteLine("teste");
	

		Generic0<Ponto> g1 = new Generic0<Ponto>(new Ponto());
        g1.show();
        Generic1<Ponto> p1 = new Generic1<Ponto>(new Ponto(2,3));
    }
}
  