// CallbackCpp.cpp : main project file.

#include "stdafx.h"

using namespace System;
using namespace System::Collections;

typedef int (*CompareFuncPtr)(const void *, const void *);

int compareInts(const void*i1, const void *i2) {
	return *((int *) i1) - *((int *) i2);
}

void testQSort() {
	int  vals[] = { 2, 8 , 13, 5, 4 };
	int nelems = sizeof(vals)/sizeof(int);
	qsort(vals, nelems, sizeof(int), compareInts);
	for (int i=0; i < nelems; ++i) {
		Console::WriteLine(vals[i]);
	}
}



	
typedef bool (*Predicate2)(int val);


//predicados
bool greater10(int i) { return i > 10; }

ref class GreaterThan {
	int vr;
public:
	 GreaterThan(int vr) {
		this->vr = vr;
	}
	
	bool operator()(int v) {
	   return v > vr;
	}
};

template< typename T >
int countIf(int vals[], int len, T p) {
    int n=0;
	for (int i=0; i < len; ++i) {
		if (p(vals[i])) n++;
	}
	return n;
}

 
int main(array<System::String ^> ^args) {	
	int a[] = {2, 10, 13, 14};

 
	Console::WriteLine("Teste QuickSort");
    testQSort();
    
  
    Console::WriteLine("Teste Templates");
	
	Console::WriteLine(countIf(a,sizeof(a)/sizeof(int), greater10));
 
    GreaterThan^ gt1= gcnew GreaterThan(10);
    Console::WriteLine(countIf(a,sizeof(a)/sizeof(int), gt1));

}
