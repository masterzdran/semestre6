﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Constraints
{
    class A {
        int a;

        public void m()
        {
            Console.WriteLine("m of A");
        }

        public A(int i) { a = i; }

        public A() { a = 0; }
    }

    class B : A
    {
        int a;
    }

    struct S {
        int i;
    }

    class G2<T> where T : A
               
    {
        T t;

        public G2()
        {
            t = null;
        }

        public void check()
        {
            t.m();
        }
    }

    class G<T> where T: new()
    {
        public static T Create()
        {
            return new T();
        }

    }

    class Program
    {
        static void Main(string[] args)
        {
            A a = G<A>.Create();

            S s = G<S>.Create();

            G2<B> g = new G2<B>();


        }
    }
}
