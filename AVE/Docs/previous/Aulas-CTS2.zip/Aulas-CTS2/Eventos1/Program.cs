// implementa��o custom de eventos

using System;
using System.Collections.Generic;
using System.Text;

public delegate void MyEventHandler();


class EventProducer
{
    private MyEventHandler _evt;

    public event MyEventHandler evt
    {
        add
        {
            DateTime dt = DateTime.Now;
            if (dt.Hour >= 12)
                throw new InvalidOperationException("Invalid register hour");
            _evt += value;
        }
        remove
        {
            _evt -= value;
        }
    }


    public void GenerateEvent()
    {
        if (_evt != null) _evt();
    }

}
 
class Program
{
    static void EventListener()
    {
        Console.WriteLine("event triggered!");
    }

    static void Main(string[] args)
    {

        EventProducer p = new EventProducer();

        p.evt += EventListener;

        p.GenerateEvent();


    }
}
