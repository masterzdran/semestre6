using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;

namespace Generics
{
    class Utils
    {
        public void show(IEnumerable col)
        {
            IEnumerator e = col.GetEnumerator();
            Console.Write("[ ");
            if (e.MoveNext())
            {
                Console.Write(e.Current);
                while (e.MoveNext())
                {
                    Console.Write(',');
                    Console.Write(e.Current);
                }
            }
            Console.WriteLine("]");
        }

        public void show<T>(IEnumerable<T> col)
        {
            IEnumerator<T> e = col.GetEnumerator();
            Console.Write("[[ ");
            if (e.MoveNext())
            {
                Console.Write(e.Current);
                while (e.MoveNext())
                {
                    Console.Write(',');
                    Console.Write(e.Current);
                }
            }
            Console.WriteLine("]]");
        }
    }


    struct Fraction : IEquatable<Fraction>, IComparable<Fraction>, IComparable {
        int numerator;
        int denominator;

        private static int MDC(int n1, int n2) {
            int D = 0;
            int d=0;

            if (n1 > n2) { D = n1; d=n2; }
            else    { D=n2; d=n1; }
            int r,q;
            while ((r= D%d) != 0) {
                D=d;
                d=r;
            }
            return d;
        }

        public void reduce() {
            int mdc = MDC(numerator, denominator);
            numerator /= mdc;
            denominator /= mdc;
        }

        public Fraction(int n, int d)
        {
            numerator = n;
            denominator = d;
            reduce();
        }

        Fraction add(Fraction r) {
            if (r.denominator == denominator) return new Fraction(numerator+r.numerator, denominator);
            return new Fraction(numerator * r.denominator + r.numerator * denominator, denominator * r.denominator);
        }


        public override bool Equals(object obj)
        {
            if (!(obj is Fraction)) return false;
            return  Equals((Fraction) obj);
        }

        public override int GetHashCode()
        {
            return numerator ^ denominator;
        }

		public bool Equals(Fraction f)
		{
			return numerator == f.numerator && denominator == f.denominator;
		}

        public override String ToString() {
            StringBuilder sb = new StringBuilder();
            sb.Append(numerator);
            sb.Append('/');
            sb.Append(denominator);
            return sb.ToString();
        }

        #region IComparable<Fraction> Members

        public int CompareTo(Fraction other)
        {
           return (int ) ((((float) numerator) / denominator ) - (((float) other.numerator) / other.denominator));
        }

        #endregion

        #region IComparable Members

        public int CompareTo(object obj)
        {
            if (!(obj is Fraction)) throw new InvalidCastException("object not fraction");
            return CompareTo((Fraction)obj);
        }

        #endregion
    }
            
    class Program
    {
        static void Main(string[] args)
        {
            Fraction r = new Fraction(32,14);

            Fraction r1 = new Fraction(16, 7);
            Console.WriteLine(r.Equals(r1));


            int[,] intVals = { { 1, 2, 3 }, { 4, 5, 6 } };
            Array arr = intVals;
            IList ival = arr;

            for (int i = 0; i < ival.Count; ++i)
                Console.WriteLine(ival[i]);
        }
    }
}
