#define ExtensionMethods
//#define WithLinq

using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.Linq;

 
namespace Generics {
	
    public struct Pair<T, U>
    {
        public readonly T v1;
        public readonly U v2;

        public Pair(T v1, U v2)
        {
            this.v1 = v1; this.v2 = v2;
        }

        public override string ToString()
        {
            return string.Format("({0},{1})", v1.ToString(), v2.ToString());
        }

    }

    public struct Point : IComparable, IComparable<Point>
    {
        public int x, y;

        public Point(int x, int y)
        {
            this.x = x; this.y = y;
        }

        public double distance() {
            return Math.Sqrt(x*x + y*y);
        }
       
        public int CompareTo(object obj)
        { 
            if (obj.GetType() != typeof(Point)) 
                throw new Exception("Invalid type!");
            Point p = (Point) obj;
            return (int) (distance()- p.distance());
            
        }
  
        public int CompareTo(Point p)
        {
            return (int)(distance() - p.distance());
        }

        public override String ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append('(');
            sb.Append(x);
            sb.Append(',');
            sb.Append(y);
            sb.Append(')');
            return sb.ToString();
        }


   }

    static class GenericAlgorithms {

        #region Auxiliary Classes
        private class WhereIterator<T> : IEnumerator<T>, IEnumerable<T>
        {
            IEnumerator<T> valsIter;
            IEnumerable<T> vals;
            Predicate<T> p;
            bool started;

            internal WhereIterator(IEnumerable<T> vals, Predicate<T> p)
            {
                this.valsIter = vals.GetEnumerator();
                this.vals = vals;
                this.p = p;
            }

            public IEnumerator<T> GetEnumerator()
            {
                if (started) return new WhereIterator<T>(vals, p);
                return this;
            }

            IEnumerator IEnumerable.GetEnumerator()
            {
                return GetEnumerator();
            }

            public T Current
            {
                get
                {
                    if (!started) throw new InvalidOperationException();
                    return valsIter.Current;
                }
            }

            public void Dispose() {}

            object IEnumerator.Current
            {
                get {  
                    if (!started) throw new InvalidOperationException();
                    return Current; 
                }
            }

            public bool MoveNext()
            {
                if (!started)
                {
                    started = true;
                }
                while (valsIter.MoveNext())
                {
                    T current = valsIter.Current;
                    if (p(Current)) return true;
                }
                return false;
            }


            public void Reset()
            {
            }

        }

        public static void show<T>(IEnumerable<T> c)
        {
            Console.Write('[');
            IEnumerator<T> e = c.GetEnumerator();
            if (e.MoveNext())
            {
                Console.Write(e.Current);
                while (e.MoveNext())
                {
                    Console.Write(", " + e.Current);
                }
            }
            Console.WriteLine(']');
        }

        class RangeComparer<T> where T : IComparable<T>
        {

            private T min, max;
            public RangeComparer(T mn, T mx) { min = mn; max = mx; }

            public bool IsInRange(T t)
            {
                return t.CompareTo(min) >= 0 && t.CompareTo(max) <= 0;
            }
        }

        private class GreaterThanClass<T> where T : IComparable
        {
            T r;

            public GreaterThanClass(T r) { this.r = r; }

            public bool isGreater(T v) { return v.CompareTo(r) > 0; }
        }

        /*----------------------------------------------------
         * Agregador de compara��es
         *****************************************************/
        public class ComparatorAux<T> : IEnumerable<T>
        {
            Comparison<T> comp, oldcomp;
            IEnumerable<T> elems;
   
            public ComparatorAux( IEnumerable<T> elems, Comparison<T> comp)
            {
                this.elems = elems;
                this.comp = comp;
            }

            public ComparatorAux(ComparatorAux<T> elems, Comparison<T> comp)
            {
                this.elems = elems;
                this.comp = comp;
                this.oldcomp = elems.Comp;
            }


            public Comparison<T> Comp
            {
                get { return comp; }
            }

            private int AggregateComparison(T t1, T t2)
            {
                int res = 0;
                if (oldcomp != null && (res = oldcomp(t1, t2)) != 0)
                        return res;
                return comp(t1, t2);
            }
                    

            #region IEnumerable<T> Members

            public IEnumerator<T> GetEnumerator()
            {
                List<T> sortContainer = new List<T>();
                ForEach(elems, t => sortContainer.Add(t));
                sortContainer.Sort(AggregateComparison);
                return sortContainer.GetEnumerator();
            }

            #endregion

            #region IEnumerable Members

            IEnumerator IEnumerable.GetEnumerator()
            {
                return GetEnumerator();
        
            }

            #endregion

        }

        /*----------------------------------------------------
       * Agregador de compara��es(vers�o 2)
       *****************************************************/
        public class ComparatorAux2<T> : IEnumerable<T>, IEnumerator<T>
        {
            List<Comparison<T>> comps;
            IEnumerable<T> elems;
            IEnumerator<T> sortedElems;
            List<T> sortContainer;

            public ComparatorAux2(IEnumerable<T> elems)
            {
                this.elems = elems;
                comps = new List<Comparison<T>>();
            }


            public void addComp(Comparison<T> comp)
            {
                comps.Add(comp);
            }

            private int AggregateComparison(T t1, T t2)
            {
                int res = 0;
                foreach (Comparison<T> c in comps)
                {
                    if ((res = c(t1, t2)) != 0) break;
                }
                return res;
            }


            #region IEnumerable<T> Members

            public IEnumerator<T> GetEnumerator()
            {
                return this;
            }

            #endregion

            #region IEnumerable Members

            IEnumerator IEnumerable.GetEnumerator()
            {
                return this;
            }

            #endregion

            #region IEnumerator<T> Members

            public T Current
            {
                get
                {
                    return sortedElems.Current;
                }
            }

            #endregion

            #region IDisposable Members

            public void Dispose()
            {

            }

            #endregion

            #region IEnumerator Members

            object IEnumerator.Current
            {
                get
                {
                    return Current;
                }
            }

            public bool MoveNext()
            {
                if (sortContainer == null)
                {
                    sortContainer = new List<T>();
                    ForEach(elems, t => sortContainer.Add(t));
                    sortContainer.Sort(AggregateComparison);
                    sortedElems = sortContainer.GetEnumerator();
                }
                return sortedElems.MoveNext();
            }

            public void Reset()
            {
                throw new NotImplementedException();
            }

            #endregion
        }
        #endregion

        /*-------------------------------------------------------------
         * Generic Algorithms
         *------------------------------------------------------------*/


        public static void ForEach<T>(this IEnumerable<T> vals, Action<T> action)
        {
            foreach (T t in vals) action(t);
        }

        public static int CountIf<T>(this IEnumerable<T> c, Predicate<T> p)
        {
            int counter = 0;
            foreach (T i in c)
            {
                if (p(i)) counter++;
            }
            return counter;
        }


        //public static ComparatorAux<T>  OrderBy<T,U>(this IEnumerable<T> c, Func<T,U> key ) where U : IComparable<U>
        //{
        //    ComparatorAux<T> ca = new ComparatorAux<T>(c,  (e1, e2) => key(e1).CompareTo(key(e2)));
        //    return ca;
        //}
 
        
        //public static ComparatorAux<T> ThenBy<T,U>(this ComparatorAux<T> c, Func<T,U> key ) where U : IComparable<U>
        //{
        //    ComparatorAux<T> ca = new ComparatorAux<T>(c, (e1, e2) => { 
        //                                                        int res = c.CompareTo(key(e1), key(e2));
        //                                                        if (res == 0)
        //                                                            res = key(e1).CompareTo(key(e2));
        //                                                        return res;
        //                                                     });
        //}

        public static ComparatorAux<T> OrderBy<T,U>(this IEnumerable<T> c, Func<T, U> conv) where U : IComparable<U>
        {
            Console.WriteLine("OrderBy");
           return  new ComparatorAux<T>(c, (p1,p2) => conv(p1).CompareTo(conv(p2)));
  
        }
 
        public static ComparatorAux<T> ThenBy<T,U>(this ComparatorAux<T> c, Func<T, U> conv) where U : IComparable<U>
        {
            Console.WriteLine("ThenBy");
            return new ComparatorAux<T>(c, (p1, p2) =>
            {
                Comparison<T> comp = c.Comp;
                int res = 0;
                if ((res = comp(p1, p2)) != 0) return res;
                return conv(p1).CompareTo(conv(p2));
            });

  
        }

		public static IEnumerable<T> Where<T>(this IEnumerable<T> vals, Predicate<T> p) {
			Console.WriteLine("Select with explicit enumerable");
			return new WhereIterator<T>(vals, p);
		}

		public static IEnumerable<T> Where2<T>(this IEnumerable<T> vals, Predicate<T> p)
		{
            Console.WriteLine("Select with C# iterator");
			foreach (T i in vals)
			{
				if (p(i)) yield return i;
			}
			yield break;
		}

        public static IEnumerable<T> InRange<T>( this IEnumerable<T> ts, T min, T max)
            where T : IComparable<T>
        {
            return Where(ts, new RangeComparer<T>(min, max).IsInRange);
        }

        public static IEnumerable<T> InRange2<T>( IEnumerable<T> ts, T min, T max)
             where T : IComparable<T>
        {
            return Where(ts,  delegate(T t) { return t.CompareTo(min) >= 0 && t.CompareTo(max) <= 0; });
        }

        public static IEnumerable<T> InRange3<T>(IEnumerable<T> ts, T min, T max)
           where T : IComparable<T>
        {
            return Where(ts, t => t.CompareTo(min) >= 0 && t.CompareTo(max) <= 0 );
        }

        public static IEnumerable<T> removeDuplicates<T>(IEnumerable<T> vals)
        {
            List<T> res = new List<T>();
            foreach (T t in vals)
            {
				if (res.IndexOf(t) == -1)
				{
					res.Add(t);
					yield return t;
				}
            }
        }

        public static int CountGreaterThan<T>(IEnumerable<T> c, T v) where T : IComparable
        {
            GreaterThanClass<T> gtc = new GreaterThanClass<T>(v);
            return CountIf(c, gtc.isGreater);
        }

        public static int CountGreaterThan2<T>(IEnumerable<T> c, T v)
            where T : IComparable<T>
        {

            return CountIf(c, delegate(T i) { return i.CompareTo(v) > 0; });
        }

        public static IEnumerable<T> GreaterThan<T>(this IEnumerable<T> c, T v) where T : IComparable
        {

            return Where(c, t => t.CompareTo(v) > 0);
        }

        public static IEnumerable<U> Convert<T, U>(this IEnumerable<T> c, Func<T, U> f)
        {
            Console.WriteLine("Convert!");
            foreach (T v in c) 
                yield return f(v);
        }

        public static IEnumerable<U> Select<T, U>(this IEnumerable<T> c, Func<T, U> f)
        {
            Console.WriteLine("Select!");
            foreach (T v in c)
                yield return f(v);
        }

} 


      
	class Program {


        static void Test2()
        {
            List<int> list = new List<int>(new int[] { 2, 5, 12, 4, 2, 3, 5, 7, 7 });


            //GenericAlgorithms.ForEach(
            //    GenericAlgorithms.Where2(list, v => v % 3 == 0),
            //    v => Console.WriteLine(v));

            //list.
            //    Where2(v => v % 3 == 0).
            //    ForEach(v => Console.WriteLine(v));

#if WithLinq
            (from v in list
             where v % 3 == 0
             select v).ForEach(Console.WriteLine);
            
#endif

            Console.WriteLine("\nDone");
        }

        static void Test1()
        {
            List<int> list = new List<int>(new int[] { 2, 5, 12, 4, 2, 3, 5, 7, 7 });

            IEnumerable<int> lres = GenericAlgorithms.InRange2(list, 3, 7);

            GenericAlgorithms.ForEach(lres, Console.WriteLine);

            Console.WriteLine("Initial List: ");
            GenericAlgorithms.show(list);

            var l = GenericAlgorithms.removeDuplicates(list);

            Console.WriteLine("After removing duplicates: ");
            GenericAlgorithms.ForEach(l, Console.WriteLine);

            Console.WriteLine("Count greater than 5: " + GenericAlgorithms.CountGreaterThan(list, 5));
            Console.WriteLine("Count greater than 5 with anonym method: " + GenericAlgorithms.CountGreaterThan2(list, 5));
        }

        static void Test3()
        {
            List<Point> list = new List<Point>(new Point[] { new Point(1, 2),
                                                             new Point(3, 4),
                                                             new Point(3, 5) });

            IEnumerable<Point> lres = GenericAlgorithms.GreaterThan(list, new Point(2, 3));
            var lres2 = lres.Convert(p => new { a = p.y, b = p.x, c = 0 });
            Console.WriteLine(lres2);
            GenericAlgorithms.ForEach(lres2, (i => Console.WriteLine(i)));

#if WithLinq
            (from p in list
             where p.CompareTo(new Point(2, 3)) > 0
             select new { a = p.y, b = p.x, c = 0 }).ForEach(Console.WriteLine);

#endif


        }

        static void Test4()
        {
            List<Point> list = new List<Point>(new Point[] { new Point(2, 1),
                                                             new Point(3, 4),
                                                             new Point(3, 5),
                                                             new Point(1, 2) });


            (list.
             OrderBy(p => p.y)).
             ThenBy(p => p.x).
             ForEach(p => Console.WriteLine(p));

            var s = (from p1 in list
                     orderby p1
                     select p1).
                     ThenBy( p => p.x );
                    
            s.ForEach(p => Console.WriteLine(p));

                 
        }



#if testgen
        public static void testgen()
        {
            //List<int> list =
            //       new List<int>(new int[] { 2, 5, 12, 4, 2, 3, 5, 7, 7 });
            //Console.WriteLine("Original list: ");
            //GenericAlgorithms.ForEach(list, Console.WriteLine);
            //IEnumerable<int> temp1 = GenericAlgorithms.InRange(list, 10, 20);

            
            //Console.WriteLine("After first selection: ");
            //GenericAlgorithms.ForEach(temp1, Console.WriteLine);
         
            //IEnumerable<int> temp2 = GenericAlgorithms.Where(temp1, i => i % 2 == 0);
            //Console.WriteLine("After second selection: ");
         
            //GenericAlgorithms.ForEach(temp2, Console.WriteLine);

            List<int> list =
                   new List<int>(new int[] { 2, 5, 12, 4, 2, 3, 5, 15, 16, 7, 7 });
            Console.WriteLine("Original list: ");

            GenericAlgorithms.ForEach(list, Console.WriteLine);
            Console.WriteLine("After second selection: ");
            //GenericAlgorithms.ForEach(
            //    GenericAlgorithms.Where(
            //      GenericAlgorithms.InRange(list, 10, 20), i => i % 2 == 0), 
            //      Console.WriteLine);

            list.AsEnumerable<int>().
                InRange(10, 20).
                Where(i => i % 2 == 0).
                ForEach(Console.WriteLine);
           
        }
         
#endif
		static void Main(string[] args) {
            Test4();
		}
	}
}
