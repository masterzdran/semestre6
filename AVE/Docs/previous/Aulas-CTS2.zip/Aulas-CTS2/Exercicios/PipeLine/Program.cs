using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

 
public interface IntPipelineStep
{
    /* o m�todo seguinte representa um passo do pipeline de valores double. 
       O primeiro par�metro diz o n�mero do passo a executar (de 1 a N). 
       O segundo par�metro � o input do passo (output do passo anterior);
    */
    double Process(int stepNumber, double parm1);
}

public class Pipeline
{
    public void Register(IntPipelineStep p)
    {
        /* acrescenta o passo �p� no fim do pipeline*/
    }

    public void Unregister(IntPipelineStep p)
    {
        /* retira o passo �p� do pipeline */
    }

    public double Process(double initial)
    {
        return 0.0;
    }
}

public delegate double StepHandler(int stepNumber, double parm1);

public class Pipeline2
{
    private StepHandler pipeline;

    public void Register(StepHandler p)
    {
        pipeline += p;
    }

    public void Unregister(StepHandler p)
    {
        pipeline -= p;
    }

    public double Process(double initial)
    {
        if (pipeline == null)
            throw new InvalidOperationException("Empty Pipeline!");
        Delegate[] steps = pipeline.GetInvocationList(); ;
         
        double currValue = initial;
        for (int i = 0; i < steps.Length; ++i)
            currValue = ((StepHandler)steps[i])(i+1, currValue);
        return currValue;
    }

    public void addStep(int stepNumber, StepHandler p)
    {
        Delegate[] steps =  pipeline.GetInvocationList();
        if (stepNumber == steps.Length + 1) { Register(p); return; }
        if (stepNumber < 0 || stepNumber > steps.Length)
            throw new InvalidOperationException("Invalid step number!");
        StepHandler newPipe = null;
        for (int i = 1; i <stepNumber;++i)
        {
            newPipe += (StepHandler) steps[i-1];
        }
        newPipe += p;
        for (int i = stepNumber; i <= steps.Length; ++i)
        {
            newPipe += (StepHandler) steps[i-1];
        }
        pipeline = newPipe;
    }

    public void addStep2(int stepNumber, StepHandler p)
    {
        Delegate[] steps = pipeline.GetInvocationList();
        if (stepNumber == steps.Length + 1) { Register(p); return; }
        if (stepNumber < 0 || stepNumber > steps.Length)
            throw new InvalidOperationException("Invalid step number!");
     
        for (int i = stepNumber; i <= steps.Length; ++i )
        {
            pipeline -= (StepHandler)steps[i - 1];
        }
        pipeline += p;
        for (int i = stepNumber; i <= steps.Length; ++i)
        {
            pipeline += (StepHandler)steps[i - 1];
        }
        
    }

    public void reset()
    {
        pipeline = null;
    }
}

class Program
{
    static double stepA(int sn, double val)
    {
        Console.WriteLine("in stepA");
        return val + 1.0;
    }

    static double stepB(int sn, double val)
    {
        Console.WriteLine("in stepB");
        return val *2.0;
    }

    static double stepC(int sn, double val)
    {
        //Console.WriteLine("in stepC");
        return val - 2.0;
    }

    static void Main(string[] args)
    {
        Pipeline2 pipe = new Pipeline2();

        Stopwatch sw = Stopwatch.StartNew();
        pipe.Register(stepA);
        pipe.Register(stepB);

        for (int i=0; i < 1000; ++i) pipe.addStep(i+2, stepC);
        sw.Stop();
        Console.WriteLine("addStep in {0}ms", sw.ElapsedMilliseconds);
        Console.WriteLine(pipe.Process(5.0));

        pipe.reset();

        sw = Stopwatch.StartNew();
        pipe.Register(stepA);
        pipe.Register(stepB);

        for (int i = 0; i < 1000; ++i) pipe.addStep2(i+2, stepC);
        sw.Stop();
        Console.WriteLine("addStep2 in {0}ms", sw.ElapsedMilliseconds);
        Console.WriteLine(pipe.Process(5.0));

    }
}

