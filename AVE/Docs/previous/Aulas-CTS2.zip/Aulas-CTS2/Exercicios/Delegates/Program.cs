using System;
using System.Collections.Generic;
using System.Text;

namespace Delegates
{

    class TemperatureEventArg : EventArgs {
        public readonly double temperature;
        public TemperatureEventArg(double t) { temperature = t; }
    }


    class TemperatureAlarmGenerator {
        public event EventHandler Alarm;

        private void alarmTracer(object src, EventArgs args)
        {
            Console.WriteLine("Temperature alarm at {0}, {1} listeners", DateTime.Now, Alarm.GetInvocationList().Length-1);
        }
 
        protected virtual void onAlarm(TemperatureEventArg args) {
            if (Alarm!= null) Alarm(this, args);
        }

        public void fireAlarm(int temperature) {
            onAlarm(new TemperatureEventArg(temperature));
        }
    }


    class Program
    {
        private static void alarmTracer(object src,  EventArgs args)
        {
            Console.WriteLine("Temperature is {0}�", ((TemperatureEventArg)args).temperature);
        }

        static void Main(string[] args)
        {

            TemperatureAlarmGenerator ag = new TemperatureAlarmGenerator();

            ag.Alarm  += alarmTracer;
            ag.fireAlarm(35);

        }
    }
}
