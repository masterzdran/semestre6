using System;
using System.Collections.Generic;
using System.Text;

namespace Questao1
{
    abstract class Base : IComparable
    {
        int IComparable.CompareTo(object obj)
        {
            CompareTo(obj);
            Console.WriteLine("Base's CompareTo");
            
            return 0;
        }
        protected abstract int CompareTo(object o);
    }

    class Derived : Base 
    {
        protected override int CompareTo(object obj)
        {
            Console.WriteLine("Derived's CompareTo");
            return 0;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            IComparable i = new Derived();
            i.CompareTo(null);
        }
    }
}
