using System;
using System.Collections.Generic;
using System.Text;

namespace Interfaces
{
    interface I
    {
        void MVirtual();
    }

    class A : I
    {
        public void MVirtual() { Console.Write("A "); }
        void I.MVirtual() { Console.Write("Explicit "); }
    }

    class B : A, I
    {
        public new void MVirtual() { Console.Write("B "); }
    }

    class Program
    {
        static void Main(string[] args)
        {
            A a = new B();
            a.MVirtual();
            I i1 = a;
            i1.MVirtual();

        }
    }
}
