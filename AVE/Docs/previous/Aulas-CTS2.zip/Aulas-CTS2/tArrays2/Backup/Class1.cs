/* 
 * N-Dimentional arrays versus jagged arrays
 */

using System;

namespace tArrays2
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			
			int[,] a = new int[10,10];

            Console.WriteLine("\nBi-dimentional array\n");
			System.Console.WriteLine(a.GetType().FullName);
			System.Console.WriteLine(a.GetType().BaseType.FullName);


			a[0,2] = 3;
			Console.WriteLine(a[0,2]);
            System.Console.WriteLine("Numero de Dimensoes: {0}", a.Rank);
 
		
            Console.WriteLine("\nJagged Array\n");
			
			int[][] ja = new int[10][];
			System.Console.WriteLine("Jagged Type: "+ja.GetType());
			System.Console.WriteLine("Jagged Based Type: "+ja.GetType().BaseType);

            System.Console.WriteLine("Numero de Dimensoes: {0}" , ja.Rank);
 
			ja[0] = new int[4];
			ja[0][2]=3;
            Console.WriteLine(ja[0][2]);

		}
	}
}
