using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;

namespace GenericUtils {

    public struct Pair<T, U>
    {
        public readonly T v1;
        public readonly U v2;

        public Pair(T v1, U v2)
        {
            this.v1 = v1; this.v2 = v2;
        }

        public override string ToString()
        {
            return string.Format("({0},{1})", v1.ToString(), v2.ToString());
        }

    }

    class GenericAlgorithms
    {

        public static int CountIf<T>(IEnumerable<T> c,  Predicate<T> p)
        {
            int counter = 0;
            foreach (T i in c)
            {
                if (p(i)) counter++;
            }
            return counter;
        }

        public static List<T> removeDuplicates<T>(IEnumerable<T> vals)
        {
            List<T> res = new List<T>();
            foreach (T t in vals)
            {
                if (res.IndexOf(t) == -1) res.Add(t);
            }
            return res;
        }

        private class GreaterThanClass<T> where T : IComparable
        {
            T r;

            public GreaterThanClass(T r) { this.r = r; }

            public bool isGreater(T v) { return v.CompareTo(r) > 0; }
        }

        public static int CountGreaterThan<T>(IEnumerable<T> c, T v) where T : IComparable
        {
            GreaterThanClass<T> gtc = new GreaterThanClass<T>(v);
            return CountIf(c, gtc.isGreater);
        }

        public static int CountGreaterThan2<T>(IEnumerable<T> c, T v)
            where T : IComparable<T>
        {

            return CountIf(c, delegate(T i) { return i.CompareTo(v) > 0; });
        }

        public static List<T> LessThan<T>(ICollection<T> col, T refVal) where T : IComparable<T> {
            List<T> ll = new List<T>();
            foreach(T val in col)  
                if (val.CompareTo(refVal) < 0) ll.Add(val);
            return ll;
        }

        public static List<T> LessThan0<T>(ICollection<Nullable<T>> col, T refVal) 
            where T : struct, IComparable<T>
        {
            List<T> ll = new List<T>();
            foreach (Nullable<T> nval in col)
                if (nval.HasValue && nval.Value.CompareTo(refVal) < 0) ll.Add(nval.Value);
            return ll;
        }

        public static List<T> LessThan00<T>(ICollection<T?> col, T refVal)
            where T : struct, IComparable<T>
        {
            List<T> ll = new List<T>();
            foreach (T? nval in col)
                if (nval.HasValue && nval.Value.CompareTo(refVal) < 0) ll.Add(nval.Value);
            return ll;
        }
       
        












        public static List<T> LessThan2<T>(ICollection<T?> col, T refVal) where T : struct, IComparable<T>
        {
            List<T> ll = new List<T>();
            foreach (T? val in col)
                if (val.HasValue && val.Value.CompareTo(refVal) < 0) ll.Add(val.Value);
            return ll;
        }


        public static IEnumerable<T> LessThan3<T>(IEnumerable<T?> col, T refVal) 
            where T : struct, IComparable<T>
        {
          
            foreach (T? val in col)
                if (val.HasValue && val.Value.CompareTo(refVal) < 0)
                    yield return val.Value;
           
        }



        internal class CountIterator<T> : IEnumerable<Pair<T?, int>>, IEnumerator<Pair<T?, int>> where T : struct
        {
            private IEnumerator<KeyValuePair<T?, int>> vals;
            private int nullCount;

            public CountIterator(Dictionary<T?, int> vals, int nullCount)
            {
                this.vals = vals.GetEnumerator();
                this.nullCount = nullCount;
            }


            #region IEnumerable<Pair<T?,int>> Members

            public IEnumerator<Pair<T?, int>> GetEnumerator()
            {
                return this;
            }

            #endregion

            #region IEnumerable Members

            IEnumerator IEnumerable.GetEnumerator()
            {
                return this;
            }

            #endregion

            #region IEnumerator<Pair<T?,int>> Members

            public Pair<T?, int> Current
            {
                get
                {
                    if (nullCount != 0)
                    {
                        int oldCount = nullCount;
                        nullCount = 0;
                        return new Pair<T?, int>(null, oldCount);
                    }
                    KeyValuePair<T?, int> val = vals.Current;
                    return new Pair<T?, int>(val.Key, val.Value);
                }

            }

            #endregion

            #region IDisposable Members

            public void Dispose()
            {

            }

            #endregion

            #region IEnumerator Members

            object IEnumerator.Current
            {
                get
                {
                    return Current;
                }

            }

            public bool MoveNext()
            {
                if (nullCount != 0) return true;
                else return vals.MoveNext();

            }

            public void Reset()
            {
                throw new Exception("The method or operation is not implemented.");
            }

            #endregion
        }

        public static IEnumerable<Pair<T, int>> CountRepeated0<T>(IEnumerable<T> seq) 
        {
            Dictionary<T, int> vals = new Dictionary<T, int>();
            foreach (T key in seq)
            {
                int count = 0;
                
                if (vals.TryGetValue(key, out count))
                {
                    count++;
                }
                else count = 1;
                vals[key] = count;
            }
            List<Pair<T, int>> pairs = new List<Pair<T, int>>();
            foreach( KeyValuePair<T,int> kv in vals) 
                pairs.Add(new Pair<T,int>(kv.Key, kv.Value));
            return pairs;
        }


        public static IEnumerable<Pair<T?, int>> CountRepeated<T>(IEnumerable<T?> seq) where T : struct
        {
            Dictionary<T?, int> vals = new Dictionary<T?, int>();
            int nullCount = 0;
            foreach (T? key in seq)
            {
                int count = 0;


                if (key == null) nullCount++;
                else
                {
                    if (vals.TryGetValue(key, out count))
                    {
                        count++;
                    }
                    else count = 1;
                    vals[key] = count;
                }
            }
            return new CountIterator<T>(vals, nullCount);
        }


        public static IEnumerable<Pair<T?, int>> CountRepeated2<T>(IEnumerable<T?> seq) where T : struct
        {
            Dictionary<T?, int> vals = new Dictionary<T?, int>();
            int nullCount = 0;
            foreach (T? key in seq)
            {
                int count = 0;


                if (key == null) nullCount++;
                else
                {
                    if (vals.TryGetValue(key, out count))
                    {
                        count++;
                    }
                    else count = 1;
                    vals[key] = count;
                }
            }
            if (nullCount != 0)
                yield return new Pair<T?, int>(null, nullCount);

            foreach (KeyValuePair<T?, int> val in vals)
                yield return new Pair<T?, int>(val.Key, val.Value);
        }


        public static void show<T>(IEnumerable<T> c)
        {
            Console.Write('[');
            IEnumerator<T> e = c.GetEnumerator();
            if (e.MoveNext())
            {
                Console.Write(e.Current);
                while (e.MoveNext())
                {
                    Console.Write(", " + e.Current);
                }
            }
            Console.WriteLine(']');
        }

        public static void show2(IEnumerable c)
        {
            Console.Write('[');
            IEnumerator e = c.GetEnumerator();
            if (e.MoveNext())
            {
                Console.Write(e.Current);
                while (e.MoveNext())
                {
                    Console.Write(", " + e.Current);
                }
            }
            Console.WriteLine(']');
        }

        public static readonly string[] namesaux = {
           "Jorge", "Manuel", "Martins", "Pi�o"
        };

        public static IEnumerable<string> names() {
            yield return "Jorge";
            yield return "Manuel";
            yield return "Martins";
            yield return "Pi�o";

            /*
            foreach (string name in namesaux)
                yield return name;
            */
        }


    }

    class Program
    {

        static void Test()
        {
            List<int> list = new List<int>(new int[] { 2, 5, 12, 4, 2, 3, 5, 7, 7 });


            Console.WriteLine("Initial List: "); GenericAlgorithms.show(list);
            list = GenericAlgorithms.removeDuplicates(list);
            Console.WriteLine("After removing duplicates: "); GenericAlgorithms.show(list);
            Console.WriteLine("Count greater than 5: " + GenericAlgorithms.CountGreaterThan(list, 5));
            Console.WriteLine("Count greater than 5 with anonym method: " + GenericAlgorithms.CountGreaterThan2(list, 5));
        }

        static void Main(string[] args)
        {

            //int?[] vals = { 0, null, 3, null, 5, 6, 6, 6, 5, 4 };

            //List<int> lr = GenericAlgorithms.LessThan00(vals, 5);
            //GenericAlgorithms.show(lr);


            //IEnumerable<Pair<int, int>> pairs = GenericAlgorithms.CountRepeated0(vals);
            //foreach (Pair<int, int> pair in pairs)
            //{
            //    Console.WriteLine(pair.ToString());
            //}

            foreach( string name in GenericAlgorithms.names()) {
                Console.WriteLine(name);
            }

        }
    }

}
