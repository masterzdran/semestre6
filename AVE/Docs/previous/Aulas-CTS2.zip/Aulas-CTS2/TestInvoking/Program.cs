using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

namespace TestInvoking
{
    interface IValidator {
        bool validate();
    }

    class A : IValidator {
    
       
        virtual public bool  validate()
        {
 	        return true;
        }

        virtual public bool method1() {
            //Console.WriteLine("Method 1 in A");
            return true;
        }

    }

    class B : A {
        override public bool  validate()
        {
 	        return true;
        }

        override  public bool method1() {
            //Console.WriteLine("Method 1 in A");
            return true;
        }

      

    }

    class C : A {
        override  public bool method1() {
            //Console.WriteLine("Method 1 in A");
            return true;
        }

        override public bool  validate()
        {
 	        return true;
        }

    }

    class D : A {
        override  public bool method1() {
            //Console.WriteLine("Method 1 in A");
            return true;
        }

        override public bool  validate()
        {
 	        return true;
        }

    }

    class Program
    {
        static A[] createArray(int size) {
            A[] a = new A[size];
            for (int i=0; i < size; ++i) {
                switch (i%4) {
                    case 0: a[i] = new D(); break;
                    case 1: a[i] = new D(); break;
                    case 2: a[i] = new D(); break;
                    case 3: a[i] = new D(); break;
                }

            }
          
            return a;
        }

        static void testInvokeInterface() {
            IValidator[]  a = createArray(10000);
            Console.WriteLine("Start test invoking interface dispatch...");
            Stopwatch s = Stopwatch.StartNew();
            for (int n=0; n < 10000; ++n) {
                for(int i=0; i < a.Length; ++i) 
                    a[i].validate(); 
            }
            Console.WriteLine("{0} ms elapsed!", s.ElapsedMilliseconds);
            s.Stop();
        }

         static void testInvokeVirtualMethod() {
            A[]  a = createArray(10000);
            Console.WriteLine("Start test invoking virtual method dispatch...");
            Stopwatch s = Stopwatch.StartNew();
            
            for (int n=0; n < 10000; ++n) {
                for(int i=0; i < a.Length; ++i) 
                    a[i].method1(); 
            }
            Console.WriteLine("{0} ms elapsed!", s.ElapsedMilliseconds);
            s.Stop();
        }

        static void InterfaceMethodInvoke() {
            IValidator a = new A();
            for (int i=0; i < 6; ++i) 
                a.validate();
        }

        static void VirtualMethodInvoke()  {
            A a = new B();
            for (int i=0; i < 6; ++i) 
                a.method1();
        }

        static void Main(string[] args)
        {
            testInvokeInterface();
            testInvokeVirtualMethod();
            
        }
    }


 
}
