﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Arrays
{
	public class A
	{
		public static void EnumArrays()
		{
			int[,] matrix = { { 1, 2 }, { 2, 4 }, { 5, 6 } };
			foreach (int i in matrix) Console.WriteLine(i);
		}
	}

	 
	class Program
	{
		static void Main(string[] args)
		{
            A.EnumArrays();
		}
	}
}
