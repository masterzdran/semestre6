using System;
using System.Collections.Generic;

namespace TArrays
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{


        #region ArrayCreator
        static Array createMatrix(Type elementType, int length)
        {
            return Array.CreateInstance(elementType, length, length);
        } 
        #endregion

		static void testCoVariancia() {
			string[] tabStrings = new string[] { "str1", "str2", "str3" };
			Console.WriteLine("Size={0}", tabStrings.Length);
			foreach( string str in tabStrings) 
				Console.WriteLine(str);			 

			// E o c�digo seguinte?
			object[] tabObjects = tabStrings;  // co-vari�ncia em arrays			
			tabObjects[2]= new object();       // problemas?
		}

        class A { }
			 
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		static void Main(string[] args)
		{
           //int[][] a = new int[10][];
           //for (int i = 0; i < 10; ++i) a[i] = new int[20];

           //a[0][1] = 23;

           //int[,] a1 = new int[10, 20];

           //a1[0, 1] = 23;



           //bool[,] o = (bool[,]) createMatrix(typeof(Boolean), 3);

           //Console.WriteLine(o.GetType());

           //object b00 = o.GetValue(0, 0);

           //bool b = o[0, 0];

           //Console.WriteLine(b00);
           //Console.WriteLine();
           //foreach (Boolean b in o)
           //    Console.WriteLine(b);

           string[] names = { "joao", "rute", "joana" };

           object[] objs = names;

           objs[0] = new A();

           List<string> ls = new List<String>();
           ls.Add("Joao");
           //List<object> lo = ls;

		}
    }
}
