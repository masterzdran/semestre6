﻿#define WITH_GEN_METHOD

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GenericTests
{
	class G<T>  where T: IComparable {
		public static void write(T t) {
			Console.WriteLine(t);
		}

        public static int CompareTo(T t1, T t2) {
            return t1.CompareTo(t2);
        }
	}

#if WITH_GEN_METHOD
    class G 
    {
        public static void write<T>(T t)
        {
            Console.WriteLine(t);
        }

        public static void equals<T>(T t1, T t2) where T: IEquatable<T>
        {
            Console.WriteLine(t1.Equals(t2));
        }
    }
#endif

	class Program
	{
		static void Main(string[] args)
		{
            G<int>.write(3);
            G.equals<int>(2, 3);
		}
	}
}
