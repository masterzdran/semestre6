using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

namespace StaticConstructors
{
    class Teste {
        static int i;
        static Teste() {i=3;}

        public static int I
        {
            get { return i; }
        }
    }

    class Teste2
    {
        static int i = 3;

        public static int I
        {
            get { return i; }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            int a = 0;
            Stopwatch sw = Stopwatch.StartNew();
            for (int i = 0; i < 10000000; ++i)
            {
                a += Teste.I;
            }
            sw.Stop();
            Console.WriteLine(sw.ElapsedMilliseconds);
            sw = Stopwatch.StartNew();
            for (int i = 0; i < 10000000; ++i)
            {
                a += Teste2.I;
            }
            sw.Stop();
            Console.WriteLine(sw.ElapsedMilliseconds);
        }
    }
}
