#define WithMouseEvents

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Variance {
    class A : IComparable<A>, IComparable {  
        int a;

        #region IComparable<A> Members

        public int CompareTo(A other)
        {
            throw new NotImplementedException();
        }

        #endregion

        #region IComparable Members

        public int CompareTo(object obj)
        {
            throw new NotImplementedException();
        }

        #endregion
    }

    class B : A {
        int b;
    }

    class C :B {
        int b;
    }

    class N<T> where T : IComparable { 
        
    }

#if WITH_METHOD_VARIANCE
    class TA
    {
       public virtual  A createFrom(B a) {
           return new A();
       }
    }

    class TB : TA {
        public override B  createFrom(A a) {
            return new B();
        }
    }
#endif

    delegate A TesteVariance(B b);
  
    delegate U TesteVarianceGen<T, U>( T t);


    class Program
    {
        static A Normal(B b) {
            Console.WriteLine("Normal Callback");
            return null;
        }

        static B ReturnCoVariance(B b) {
            Console.WriteLine("ReturnCoVariance Callback");
            return null;
        }

        static A ParameterContraVariance(A b) {
            Console.WriteLine("Parameter ContraVariance Callback");
            return null;
        }

        static A BadVariance(C b)
        {
            Console.WriteLine("Parameter BadVariance Callback");
            return null;
        }


        static void MouseHandler(object src, EventArgs args)
        {
            Console.WriteLine("Handler do Mouse");
        }

        static void testDelegateVariance()
        {

            TesteVariance t = null;
            TesteVarianceGen<B, B> tgab = null;


            t += Normal;
            t += ReturnCoVariance;
            t += ParameterContraVariance;

            t(null);


#if WithMouseEvents
            MouseEventHandler me;
            me = new MouseEventHandler(MouseHandler);
#endif
        }

        
         

        static void Main(string[] args) {
           
            testDelegateVariance();

        }
    }
}
