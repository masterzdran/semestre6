﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace LinqExamples
{
    class Program
    {
        public static IEnumerable<FileInfo> GetDirectoryEnumerator(DirectoryInfo di)
        {
            foreach (FileInfo fi in di.GetFiles())
            {
                yield return fi;
            }
            foreach (DirectoryInfo childDi in di.GetDirectories())
            {
                foreach (FileInfo fi in GetDirectoryEnumerator(childDi)) yield return fi;
            }
        }

        public static IEnumerable<string> GetLines(FileInfo fi)
        {
            string l;
            using (TextReader tr = new StreamReader(fi.OpenRead()))
            {
                while ((l = tr.ReadLine()) != null)
                {
                    yield return l;
                }
            }
        }

        public static int CountLines(FileInfo fi)
        {
            int res = 0;
            using (TextReader tr = new StreamReader(fi.OpenRead()))
            {
                while (tr.ReadLine() != null)
                    res++;
            }
            return res;
        }

        public static void ShowAllWithString(string path, string substring)
        {
            DirectoryInfo di = new DirectoryInfo(path);
            var res = GetDirectoryEnumerator(di)
              .Where(fi => fi.Extension == ".cs")
              .SelectMany(fi => GetLines(fi).Select(s => new { File = fi, Line = s }))
              .Where(p => p.Line.Contains(substring));

            foreach (var p in res)
            {
                Console.WriteLine("file = {0}; line = {1}", p.File.FullName, p.Line);
            }
        }

        public static void ShowNumberOfLines(string path, string substring)
        {
            DirectoryInfo di = new DirectoryInfo(path);
            var res = GetDirectoryEnumerator(di)
              .Where(fi => fi.Extension == ".cs")
              .Select(fi => new { File = fi, Lines = CountLines(fi) });
         
            foreach (var p in res)
            {
                Console.WriteLine("file = {0}; lines = {1}", p.File.FullName, p.Lines);
            }
        }

        public static void ShowNumberOfLines2(string path, string substring)
        {
            DirectoryInfo di = new DirectoryInfo(path);
            var res = from fi in GetDirectoryEnumerator(di)
                      where fi.Extension == ".cs"
                      select new { File = fi, Lines = CountLines(fi) };

            foreach (var p in res)
            {
                Console.WriteLine("file = {0}; lines = {1}", p.File.FullName, p.Lines);
            }
        }
       

        static void Main(string[] args)
        {
            ShowNumberOfLines2(@"C:\Home\disciplinas\AVE\1S2010-2011\src\Aulas-CTS2", "yield");
      
        }
    }
}
