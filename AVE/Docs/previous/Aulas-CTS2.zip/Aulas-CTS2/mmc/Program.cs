using System;
using System.Collections.Generic;
using System.Text;

namespace mmc
{
    struct RGB {
        public readonly byte r, g, b;
        public RGB(int r, int g, int b) {
            this.r = (byte)r; this.g = (byte)g; this.b = (byte)b;
        }
    }

    class Program
    {
        public static long mmc(int n1, int n2, int n3)
        {
            
            long mmc = n2;
            while (mmc % n1 != 0 || mmc % n3 != 0)
            {
               
                mmc += n2;
            }
            return mmc;
        }


        public static int  rgb() 
        {
            RGB[] colors = new RGB[256*256*256];

            int c=0;
            for (int r=0; r < 256; r++)
                for (int g=0; g < 256; ++g)
                    for (int b=0;b < 256; ++b)
                        colors[c++] = new RGB(r,g,b);
            int df=0;
            for(c=0; c < colors.Length; ++c) {
                RGB color = colors[c];
                if (color.b != color.g && color.g != color.r && color.r != color.b) df++;
            }
            return df;
        }

        static void Main(string[] args)
        {
           // Console.WriteLine(mmc(22500, 1024, 60));
           // Console.WriteLine(mmc(256, 60, 60));
           Console.WriteLine(mmc(28800, 1024, 1024));
           //Console.WriteLine(rgb( ));
        }
    }
}
