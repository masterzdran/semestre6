﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CaptureContext
{
    class ContextExample {
        public int aField;
        public Action AMethod(int aParam)  {
            long aLocal  = DateTime.Now.Millisecond;
            return delegate {
             Console.WriteLine("aField = {0}, aParam = {1}, aLocal = {2}", aField, aParam, aLocal);
                        aLocal += 1; aField += 1;
                    };
        }

        public static void ContextTest() {
            ContextExample ce1 = new ContextExample();
            ContextExample ce2 = new ContextExample();
            ce1.aField = 1;
            Action mi1 = ce1.AMethod(2);
            mi1(); // aField = 1, aParam = 2, aLocal = x
            ce1.aField = 3;
            mi1(); // aField = 3, aParam = 2, aLocal = x +1
            Action mi2 = ce1.AMethod(20);
            mi2(); // aField = 4, aParam = 20, aLocal = y
            mi1(); // aField = 5, aParam = 2, aLocal = x + 2
        }

        public static void Main()
        {
            ContextTest();
        }
    }
}
