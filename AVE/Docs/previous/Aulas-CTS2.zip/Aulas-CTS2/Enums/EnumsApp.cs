using System;
  
namespace CTS {
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
     
 
	 
	class EnumsApp
	{
		
		
		static void Main(string[] args) {
		   AccessModes a = AccessModes.Write | AccessModes.Read;

           //AccessModes a = (AccessModes) AccessModes.Parse(typeof(AccessModes), "Write, Read");
           Console.WriteLine("a= " + a);
		   
           //Console.WriteLine("test:");
		 
		   //EnumTester.test();
		}
	}
}
