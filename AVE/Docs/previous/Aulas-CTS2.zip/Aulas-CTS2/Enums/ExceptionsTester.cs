using System;

namespace CTS2 {
	/// <summary>
	/// Summary description for Exceptions.
	/// </summary>
	
	public class EA : Exception {}
	public class EB : Exception {}

	public class ExceptionsTester 
	{
		
		static void genEA() {
		    throw new EA();
		}
		
		static void genEB() 
		{
			throw new EB();
		}
		
		
		public static void tExceptions() {
		  try {
			genEA();
			genEB();
		  }
		  catch (EA a) {
		  }
		  catch (EB b) 
		  {
		  }
		  
		}
		    
	}
}
