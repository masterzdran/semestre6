using System;

namespace CTS
{
	/// <summary>
	/// Summary description for EnumTester.
	/// </summary>

    // check the differences by uncomment next line
	[Flags] 
	enum AccessModes : byte {
	  Read=1, Write=2, Execute=4, Append=8
	}
	
	
	public class EnumTester {
		public static void showNames() {
			 string[] names = Enum.GetNames(typeof (AccessModes));
			 foreach(string name in names) {
			   Console.WriteLine(name);
			 }
			 
		}
		
		public static void showValues() {
			Array values = Enum.GetValues(typeof (AccessModes));
			foreach(int val in values) 
			{
				Console.WriteLine(val);
			}
			 
		}
		
		public static void test() {
		  showValues();
		  showNames();
		}
	}
}
