using System;
using System.Collections;
 
namespace CTS2
{
    delegate int Comparator(object o1, object o2);
   
    class Program
    {

        public static void sort(object[] vals, Comparator cmp)
        {
            for (int i = vals.Length - 1; i > 0; --i)
            {
                for (int j = 0; j < i; j++)
                {
                    if (cmp(vals[j], vals[j + 1]) > 0)
                    {
                        object temp = vals[j];
                        vals[j] = vals[j + 1];
                        vals[j + 1] = temp;
                    }
                }
            }
        }

        public static void sortByCustomSort()
        {
            object[] vals = { 3, 1, 8, 4, 5, 2 };
            MyComparators mc = new MyComparators();
            sort(vals, mc.intComparer);

            foreach (int i in vals) Console.WriteLine(i);
        }

        public static void sortByArraySort()
        {
            int[] vals = new int[] { 2, 8, 13, 5, 4 };
           
            Array.Sort(vals);
          
            foreach (int i in vals) Console.WriteLine(i);
        }

        class MyComparators
        {
            public int intComparer(object o1, object o2)
            {
                int i1 = (int)o1;
                int i2 = (int)o2;
                return i1 - i2;
            }
        }


        static void Main(string[] args) {

            sortByArraySort();
            // sortByCustomSort()
        }
    }
}
