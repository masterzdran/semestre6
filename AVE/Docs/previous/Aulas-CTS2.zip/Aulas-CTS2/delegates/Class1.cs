using System;
using System.Collections;

namespace delegates
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	
	delegate void Logger(string msg, int descriptor);
	
	class Process {
		
		public Logger logger;
		
		/*
        
        public event Logger logger;
        */
        
        /*
        private Logger _logger;
         
		public event Logger logger {
			add {
			  _logger += value;
			}
			remove {
			  _logger -= value;
			}
		}
        */
		
		public void doWork() {
		  // .... working....
		  
		  // logging error
		  
		  if (logger != null)
		     logger("erro1", 23);
		  
		} 
	}
		
	class MyFileLogger {
	    // callback em m�todo de inst�ncia
		public  void log(string s, int id) {
			System.Console.WriteLine("MyFileLogger: MSG={0}, ID={1}", s, id);
		}
	}
	
	class MyConsoleLogger {
		// callback em m�todo est�tico
		public  static void log(string s, int id) {
			System.Console.WriteLine("MyConsoleLogger: MSG={0}, ID={1}", s, id);
		}
	}
		
	class Class1
	{
		private static void callbackEvent1(object src, EventArgs args) 
		{
			System.Console.WriteLine("em callback de Event1!");
		}
		
		public static void CheckTypeWithManyEvents() 
		{
			TypeWithManyEvents t = new TypeWithManyEvents();
			t.Event1 += new EventHandler(callbackEvent1);
			t.generateEvent1();
		}
	
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args) {
		  
		   Process p = new Process();
		   MyFileLogger fl = new MyFileLogger();
		    
		    // registar o callback
		   p.logger += new Logger(fl.log);
		   p.logger += new Logger(MyConsoleLogger.log);
		   
		   p.logger -= new Logger(MyConsoleLogger.log);
		    
		   p.doWork();
		   
		 
		   CheckTypeWithManyEvents();
		 
		}
	}
}
