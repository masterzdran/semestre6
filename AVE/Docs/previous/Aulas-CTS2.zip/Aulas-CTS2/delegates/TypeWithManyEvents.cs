using System;
using System.Collections;

namespace delegates {
	/// <summary>
	/// Summary description for Class2.
	/// </summary>
		
	public class EventsSet {
		private Hashtable events;
		
		internal EventsSet() {
		 events = new Hashtable();
		}
		
		internal void add(object eventKey, Delegate d) {
			Delegate actual = (Delegate) events[eventKey];
			events[eventKey] = Delegate.Combine(actual, d);
		}
		
		internal void remove(object eventKey, Delegate d) {
			Delegate actual = (Delegate) events[eventKey];
			events[eventKey] = Delegate.Remove(actual, d);
		}
		
		internal Delegate get(object eventKey) {
			return (Delegate) events[eventKey];
		}
		
		public void invokeDelegate(object eventKey, object src, EventArgs args) {
			EventHandler eh = (EventHandler) events[eventKey];
		  
			if (eh != null) {
				eh(src, args); 
			}
		}
		  
	}
	
	 
	
	public class TypeWithManyEvents {
		protected static readonly object Event1Key= new object();
		protected static readonly object Event2Key= new object();
		protected static readonly object Event3Key= new object();
		protected static readonly object Event4Key= new object();
		
		EventsSet events = new EventsSet();
		
		public event EventHandler Event1  {
		  add { events.add(Event1Key, value);  }
		  remove { events.remove(Event1Key, value); }
		}
		
		protected virtual void onEvent1(EventArgs args) {
		 
			EventHandler de = (EventHandler) events.get(Event1Key);
		  
			if (de!= null) {
			   de(this, args);
			}
		  
		}
		
		public void generateEvent1() {
		   onEvent1(EventArgs.Empty);
		}
		
	}
}
