using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Generics
{
	
	class Test<T> : IComparable<T> where T: IComparable<T>{
        T v;

        public Test(T _v) { 
            v= _v;
        }

      
        public void show() {
            Console.WriteLine(v);
        }

        #region IComparable<T> Members

        public int CompareTo(T other)
        {
            return v.CompareTo(other);
        }

        #endregion
    }

	class MyArray<T> where T :  IComparable, IComparable<T> ,new()  {
		T[] vals;
		
		
		//public void destroy() {
		//      for (int i=0; i < vals.Length; ++i) vals[i] = null;
		//}
		
		public MyArray(int size) {
			vals = new T[size];
		    for (int i=0; i < size; ++i) vals[i] = new T();
		}
		
		bool GreaterThan (T t) {
			foreach( T t1 in vals) {
				if (t1.CompareTo(t) > 0) return true;
			}
			return false;
		}
	}
			
	class MyStack<T> : IEnumerable<T> {
		private const int STACKSIZE=100;
		T[] stack;
		int sp;
		
		
		private class Enumerator :  IEnumerator<T> {
			MyStack<T> stack;
			int curr;
		 	
			public Enumerator(MyStack<T> s) {
				stack=s;
				curr = STACKSIZE;
			}
			
			object IEnumerator.Current
			{
				get { return stack.stack[curr]; }
			}
			
			T IEnumerator<T>.Current
			{
				get { return stack.stack[curr]; }
			}

			public bool MoveNext()
			{
				if (stack.sp == curr) return false;
				--curr;
				return true;
			}

			public void Dispose() {
				
			}
			
			public void Reset()
			{
				throw new Exception("The method or operation is not implemented.");
			}

			 
		}
				
		
		public MyStack() {
			stack = new T[STACKSIZE];
			sp = STACKSIZE;
		}
		
		public void push(T t) {
			if (sp==0) throw new Exception("Full Stack!");
			stack[--sp]=t;
		}
		
		public T pop() {
			if (sp==STACKSIZE) throw new Exception("Empty Stack!");
			return stack[sp++];
		}
		
		public IEnumerator<T> GetEnumerator() {
			return new Enumerator(this);
		}
		
	    IEnumerator IEnumerable.GetEnumerator() {
			return new Enumerator(this);
		}
	

	}
			
		
	class Program
	{
		static void Main(string[] args)
		{
            MyArray<int> a = new MyArray<int>(10);

			MyStack<int> si = new MyStack<int>();
			
			MyStack<string> ss = new MyStack<string>();
			
			
			MyStack<Array> ss2 = new MyStack<Array>();
			
			
			
			si.push(2);
			si.push(3);
			
			foreach( int i in si) {
				Console.WriteLine(i);
			}
			ss.push("s1");
			ss.push("s2");
			
			foreach( string i in ss) {
				Console.WriteLine(i);
			}
			
	
		}
	}
}
