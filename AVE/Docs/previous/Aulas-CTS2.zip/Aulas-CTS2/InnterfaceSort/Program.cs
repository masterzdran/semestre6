using System;
using System.Collections.Generic;
using System.Text;

namespace InterfaceSort
{
    struct  IntVal : IComparable
    {
        public readonly int v;

 
        public int CompareTo(object obj)
        {
            if (!(obj is IntVal)) throw new InvalidCastException();
            return v - ((IntVal)obj).v;
        }

        public IntVal(int v) { this.v = v; }

        public override string ToString()
        {
            return v.ToString();
        }
       
    }

 

    class Program
    {
        static IntVal[] createValues(int size)
        {
            IntVal[] values = new IntVal[size];
            for (int i = 0; i < size; ++i)
            {
                values[i] = new IntVal(size - i);
            }
            return values;
        }

        static void showArray(IntVal[] array)
        {
           
            foreach(object o in array)
            {
               Console.WriteLine(o.ToString());
            }
        }


        static void Main(string[] args)
        {
            IntVal[] vals = createValues(20);
            Array.Sort(vals);
            showArray(vals);
        }
    }
}
