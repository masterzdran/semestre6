using System;
using System.Collections.Generic;
using System.Text;

namespace Generics {

	class Teste<T>  where T:struct {
		Nullable<T> nullableVal = null;
		public Teste(Nullable<T> val) {  this.nullableVal=val; }
	}
	
	class Pessoa {
		DateTime dataNasc;
		DateTime?  dataCasamento;
		
		public Pessoa (DateTime dn)  {
			dataNasc= dn;
			dataCasamento = null;
			 
			//DateTime dt = (DateTime) dataCasamento;
			if (dataCasamento==null)
				Console.WriteLine("solteiro!");
			object o = dataCasamento;
			if (o ==null)
				Console.WriteLine("solteiro!");
				
		    DateTime? dt2 = (DateTime?) o;
		    
		    Console.WriteLine("dt2.hasValue={0}", dt2.HasValue);
		    
			
		}
			
	}
	
	
	
	class G1  {
		public static T[] createTArray<T>(int size)   where T :  new()  {
			T[] t = new  T[size];
			for (int i= 0; i < size; ++i) t[i] = new T();
			return t;
		}
		
		public static T max<T>(T t1, T t2) where T : IComparable<T> {
			return (t1.CompareTo(t2)>0) ? t1 : t2;
		}
	}
	
	class Program
	{
		static void Main(string[] args)
		{

            G1.createTArray<int>(10);
			 
			Pessoa p = new Pessoa(DateTime.Now);
		}
	}
}
