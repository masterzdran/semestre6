using System;

interface I{
	void MInstance();
	void MVirtual();
	void MExplicit();
}
abstract class A:I{
	public void MInstance(){Console.WriteLine("A -> instance");}  
	public virtual void MVirtual(){Console.WriteLine("A -> virtual");}  
	void I.MExplicit(){Console.WriteLine("A -> explicit");} 
}
class B:A,I{
	public new virtual void MInstance(){Console.WriteLine("B -> instance");} 
	public override void MVirtual(){Console.WriteLine("B -> virtual");}
	public virtual void MExplicit(){Console.WriteLine("B -> explicit");} 
}
class C:B{
	public override void MInstance(){Console.WriteLine("C -> instance");} 
	public new void MVirtual(){Console.WriteLine("C -> virtual");} 
	public override void MExplicit(){Console.WriteLine("C -> explicit");}
}

class MainClass { 
	static void Main(){ 
		A a = new B();
		a.MInstance();
		a.MVirtual(); 
		((I)a).MExplicit();

		a = new C(); 
		a.MInstance();
		a.MVirtual();
		((I)a).MExplicit();
		 
	}
}

