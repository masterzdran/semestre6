using System;
using System.IO;

namespace CTS2 {
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	
	delegate void Logger(string msg, int code);

    class WorkerProcess {
		
		public event  Logger logger;
		
#if WITH_SIMPLE_EVENT	     
        public event Logger logger;
#elif WITH_CUSTOM_EVENT	      
        private Logger _logger;
         
		public event Logger logger {
			add {
			  _logger += value;
			}
			remove {
			  _logger -= value;
			}
		}
#endif
		
        virtual protected void doLog(string msg, int code) {
            if (logger != null)
                logger(msg, code);
        }

		public void doWork() {
		    // .... working....
		  
		    // logging error
            doLog("erro", 123);
		} 
	}
		
	class MyStreamLogger {
	    // callback em m�todo de inst�ncia
        StreamWriter logStream;

        public MyStreamLogger(Stream logStream) {
            this.logStream = new StreamWriter(logStream);
        }

		public  void log(string s, int id) {
			logStream.WriteLine("MyStreamLogger: MSG={0}, ID={1}", s, id);
            logStream.Flush();
		
		}
	}
	
	class MyConsoleLogger {
		// callback em m�todo est�tico
		public  static void log(string s, int id) {
			System.Console.WriteLine("MyConsoleLogger: MSG={0}, ID={1}", s, id);
		}
	}
		
	class Class1
	{
		
	
		static void Main(string[] args) {
		  
		   WorkerProcess p = new WorkerProcess();
		   MyStreamLogger fl = new MyStreamLogger(Console.OpenStandardOutput());
		    
		    // registar o callback
		   p.logger += new Logger(fl.log);
		   p.logger += new Logger(MyConsoleLogger.log);

		  //p.logger -= new Logger(fl.log);
		   
		   //p.logger -= new Logger(MyConsoleLogger.log);
		    
		   p.doWork();
		 
		}
	}
}
