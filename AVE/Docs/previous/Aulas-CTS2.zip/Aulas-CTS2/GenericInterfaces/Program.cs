using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics; 

namespace Generics0 {
	
	struct TVal : IComparable<TVal>,IComparable {
		public int v;
		
		public TVal(int v) { this.v=v; }
		
		int IComparable.CompareTo(object o) {
		    if (!(o is TVal)) throw new Exception("Invalid Argument!");
		    return CompareTo((TVal) o);
		}
		
		public int CompareTo(object o) {
			if (!(o is TVal)) throw new Exception("Invalid Argument!");
			TVal t = (TVal) o;
			return v - t.v;
		}
		
		public int CompareTo(TVal  t) {
			return v - t.v;
		}
		
		
		 
	}
		
	class Utils   {
		
		
		public static T Greatest<T>(List<T> vals)  where T : IComparable {
			if (vals.Count == 0) throw new Exception("Empty Collection");
			T r = vals[0];
			for(int i=0; i < vals.Count; ++i)  {
				  IComparable ic = vals[i];
				  if (ic.CompareTo(r) > 0) r = vals[i];
			}
			return r;
		}
		
		public static T Greatest2<T>(List<T> vals)  where T : IComparable {
			if (vals.Count == 0) throw new Exception("Empty Collection");
			T r = vals[0];
			for(int i=0; i < vals.Count; ++i)  {
				  if (vals[i].CompareTo(r) > 0) r = vals[i];
			}
			return r;
		}
		
		public static T Greatest3<T>(List<T> vals) where T : IComparable<T>    {
			if (vals.Count == 0) throw new Exception("Empty Collection");
			T r = vals[0];
			for(int i=0; i < vals.Count; ++i)  {
				  if (vals[i].CompareTo(r) > 0) r = vals[i];
			}
			return r;
		}
	}
	
	class Program
	{
		static void Main(string[] args) {
			
			
		    List<TVal> l1 = new List<TVal>();
			for (int i = 0; i < 3000000; ++i)
				l1.Add(new TVal(i));
				
			Stopwatch sw = Stopwatch.StartNew();
			Utils.Greatest(l1);
			Console.WriteLine("Greatest em {0}ms!", sw.ElapsedMilliseconds);
			
		    sw = Stopwatch.StartNew();
			Utils.Greatest2(l1);
			Console.WriteLine("Greatest2 em {0}ms!", sw.ElapsedMilliseconds);
			
			sw = Stopwatch.StartNew();
			Utils.Greatest3(l1);
			Console.WriteLine("Greatest3 em {0}ms!", sw.ElapsedMilliseconds);

			
		}
	}
}
