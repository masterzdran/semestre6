// delegates callbacks with virtual fucntions
// see generated IL

using System;
using System.Collections.Generic;
using System.Text;

namespace VirtualFunc
{
    delegate void DA();

    interface I1
    {
        void f();
    }

    class A : I1
    {
        public virtual void f()
        {
            Console.WriteLine("f de A");
        }
    }

    class B : A
    {
        public override void f()
        {
            Console.WriteLine("f de B");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            I1 a = new B();
            DA da = a.f;

            da();
        }
    }
}
