#define WITH_ANONYMOUS
#define WITH_CLASS
#define WITH_LAMBDA

using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Predicates {
	public delegate bool Predicate(int i);
	public delegate void Action(int i);
	
	
	class Program {
#if WITH_CLASS
		private class GreaterThanAux {
			private int intRef;
			
			public GreaterThanAux(int r) { intRef = r; }
			
			public bool GreaterThanPred(int i) {return i >  intRef; }
		}
#endif				
		public static int countIf(int[] a, Predicate p) {
			int c=0;
			foreach(int i in a) if (p(i)) c++;
			return c;
		}

        private static bool isEven(int v) {
            return v %2==0;
        }

        public static int countEven0(int[] a)
        {
            return countIf(a, new Predicate(isEven));
        }
#if WITH_LAMBDA		
		public static int countEven(int[] a) {
			return countIf(a,  i =>   i %2 ==0 );
		}
#else
		public static int countEven(int[] a) {
			return countIf(a,  delegate(int i) { return i %2 ==0;});
		}
#endif

#if WITH_LAMBDA	
		public static int countOdd(int[] a) {
			return countIf(a, i => i %2 !=0);
		}	
#else
		public static int countOdd(int[] a) {
			return countIf(a,  delegate(int i) {return i %2 !=0; });
		}	
#endif

		static int r;
		
		private static bool isGreater(int i) {
			return i > r;
		}
	    
	    // with static variable: bad! Not Thread safe
	    public static int countGreaterThan1(int[] a, int vr) {
			r = vr;
			return countIf(a, isGreater);
		}

#if WITH_CLASS
		// with auxiliary class: boring!
		public static int countGreaterThan2(int[] a, int vr) {
			GreaterThanAux ga = new GreaterThanAux(vr); 
			return countIf(a,  ga.GreaterThanPred);
		}
#endif	

#if WITH_ANONYMOUS

#if WITH_LAMBDA
		// with anonymous method: ok!
		public static int countGreaterThan3(int[] a, int vr)
		{
			return countIf(a, i => i > vr);
		}
#else
		// with anonymous method: ok!
		public static int countGreaterThan3(int[] a, int vr) {
			return countIf(a,  delegate(int i) { return i > vr; });
		}
#endif

#endif

#if WITH_LAMBDA
		public static  void show(int[] a)
		{
			for (int i=0; i < a.Length; ++i)
				new Thread(() => { Console.WriteLine("i={0}", i); }).Start();
		}
#endif

		static void Main(string[] args)
		{
			int[] vals = { 2, 5, 8, 12, 13 , 16};

			show(vals);

         
			Console.WriteLine(countEven(vals)+countOdd(vals) == vals.Length);
			
            Console.WriteLine(countGreaterThan1(vals, 8));
			Console.WriteLine(countGreaterThan2(vals, 8));
			Console.WriteLine(countGreaterThan3(vals, 8));
		}
	}
}
