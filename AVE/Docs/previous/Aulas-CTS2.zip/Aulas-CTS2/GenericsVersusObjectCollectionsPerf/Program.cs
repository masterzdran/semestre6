using System;
using System.Collections;
using System.Diagnostics;
using System.Collections.Generic;
 
namespace CTS2
{
	delegate long Test();
	 
	class GenericsVersusObjectCollectionsPerf {
	    
		const int COLLECTIONSIZE= 10000000;
		ArrayList vals;
		List<int> genericVals;
		
		public long buildArrayListCollection() {
			vals = new ArrayList(COLLECTIONSIZE);
			for(int i=0; i < COLLECTIONSIZE; ++i) { 
			   vals.Add(i);
			} 
			return COLLECTIONSIZE;
		}
		
		public long buildGenericListCollection() {
		    genericVals = new List<int>(COLLECTIONSIZE);
			for(int i=0; i < COLLECTIONSIZE; ++i) { 
			   genericVals.Add(i);
			} 
			return COLLECTIONSIZE;
		}
		
		public long testArrayList()  {
			long sum=0;
			foreach(int i in vals) {
				sum += i;
			}
		 
			return sum;
		}
		
		public long testGenericList() {
			long sum=0;
			foreach(int i in genericVals) {
				sum += i;
			}
			return sum;
		}
	}
			
			
	
	class Program {
		
		public static void Execute(string testName, Test t) {
           
			Stopwatch sw = Stopwatch.StartNew();
			Console.Write(testName + "= ");
			long res=0;
			res=t();
			sw.Stop();
			Console.WriteLine(res);
			
			Console.WriteLine("teste executado em " + sw.ElapsedMilliseconds+ "ms");
		}
		
		static void Main(string[] args) {
			GenericsVersusObjectCollectionsPerf t = new GenericsVersusObjectCollectionsPerf();
			Execute("buildArrayListCollection", t.buildArrayListCollection);
			Execute("buildGenericListCollection", t.buildGenericListCollection);
			Execute("testArrayList", t.testArrayList);
			Execute("testGenericList", t.testGenericList);
		}
	}
}
