using System;
using System.Collections.Generic;
using System.Text;

namespace CTS2
{
    class Program
    {
        private static void callbackEvent1(object src, EventArgs args) 
		{
			System.Console.WriteLine("em callback de Event1!");
		}

        static void Main(string[] args)
        {
            TypeWithManyEvents t = new TypeWithManyEvents();
			t.Event1 += new EventHandler(callbackEvent1);
			t.generateEvent1();
        }
    }
}
