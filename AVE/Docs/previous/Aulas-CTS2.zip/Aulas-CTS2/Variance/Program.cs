#define WITH_GENERICS

using System;
using System.Collections.Generic;
using System.Text;


#if WITH_GENERICS
class Genericvariance
{
	interface ICloneable< T> {
		 T Clone();
	}

    class G<T> {
        void show(T t)
        {
            Console.WriteLine(t.ToString());
        }
    }

    class GD<T> : G<T> where T : IComparable
    {
        public int compare(T t1, T t2)
        {
            return t1.CompareTo(t2);
        }
    }

    class Gint : G<int>
    {

        public int compare(int t1, int t2)
        {
            return t1 - t2;
        }
    }

	public bool AllSame(List<object> vals)
	{
		bool first = true;
		object last= null;
		foreach (object o in vals)
		{
			if (first)
				first = false;
			else
				if (!o.Equals(last)) return false;
			last = o;
		}
		return true;
	}

    // Tipos Gen�ricos s�o invariantes no CTS
    //public  void Test() {
    //    List<string> s = new List<string>( new string[] { "teste", "ola" });
    //    Console.WriteLine(AllSame(s));
    //}
}
#endif


class A
{
    public readonly int val;

    public A(int v)
    {
        this.val = v;
    }
}

class B : A
{
    public readonly int val2;

    public B(int v1, int v2) : base(v1)
    {
        this.val2 = v2;
    }
}

delegate A D1(B b);

class Program
{
    static B callback(A a) {
        System.Console.WriteLine("In callback!, val={0}", a.val);
        return null;
    }

    static void Main(string[] args) {
        D1 d=null;
        d += callback;
        d(new B(2,5));

    }
}
