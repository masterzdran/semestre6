// FuncPtrs.cpp : main project file.

#include "stdafx.h"

using namespace System;


typedef int (*PF)(int i);

int  square(int i) {
	return i*i;
}
int main(array<System::String ^> ^args)
{
    Console::WriteLine(L"Hello World");

	PF pf = square;
	Console::WriteLine(pf(4));
    return 0;
}
