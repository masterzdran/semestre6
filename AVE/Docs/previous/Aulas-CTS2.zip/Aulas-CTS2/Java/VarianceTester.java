import java.util.*;

abstract class Shape implements Comparable<Shape> {
	
	protected abstract double area();
	
	public int compareTo(Shape s) {
		return (int) (area() - s.area());
	}
}

class Square extends Shape {
	private double  side;
	
	protected double area() { return side*side; }
	
	public Square(double side) { this.side=side; }
	
	public String toString() {
		return "Square: side = " + side;
	}
}

class Circle extends Shape {
	private double  radius;
	
	protected double area() { return radius*radius; }
	
	public String toString() {
		return "Circle: radius = " + radius;
	}
	
	public Circle(double radius) { this.radius=radius; }
}

class Node<T extends Comparable<? super T>> { 
	T val;
	T next;
}

public class VarianceTester {
    static Shape maxShape(ArrayList<? extends Shape > shapes) {
		boolean first=true;
		Shape max=null;
		for (Shape s : shapes) {
			if (first) {
				max=s;
				first = false;
			}
			else {
				if (s.compareTo(max) > 0) max = s;
			}
		}
		return max;
	}
	
	public static void main(String[] args) {
		ArrayList<Square> squares = new ArrayList<Square>();
		squares.add(new Square(10)); squares.add(new Square(20));
		
		Node<Square> n = new Node<Square>();
		System.out.println(maxShape(squares));
	}
	
}






	