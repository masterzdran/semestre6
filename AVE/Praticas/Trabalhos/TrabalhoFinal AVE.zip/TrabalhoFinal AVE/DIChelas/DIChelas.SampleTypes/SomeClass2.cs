﻿
namespace DIChelas.SampleTypes
{
    public class SomeClass2
    {

        public SomeClass2(SomeClass3 c3) { }

    }
}