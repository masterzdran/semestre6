namespace DIChelas.SampleTypes
{
    public interface ISomeInterface1
    {
        
    }
}