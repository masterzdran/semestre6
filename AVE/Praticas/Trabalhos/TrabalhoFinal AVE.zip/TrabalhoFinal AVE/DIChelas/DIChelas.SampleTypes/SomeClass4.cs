﻿
namespace DIChelas.SampleTypes
{
    public class SomeClass4
    {

        public SomeClass4() { }

    }
}