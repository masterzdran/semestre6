﻿
namespace DIChelas.SampleTypes
{
    public class SomeClass1
    {

        public SomeClass1(SomeClass2 c2) { }

    }
}