﻿
namespace DIChelas.SampleTypes
{
    public class SomeClass3
    {

        public SomeClass3(SomeClass1 c1) { }

    }
}