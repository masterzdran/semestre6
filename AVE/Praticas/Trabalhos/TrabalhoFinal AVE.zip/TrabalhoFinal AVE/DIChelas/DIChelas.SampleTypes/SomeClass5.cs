﻿
namespace DIChelas.SampleTypes
{
    public class SomeClass5
    {

        public SomeClass5() { }

    }
}