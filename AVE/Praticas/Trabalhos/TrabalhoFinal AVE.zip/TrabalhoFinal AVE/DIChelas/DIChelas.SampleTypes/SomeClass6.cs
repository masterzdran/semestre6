﻿
namespace DIChelas.SampleTypes
{
    public class SomeClass6
    {

        public SomeClass6() { }

    }
}