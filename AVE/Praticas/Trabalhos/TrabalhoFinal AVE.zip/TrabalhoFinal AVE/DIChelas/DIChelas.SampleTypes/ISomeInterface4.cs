﻿namespace DIChelas.SampleTypes
{
    public interface ISomeInterface4
    {
        ISomeInterface2 I2 { get; }

        ISomeInterface1 I1 { get; }
    }
}