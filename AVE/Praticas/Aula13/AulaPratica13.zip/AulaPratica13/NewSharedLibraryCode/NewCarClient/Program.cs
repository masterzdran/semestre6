﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CarLibrary;

namespace NewCarClient
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("***** Shared Assembly Client *****");
            SportsCar c = new SportsCar();
            c.TurboBoost();
            Console.ReadLine();
        }
    }
}
