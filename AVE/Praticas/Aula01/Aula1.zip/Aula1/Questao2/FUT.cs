using System;

public class FUT {
	public static void m() {
		Console.WriteLine(RUT.inc(1));
	}
	public static void Main(String[] args) {
		Console.WriteLine("hello world");
		Console.ReadLine();
		m();
	}
}