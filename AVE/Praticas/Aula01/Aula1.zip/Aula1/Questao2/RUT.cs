
public class RUT {
	public static int inc(int v) { return v+1; }
}