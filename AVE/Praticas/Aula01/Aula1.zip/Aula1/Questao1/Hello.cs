﻿using System;

    class Program
    {
        static void Main(string[] args)
        {
            string myMessage = "Hello World";
            Console.WriteLine(myMessage);
        }

}
